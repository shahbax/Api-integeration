<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists('inkbomb_ssactivewear_activation') ) {
    function inkbomb_ssactivewear_activation () {
    }
}