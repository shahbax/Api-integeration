<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Alphabroder\PromoStandards\Cron\Import\Gallery;
use Alphabroder\PromoStandards\Cron\Import\Inventory;
use Alphabroder\PromoStandards\Cron\Import\Price;
use Alphabroder\PromoStandards\Cron\Import\Product;
use Alphabroder\PromoStandards\Cron\Update\GalleryUpdate;
use Alphabroder\PromoStandards\Cron\Update\InventoryUpdate;
use Alphabroder\PromoStandards\Cron\Update\PriceUpdate;
use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\CronSchedules;

if ( !function_exists( 'register_alphabroder_cron' ) ) {
    function register_alphabroder_cron()
    {
        $cronSchedules = new CronSchedules();
        // Add a new scheduler
        add_filter( 'cron_schedules', array( $cronSchedules, 'after_every_two_seconds' ) );
        add_filter( 'cron_schedules', array( $cronSchedules, 'every_six_hours' ) );
        add_filter( 'cron_schedules', array( $cronSchedules, 'every_twelve_hours' ) );

        /**
         * Instances to the cron classes.
         */
        $product = new Product();
        $price = new Price();
        $inventory = new Inventory();
        $gallery = new Gallery();

        /**
         *  ===================================
         * ||        Cron Import hooks       ||
         *  ===================================
         */
        add_action(Product::HOOK_NAME, array( $product, 'execute' ));
        add_action(Price::IMPORT_CRON, array( $price, 'execute' ));
        add_action(Inventory::IMPORT_CRON, array( $inventory, 'execute' ));
        add_action(Gallery::IMPORT_CRON, array( $gallery, 'execute' ));

        /**
         *  ===================================
         * ||        Cron UPDATE hooks       ||
         *  ===================================
         */
        $update_inventory = new InventoryUpdate();
        add_action(InventoryUpdate::CRON_NAME, array($update_inventory, 'update' ));
        add_action(InventoryUpdate::CRON_UPDATE, array($update_inventory, 'execute' ));

        $price_update = new PriceUpdate();
        add_action(PriceUpdate::CRON_NAME, array($price_update, 'update' ));
        add_action(PriceUpdate::CRON_UPDATE, array($price_update, 'execute' ));

        $gallery_update = new GalleryUpdate();
        add_action(GalleryUpdate::CRON_NAME, array($gallery_update, 'update' ));
        add_action(GalleryUpdate::CRON_UPDATE, array($gallery_update, 'execute' ));
    }
}

/**
 * Clear the running import schedules and clear the log file.
 *
 */
if ( !function_exists( 'init_alphabrorder_import_fn' ) ) {
    function init_alphabrorder_import_fn()
    {
        // Clear all import.
        $price = new Price();
        $price->clearScheduler( 1 );
        // Clear import log
        Logger::log("", "w");
    }
}

/**
 * Schedule Price import after completing the product data import request.
 *
 */
if ( ! function_exists( 'after_completed_alphabrorder_import' ) ) {
    function after_completed_alphabrorder_import()
    {
        if ( !wp_next_scheduled ( Price::IMPORT_CRON ) ) {
            Logger::log("Starting Price Import event.");
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_TWO_SECONDS,
                Price::IMPORT_CRON
            );
        }
    }
}

/**
 * Schedule the Gallery import request after performing price and configuration.
 *
 */
if ( !function_exists( 'after_completed_alphabrorder_price_import' ) ) {
    function after_completed_alphabrorder_price_import()
    {
        if ( !wp_next_scheduled ( Gallery::IMPORT_CRON ) ) {
            Logger::log("Starting Gallery Import event.");
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_TWO_SECONDS,
                Gallery::IMPORT_CRON
            );
        }
    }
}

/**
 * Run inventory import schedule soon after completing the gallery import request.
 *
 */
if ( !function_exists( 'after_completed_alphabrorder_gallery_import' ) ) {
    function after_completed_alphabrorder_gallery_import()
    {
        if ( !wp_next_scheduled ( Inventory::IMPORT_CRON ) ) {
            Logger::log("Starting Inventory Import event.");
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_TWO_SECONDS,
                Inventory::IMPORT_CRON
            );
        }
    }
}

if ( !function_exists( 'after_completed_alphabrorder_inventory_import' ) ) {
    function after_completed_alphabrorder_inventory_import()
    {
        $product = new Product();
        if ( !$product->getImporterFlag() ) {
            return;
        }

        $product->setImporterFlag( false );
        Logger::log( "Inventory Import: After completing inventory import request. Preparing for next productData request." );
    }
}

/**
 *
 *  ==================================================================================================================
 *                                     *******************************
 *                                     ***   Cron UPDATE functions ***
 *                                     *******************************
 *  ==================================================================================================================
 *
 */

/**
 * Inventory update.
 */

if ( !function_exists( 'alphabroder_update_inventory_fn' ) ) {
    function alphabroder_update_inventory_fn()
    {
        if ( !wp_next_scheduled ( InventoryUpdate::CRON_NAME ) ) {
            wp_schedule_event(
                time(),
                'hourly',
                InventoryUpdate::CRON_NAME
            );
        }
    }
}

/**
 * Price update.
 */
if ( !function_exists( 'alphabroder_update_price_fn' ) ) {
    function alphabroder_update_price_fn()
    {
        if ( !wp_next_scheduled ( PriceUpdate::CRON_NAME ) ) {
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_SIX_HOURS,
                PriceUpdate::CRON_NAME
            );
        }
    }
}
/**
 * Gallery update.
 */

if ( !function_exists( 'alphabroder_update_gallery_fn' ) ) {
    function alphabroder_update_gallery_fn()
    {
        if ( !wp_next_scheduled ( GalleryUpdate::CRON_NAME ) ) {
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_TWELVE_HOURS,
                GalleryUpdate::CRON_NAME
            );
        }
    }
}

/**
 *
 *  ==================================================================================================================
 *                                     *******************************
 *                                     ***      Uninstall Cron     ***
 *                                     *******************************
 *  ==================================================================================================================
 *
 */
/**
 * Uninstall all cron jobs.
 */
if ( !function_exists( 'alphabroder_uninstall_cron_jobs' ) ) {
    function alphabroder_uninstall_cron_jobs()
    {
        $known_cron_list = array(
            InventoryUpdate::CRON_NAME,
            InventoryUpdate::CRON_UPDATE,
            PriceUpdate::CRON_NAME,
            PriceUpdate::CRON_UPDATE,
            GalleryUpdate::CRON_NAME,
            GalleryUpdate::CRON_UPDATE,
            Product::HOOK_NAME,
            Price::IMPORT_CRON,
            Inventory::IMPORT_CRON,
            Gallery::IMPORT_CRON,
        );

        foreach ( $known_cron_list as $cron_item ) {
            if ( wp_next_scheduled ( $cron_item ) ) {
                wp_clear_scheduled_hook( $cron_item );
            }
        }
    }
}