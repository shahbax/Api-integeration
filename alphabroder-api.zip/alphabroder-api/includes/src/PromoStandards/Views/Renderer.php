<?php
namespace Alphabroder\PromoStandards\Views;

class Renderer extends \InkbombCore\View\Template\Renderer
{
    public static function getTemplateDir(): string
    {
        return ALPHABRODER_PATH . 'includes/src/PromoStandards/Views/';
    }
}