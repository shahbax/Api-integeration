<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Alphabroder\PromoStandards\Cron\Import\Product;
use Alphabroder\PromoStandards\Model\Config;

$text_domain = 'alphabroder';
$options = get_option( Config::IMPORT_OPTIONS );
$read_line = ( isset( $options[Config::OPTIONS_PROMOSTANDARDS] )
    && isset($options[Config::OPTIONS_PROMOSTANDARDS]['read_line'])
    && isset($options[Config::OPTIONS_PROMOSTANDARDS]['read_line']['start'])
) ? $options[Config::OPTIONS_PROMOSTANDARDS]['read_line']['start'] : 0;

$is_importing = Config::isImportingCronInProgress();

$display_style_import_btn = ' display: ' . (!$is_importing ? 'inline-block; ' : 'none; ');
$display_cancel = ' display: ' . (!$is_importing ? 'none; ' :  'inline-block; ');
?>

<div class="wrap woocommerce">
    <h1 class="screen-reader-text"><?php esc_html_e( 'Import Products', $text_domain ); ?></h1>
    <h2><?php esc_html_e( 'Import Alphabroder Products', $text_domain ); ?></h2>
    <?php if ( !wp_next_scheduled( Product::HOOK_NAME ) ): ?>
    <p class="import-instructions">To begin import click the start importing button. Use <strong>Reset Import</strong>
        button to restart reading the Excel file from beginning. The products will be refreshed in this case.</p>
    <?php endif; ?>
    <div class="import-wrapper">
        <?php
            if ( !wp_next_scheduled( Product::HOOK_NAME ) ):
        ?>
        <button type="button" id="import_products_btn" class="button-primary woocommerce-save-button inkbomb-importer-btn"
            style="<?php echo $display_style_import_btn; ?> vertical-align: middle;"><?php esc_html_e('Begin import', $text_domain); ?></button>
            <?php if ( $read_line ): ?>
                <button type="button" id="reset_import_products_btn" class="button-secondary woocommerce-save-button"
                        style="<?php echo $display_style_import_btn; ?> vertical-align: middle;">Reset Import</button>
            <?php endif; ?>
                <div class="notice notice-info" id="info-noticebar"
                     style="display: none;"><p>The import will process via cron jobs. It will take some time.</p>
                    <p>Meanwhile, you may continue to perform other actions in Wordpress.</p>
                </div>
        <?php else: ?>
                <div class="notice error-info"><p>Actions will be available as soon the last Cron job is completed.</p></div>
                <p id="in_progress">Last process in progress</p>
        <?php endif; ?>
        <button type="button" id="cancel_import_btn" class="button-secondary" style="<?php echo $display_cancel; ?> vertical-align: middle;">Cancel import</button>
    </div>
    <div id="import-status"></div>
    <div id="product-status"></div>
</div>
<script type="text/javascript">
    window.is_importing_products = parseInt('<?php echo ($is_importing ? 1 : 0) ?>');
    jQuery( function ( $ ) {
        var import_btn= '#import_products_btn',
            cancel_btn = '#cancel_import_btn',
            import_status = '#import-status',
            reset_import_btn = '#reset_import_products_btn';

        if (window.is_importing_products) {
            count_import_total();
        }

        $( document ).on( 'click', import_btn, function () {
            $( this ).hide();
            $( cancel_btn ).show();
            $( import_status ).html(" Preparing to import ");
            $.post(ajaxurl, {
                allow_act: 1,
                action: 'begin_alphabroder_import'
            }, function (data, status) {
                $( cancel_btn ).show();
                $( import_status ).html( "Import started..." );
                $( "#info-noticebar" ).show();
                // Hide import instructions.
                $( ".import-instructions" ).hide();
                // Display counter.
                if ( !window.is_importing_products ) {
                    window.is_importing_products = 1;
                    count_import_total();
                }

                setTimeout(function () {
                    $( import_status ).html("");
                }, 10000);
            });
        } );

        $( document ).on( 'click', reset_import_btn, function () {
            if ( !confirm( "Are you sure you want to Reset the import reader to 0. The products will be refreshed." ) ) {
                return false;
            }

            $( import_status ).html( "Reseting..." );
            $.post(ajaxurl, {
                refresh_req: 1,
                action: 'reset_alphabroder_import'
            }, function (data, status) {
                $( import_status ).html( "Reset requested." );
                setTimeout(function () {
                    document.location = "";
                }, 500);
            });
        } );

        $( document ).on( 'click', cancel_btn, function () {
            if ( !confirm( "Are you sure you want to cancel the progressed import?" ) ) {
                return false;
            }

            $( import_status ).html( "Preparing to cancel..." );
            $.post(ajaxurl, {
                disallow_act: 1,
                action: 'stop_alphabroder_import'
            }, function (data, status) {
                $( cancel_btn ).hide();
                $( import_btn ).show();
                $( reset_import_btn ).show();
                $( import_status ).html( "Cancelled" );
                window.is_importing_products = 0;
                setTimeout(function () {
                    document.location = "";
                }, 5000);
            });
        } );

        if ( $("#in_progress").length ) {
            var intvl = setInterval(function () {
                $.post(ajaxurl, {
                    is_in_progress: 1,
                    action: 'is_alphabroder_cron'
                }, function (data, status) {
                    if ( data !== undefined && data.in_progress !== undefined && data.in_progress === "1") {
                        document.location = "";
                        clearInterval(intvl);
                    }
                });
            }, 10000);
        }

        function count_import_total() {
            var import_status = setInterval( function () {
                $.post(ajaxurl, {
                    action: 'alphabroder_import_total'
                }, function (data, status) {
                    if ( data !== undefined && data.total_imported !== undefined) {
                        $( "#product-status" ).html( data.total_imported + " products have been imported." );
                    }
                });

                if ( !window.is_importing_products ) {
                    clearInterval( import_status );
                }
            }, 6000 );
        }

    } );
</script>
