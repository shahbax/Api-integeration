<?php

use Alphabroder\PromoStandards\Views\Renderer;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$default_tab = null;
$tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
$settings_page = 'alphaborder-api-settings';
?>
<div class="wrap">
    <h1><?php /** @var $title */ echo $title; ?></h1>
    <nav class="nav-tab-wrapper">
        <a href="?page=<?php echo $settings_page; ?>" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Settings</a>
        <a href="?page=<?php echo $settings_page; ?>&tab=import_products" class="nav-tab <?php if($tab==='import_products'):?>nav-tab-active<?php endif; ?>">Import Product</a>
    </nav>
    <div class="tab-content">
        <?php
        $tab_to_render = 'admin/settings/general_settings.php';
        switch( $tab ) {
            case 'import_products':
                $tab_to_render = 'admin/settings/import_products.php';
                break;
        }
        Renderer::render($tab_to_render);
        ?>
    </div>
</div>