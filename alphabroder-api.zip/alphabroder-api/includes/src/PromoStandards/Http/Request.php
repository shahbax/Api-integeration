<?php
namespace Alphabroder\PromoStandards\Http;

use Alphabroder\PromoStandards\Model\Credential;

class Request extends \InkbombCore\Http\Request
{
    /**
     * @var array
     */
    private $auth;

    /**
     * @param array $options
     * @param array $headers
     * @param array|string $body
     * @param array $auth
     * @param string $method
     * @param string $uri
     */
    public function __construct(
        array $options,
        array $headers,
        $body,
        array $auth,
        $method,
        $uri
    ) {
        $this->auth = $auth;
        parent::__construct($options, $headers, $body, $method, $uri);
    }

    /**
     * Return Authentication ID
     *
     * @return string
     */
    public function getAuthId()
    {
        return $this->auth[Credential::AUTH_ID];
    }

    /**
     * Returns Authentication Password
     *
     * @return string
     */
    public function getAuthPassword()
    {
        return $this->auth[Credential::AUTH_PASSWORD];
    }
}
