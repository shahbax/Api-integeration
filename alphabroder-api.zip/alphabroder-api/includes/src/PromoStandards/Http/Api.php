<?php
namespace Alphabroder\PromoStandards\Http;

use Alphabroder\PromoStandards\Model\Xml\Converter;
use Alphabroder\PromoStandards\Model\Xml\XmlRequestBuilder;
use GuzzleHttp\Exception\GuzzleException;

class Api implements \InkbombCore\Http\ApiInterface
{
    /**
     * @var Converter
     */
    private Converter $xmlConverter;

    /**
     * @var XmlRequestBuilder
     */
    private XmlRequestBuilder $requestBuilder;

    /**
     * @var \GuzzleHttp\Client
     */
    private $client;

    public function __construct()
    {
        $this->xmlConverter = new Converter();
        $this->requestBuilder = new XmlRequestBuilder();
    }

    /**
     * @param \InkbombCore\Http\Request|Request $httpRequest
     * @return array
     * @throws \Exception
     */
    public function execute($httpRequest)
    {
        $options = $httpRequest->getOptions();
        try {
            $body = $this->requestBuilder->build($httpRequest->getBody());
            $raw_response = $this->getClient()->request($httpRequest->getMethod(), $httpRequest->getUri(), [
                'headers' => [
                    'Content-Type' => isset($options['contentType']) ?? 'application/xml'
                ],
                'body' => $body
            ]);
            $xmlStr = $raw_response->getBody()->getContents();
            return $this->xmlConverter->xmlStringToArray($xmlStr);
        } catch (GuzzleException|\Exception $e) {
            throw new \Exception($e->getMessage());
            //return $this->xmlConverter->xmlStringToArray($e->getMessage());
        }
    }

    private function getClient()
    {
        if ( empty( $this->client ) ) {
            $this->client = new \GuzzleHttp\Client();
        }
        return $this->client;
    }
}