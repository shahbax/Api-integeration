<?php
namespace Alphabroder\PromoStandards\Model;

use InkbombCore\Http\CredentialInterface;

class Credential implements CredentialInterface
{
    /**
     * Authentication ID.
     */
    const AUTH_ID = 'id';

    /**
     * Authentication Password.
     */
    const AUTH_PASSWORD = 'password';

    /**
     * @var Config
     */
    private Config $config;

    /**
     * @param Config $config
     */
    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    /**
     * @return array
     */
    public function getAuth(): array
    {
        return [
            self::AUTH_ID => $this->config->getAuthId(),
            self::AUTH_PASSWORD => $this->config->getPassword(),
        ];
    }
}