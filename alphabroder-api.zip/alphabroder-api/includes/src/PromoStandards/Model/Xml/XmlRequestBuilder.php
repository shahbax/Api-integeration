<?php
namespace Alphabroder\PromoStandards\Model\Xml;

class XmlRequestBuilder
{
    /**
     * @var RequestValidators
     */
    private RequestValidators $requestValidators;

    public function __construct()
    {
        $this->requestValidators = new RequestValidators();
    }

    public function build(array $xmlArray): string
    {
        if (empty($xmlArray)) {
            return "";
        }

        $xmlStr = '<?xml version="1.0" encoding="utf-8"?>';
        try {
            $this->requestValidators->validate($xmlArray);
        } catch (\Exception $e) {
            return $xmlStr;
        }

        $xmlStr .= '<soapenv:Envelope ';
        foreach ($xmlArray['soapenv:Envelope'] as $key => $value) {
            if (is_int($key) || !is_string($value)) {
                continue;
            }

            $xmlStr .= $key . '="' . $value . '" ';
        }
        $xmlStr .= ">";

        $xmlStr .= $this->generateSoapContent($xmlArray['soapenv:Envelope'][0]);

        $xmlStr .= "</soapenv:Envelope>";
        return $xmlStr;
    }

    private function generateSoapContent($content)
    {
        $xmlstr = '';
        if (empty($content)) {
            return $xmlstr;
        }

        foreach ($content as $key => $value) {
            if (is_array($value) && empty($value)) {
                $xmlstr .= "<{$key} />";
                continue;
            }

            $xmlstr .= "<{$key}>";
            if (is_array($value)) {
                $xmlstr .= $this->generateSoapContent($value);
            } else {
                $xmlstr .= $value;
            }
            $xmlstr .= "</{$key}>";
        }

        return $xmlstr;
    }
}