<?php
namespace Alphabroder\PromoStandards\Model\Xml;

use Alphabroder\PromoStandards\Model\Xml\RequestValidators\ValidatorInterface;

class RequestValidators
{
    /**
     * @var validatorInterface[]
     */
    private array $validators = [];

    /**
     * @param validatorInterface[] $validators
     */
    public function __construct(array $validators = [])
    {
        $this->validators = $validators;
    }

    /**
     * @param array $data
     * @return void
     * @throws \Exception
     */
    public function validate(array $data): void
    {
        foreach ($this->validators as $validator) {
            if (!$validator instanceof ValidatorInterface) {
                throw new \Exception("Invalid validator specified.");
            }

            $validator->validate($data);
        }
    }
}