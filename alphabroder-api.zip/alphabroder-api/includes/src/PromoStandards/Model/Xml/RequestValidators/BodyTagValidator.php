<?php
namespace Alphabroder\PromoStandards\Model\Xml\RequestValidators;

class BodyTagValidator implements ValidatorInterface
{
    /**
     * @inheritDoc
     */
    public function validate(array $data)
    {
        if (!isset($data['soapenv:Body'])) {
            throw new \Exception("Soap body is required");
        }
    }
}