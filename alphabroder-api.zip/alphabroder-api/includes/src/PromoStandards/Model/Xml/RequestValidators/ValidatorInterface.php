<?php
namespace Alphabroder\PromoStandards\Model\Xml\RequestValidators;

interface ValidatorInterface
{
    /**
     * @param array $data
     * @throws \Exception
     */
    public function validate(array $data);
}