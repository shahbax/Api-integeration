<?php
namespace Alphabroder\PromoStandards\Model\Xml\RequestValidators;

class EnvelopeValidator
{
    public function validate(array $data)
    {
        if (!isset($data['soapenv:Envelope'])) {
            throw new \Exception("Soap Envelop is missing");
        }
    }
}