<?php
namespace Alphabroder\PromoStandards\Model\Xml;

class Converter
{
    /**
     * @param string $xml
     * @param string|null $keySplitter
     * @return array
     */
    public function xmlStringToArray(string $xml, ?string $keySplitter = ':'): array
    {
        /*assert(\class_exists('\DOMDocument'));
        $doc = new \DOMDocument();
        $doc->loadXML($xml);
        $root = $doc->documentElement;
        $output = (array) $this->domNodeToArray($root, $keySplitter);
        $output['@root'] = $root->tagName;*/
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $clean_xml = str_ireplace(['ns1:', ''], '', $clean_xml);
        $clean_xml = str_ireplace(['ns2:', ''], '', $clean_xml);
        $clean_xml = str_ireplace(['ns0:', ''], '', $clean_xml);
        $xml = simplexml_load_string($clean_xml);
        $output = json_decode(json_encode($xml), true);
        return $output ?? [];
    }

    /**
     * @param $node
     * @param string $keySplitter
     * @return array|string|string[]
     */
    public function domNodeToArray($node, $keySplitter = '')
    {
        $output = [];
        switch ($node->nodeType) {
            case 4: // XML_CDATA_SECTION_NODE
            case 3: // XML_TEXT_NODE
                $output = trim($node->textContent);
                break;
            case 1: // XML_ELEMENT_NODE
                for ($i = 0, $m = $node->childNodes->length; $i < $m; $i++) {
                    $child = $node->childNodes->item($i);
                    $v = self::domNodeToArray($child, $keySplitter);
                    if (isset($child->tagName)) {
                        $t = $child->tagName;
                        // Can be a colon
                        if (!empty($keySplitter)) {
                            $t = substr($t, strpos($t, $keySplitter) + 1, strlen($t));
                        }
                        if (!isset($output[$t])) {
                            $output[$t] = [];
                        }
                        if (is_array($v) && empty($v)) {
                            $v = '';
                        }
                        $output[$t][] = $v;
                    } elseif ($v || $v === '0') {
                        $output = (string) $v;
                    }
                }
                if ($node->attributes->length && !is_array($output)) { // has attributes but isn't an array
                    $output = ['@content' => $output]; // change output into an array.
                }
                if (is_array($output)) {
                    if ($node->attributes->length) {
                        $a = [];
                        foreach ($node->attributes as $attrName => $attrNode) {
                            $a[$attrName] = (string) $attrNode->value;
                        }
                        $output['@attributes'] = $a;
                    }
                    foreach ($output as $t => $v) {
                        if ($t !== '@attributes' && is_array($v) && count($v) === 1) {
                            $output[$t] = $v[0];
                        }
                    }
                }
                break;
        }

        return $output;
    }
}