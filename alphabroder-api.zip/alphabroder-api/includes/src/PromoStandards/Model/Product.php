<?php
namespace Alphabroder\PromoStandards\Model;

class Product extends \InkbombCore\Model\Product
{
    const PRICE_EFFECTIVE_DATE = 'priceEffectiveDate';
    const PRICE_EXPIRY_DATE = 'priceExpiryDate';
    const ALPHABRODER_PRODUCT = 'alphaborder_product';

    /**
     * Checks if a product belongs to Alphabroder.
     *
     * @param int $productId
     * @return bool
     */
    public function isAlphaBroderProduct( $productId )
    {
        return (bool) get_post_meta( $productId, self::ALPHABRODER_PRODUCT );
    }

    /**
     * Return the Alphabroder Product Ids.
     *
     * @return array|object|\stdClass[]|null
     */
    public function getAlphaBroderProductIds()
    {
        return $this->getIdsByApiProduct( static::ALPHABRODER_PRODUCT, '1' );
    }

    public function getVariationBySku( $sku )
    {
        try {
            return parent::getVariationBySku( $sku );
        } catch ( \Exception $e ) {
            error_log( "#########  ERROR    ########" );
            error_log( $e->getMessage() );
            return false;
        }
    }

    /**
     * Set Variation Price Effective Date.
     *
     * @param string|int $variationId
     * @param string $dateTime
     */
    public function setVariationPriceEffectiveDate( $variationId, $dateTime )
    {
        update_post_meta( $variationId,  self::PRICE_EFFECTIVE_DATE, $dateTime);
    }

    /**
     * Set Variation price expiry date.
     *
     * @param string|int $variationId
     * @param string $dateTime
     */
    public function setVariationPriceExpiryDate( $variationId, $dateTime )
    {
        update_post_meta( $variationId,  self::PRICE_EXPIRY_DATE, $dateTime);
    }

    /**
     * Get Variation price Effective datetime string.
     *
     * @param string|int $variationId
     * @return string|null
     */
    public function getVariationPriceEffectiveDate( $variationId )
    {
        return get_post_meta( $variationId, self::PRICE_EFFECTIVE_DATE, true );
    }

    /**
     * Get variation price expiry date time.
     *
     * @param string|int $variationId
     * @return string|null
     */
    public function getVariationPriceExpiryDate( $variationId )
    {
        return get_post_meta( $variationId, self::PRICE_EXPIRY_DATE, true );
    }

    public function formatDateTimeFromRange( $range )
    {
        $split_date_time = explode("T", $range);
        if ( !isset( $split_date_time[ 1 ] ) ) {
            return $range;
        }

        $maxTime = explode("-", $split_date_time[1]);
        if ( !isset( $maxTime[ 1 ] ) ) {
            return $range;
        }

        return $split_date_time[0] .' ' . $maxTime[1];
    }

    /**
     * Read imported products csv.
     *
     * @return array
     */
    public function getImportedProductsData($importFileName)
    {
        if ( !file_exists( ALPHABRODER_PATH . 'assets/' . $importFileName ) ) {
            $handler = fopen( ALPHABRODER_PATH . 'assets/' . $importFileName, 'w' );
            fwrite($handler, "");
            fclose($handler);
        }

        $data = file_get_contents(ALPHABRODER_PATH . 'assets/' . $importFileName);
        $rows = explode(PHP_EOL, $data);
        $output = [];
        foreach ($rows as $key => $row) {
            if ($key == 0) {
                continue;
            }

            $content = explode(",", $row);
            if ( empty($row) ) {
                continue;
            }

            $output[] = $content[0];
        }

        return $output;
    }

    public function markImportedProductsInCsv($importFileName, $id)
    {
        $existing_data = $this->getImportedProductsData( $importFileName );
        if (in_array( $id, $existing_data)) {
            return;
        }

        $existing_data[] = "{$id}";
        // Create headers
        $csv = "id" . PHP_EOL;
        $size = count( $existing_data );
        for ($i=0; $i < $size; $i++) {
            $csv .= "{$existing_data[$i]}";
            if ( $i < ($size - 1) && ($size - 1) > 0 ) {
                $csv .= PHP_EOL;
            }
        }

        file_put_contents( ALPHABRODER_PATH . 'assets/' . $importFileName, $csv );
    }
}