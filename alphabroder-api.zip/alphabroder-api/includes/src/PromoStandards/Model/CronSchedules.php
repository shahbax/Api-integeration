<?php
namespace Alphabroder\PromoStandards\Model;

class CronSchedules
{
    const EVERY_TWO_SECONDS = 'alphabroder_every_two_seconds';
    const EVERY_SIX_HOURS = 'alphabroder_every_six_hours';
    const EVERY_TWELVE_HOURS = 'alphabroder_every_twelve_hours';

    public function after_every_two_seconds( $schedules )
    {
        $schedules [ self::EVERY_TWO_SECONDS ] = array(
            "interval" => 2,
            "display" => esc_html__( __('Alphabroder Every two seconds scheduler' )  ),
        );
        return $schedules;
    }

    public function every_six_hours( $schedules )
    {
        $schedules [ self::EVERY_SIX_HOURS ] = array(
            "interval" => 21600,
            "display" => esc_html__( __('Alphabroder Every Six seconds scheduler' )  ),
        );
        return $schedules;
    }

    public function every_twelve_hours( $schedules )
    {
        $schedules [ self::EVERY_TWELVE_HOURS ] = array(
            "interval" => 43200,
            "display" => esc_html__( __('Alphabroder Every Twelve seconds scheduler' )  ),
        );
        return $schedules;
    }
}