<?php
namespace Alphabroder\PromoStandards\Model;

use Alphabroder\PromoStandards\Hook\Admin\Settings;

/**
 * Config class contains the list configuration and settings.
 */
class Config extends \InkbombCore\Model\Config
{
    public const DEV_ENDPOINT = 'https://devservices.alphabroder.ca/';
    public const PRODUCTION_ENDPOINT = 'https://services.alphabroder.ca/';
    public const APP_MODE_PRODUCTION = 'production';
    public const APP_MODE_DEVELOPER = 'developer';
    public const COUNTRY = 'CA';
    public const UOM_CA = 'CA';
    public const LANGUAGE = 'en';
    public const CURRENCY = 'CAD';
    public const DOMAIN = 'alphabroder';
    public const FOB_ID = 'CC';
    public const CULTURE_NAME = 'en-CA';
    public const IMPORT_OPTIONS = 'alphabroder_import_update';
    public const OPTIONS_PROMOSTANDARDS = 'promostandard_products';

    /**
     * API App Mode.
     *
     * @var string
     */
    private string $appMode;

    /**
     * Returns import options data.
     *
     * @return array
     */
    public static function getImportOptions(): array
    {
        $options = get_option( self::IMPORT_OPTIONS );
        return !empty( $options ) ? $options : [];
    }

    /**
     * Returns the Settings option data array.
     *
     * @param string|null $filterIndex
     * @return array
     */
    public function getSettingsArray( $filterIndex = '' ): array
    {
        return $this->getConfigArray( Settings::OPTION_NAME, $filterIndex );
    }

    /**
     * Returns the API App mode.
     *
     * @return string|null
     */
    public function getAppMode(): ?string
    {
        if ( empty($this->appMode) ) {
            $settings = $this->getSettingsArray( Settings::OPTION_NAME );
            $this->appMode = (!empty( $settings )) ? $settings[ Settings::OPTION_NAME ] : self::APP_MODE_DEVELOPER;
        }

        return $this->appMode;
    }

    /**
     * Checks if log writer is enabled.
     *
     * @return int
     */
    public function isLogEnabled()
    {
        $isEnabled = $this->getSettingsArray( Settings::OPTION_LOGGING );
        return ( !empty( $isEnabled ) ) ? (int)$isEnabled[Settings::OPTION_LOGGING] : 0;
    }

    /**
     * Returns API Auth ID
     *
     * @return array|string
     */
    public function getAuthId()
    {
        $authId = $this->getSettingsArray( Settings::OPTION_AUTH_ID );
        return ( !empty( $authId ) ) ? $authId[Settings::OPTION_AUTH_ID] : '';
    }

    /**
     * Returns the API Password.
     *
     * @return array|string
     */
    public function getPassword()
    {
        $password = $this->getSettingsArray( Settings::OPTION_AUTH_PWD );
        return ( !empty( $password ) ) ? $password[Settings::OPTION_AUTH_PWD] : '';
    }

    public static function isImportingCronInProgress()
    {
        $ret = false;
        if ( wp_next_scheduled( \Alphabroder\PromoStandards\Cron\Import\Product::HOOK_NAME )
            || wp_next_scheduled( \Alphabroder\PromoStandards\Cron\Import\Price::IMPORT_CRON )
            || wp_next_scheduled( \Alphabroder\PromoStandards\Cron\Import\Gallery::IMPORT_CRON )
            || wp_next_scheduled( \Alphabroder\PromoStandards\Cron\Import\Inventory::IMPORT_CRON )
        ) {
            $ret = true;
        }

        return $ret;
    }
}