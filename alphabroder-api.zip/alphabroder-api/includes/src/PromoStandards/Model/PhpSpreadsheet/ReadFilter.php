<?php
namespace Alphabroder\PromoStandards\Model\PhpSpreadsheet;

class ReadFilter implements \PhpOffice\PhpSpreadsheet\Reader\IReadFilter
{
    protected $startRow = 0;

    protected $endRow = 0;

    public function __construct($startRow = 0, $endRow = 0)
    {
        $this->startRow = $startRow;
        $this->endRow = $endRow;
    }

    public function readCell($columnAddress, $row, $worksheetName = '') {
        if ($row >= $this->startRow && $row <= $this->endRow) {
            return true;
        }

        return false;
    }

    public function setStartRow($startRow)
    {
        $this->startRow = $startRow;
    }

    public function setEndRow( $endRow )
    {
        $this->endRow = $endRow;
    }

    public function getStartRow()
    {
        return $this->startRow;
    }

    public function getEndRow()
    {
        return $this->endRow;
    }
}