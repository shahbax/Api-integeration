<?php
namespace Alphabroder\PromoStandards\Model\Service;

use Alphabroder\PromoStandards\Http\Api;
use Alphabroder\PromoStandards\Http\Request;
use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\Credential;

abstract class AbstractService
{
    /**
     * @var Config
     */
    protected Config $_config;

    /**
     * @var Credential
     */
    private Credential $credential;

    /**
     * @var Api
     */
    private Api $api;

    /**
     * @param Config $config
     */
    public function __construct(Config $config)
    {
        $this->_config = $config;
        $uri = Config::DEV_ENDPOINT;
        if ($this->getConfig()->getAppMode() == Config::APP_MODE_PRODUCTION) {
            $uri = Config::PRODUCTION_ENDPOINT;
        }

        $this->constructEndpoints($uri);
    }

    /**
     * Construct endpoints.
     *
     * @param string $uri
     */
    abstract protected function constructEndpoints($uri);

    /**
     * Sends an API request to the server.
     *
     * @param string $wsdl
     * @param array $body
     * @return array
     * @throws \Exception
     */
    protected function sendRequest(string $wsdl, array $body = [] ): array
    {
        $httpRequest = new Request(
            ['contentType' => 'application/xml'],
            [],
            $body,
            $this->getCredential()->getAuth(),
            'POST',
            $wsdl
        );
        return $this->getApi()->execute($httpRequest);
    }

    /**
     * @return Config
     */
    protected function getConfig(): Config
    {
        return $this->_config;
    }

    /**
     * @return Api
     */
    protected function getApi(): Api
    {
        if ( empty( $this->api ) ) {
            $this->api = new Api();
        }

        return $this->api;
    }

    /**
     * Returns Credential Instance.
     *
     * @return Credential
     */
    protected function getCredential(): Credential
    {
        if ( empty( $this->credential ) ) {
            $this->credential = new Credential($this->_config);
        }

        return $this->credential;
    }
}