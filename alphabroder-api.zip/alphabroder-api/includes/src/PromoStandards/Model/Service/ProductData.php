<?php
namespace Alphabroder\PromoStandards\Model\Service;

use Alphabroder\PromoStandards\Http\Request;
use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\Credential;

class ProductData extends AbstractService
{
    /**
     * @var string
     */
    protected $wsdl;

    /**
     * @var string
     */
    protected $wsdl2;

    /**
     * @var string
     */
    protected $wsdlMedia;

    /**
     * @var string
     */
    protected $wsdlInventory;

    /**
     * @var string
     */
    protected $wsdlInventory2;

    /**
     * @var string
     */
    protected $wsdlPricing;

    /**
     * Fetch products data.
     *
     * @param string|int $id
     * @param string|null $partId
     * @return array
     * @throws \Exception
     */
    public function fetchProductData($id, ?string $partId = ""): array
    {
        $auth = $this->getCredential()->getAuth();
        $api_version = "2.0.0";
        $ns = "http://www.promostandards.org/WSDL/ProductDataService/2.0.0/";
        $shar = "http://www.promostandards.org/WSDL/ProductDataService/2.0.0/SharedObjects/";
        $body = [
            "soapenv:Envelope"  =>  [
                "xmlns:soapenv" => "http://schemas.xmlsoap.org/soap/envelope/",
                "xmlns:ns" => $ns,
                "xmlns:shar" => $shar,
                [
                    "soapenv:Header" => [],
                    "soapenv:Body" => [
                        "ns:GetProductRequest" => [
                            "shar:wsVersion" => $api_version,
                            "shar:id" => $auth[Credential::AUTH_ID],
                            "shar:password" => $auth[Credential::AUTH_PASSWORD],
                            "shar:localizationCountry" => Config::COUNTRY,
                            "shar:localizationLanguage" => Config::LANGUAGE,
                            "shar:productId" => $id,
                            "shar:partId" => $partId,
                        ]
                    ]
                ]
            ]
        ];

        return $this->sendRequest( $this->wsdl2, $body );
    }

    /**
     * Retrieve pricing and configuration data.
     *
     * @param string|int $id
     * @param string|null $partId
     * @return array
     * @throws \Exception
     */
    public function fetchPricingData($id, ?string $partId = ""): array
    {
        $auth = $this->getCredential()->getAuth();
        $api_version = "1.0.0";
        $ns = "http://www.promostandards.org/WSDL/PricingAndConfiguration/1.0.0/";
        $shar = "http://www.promostandards.org/WSDL/PricingAndConfiguration/1.0.0/SharedObjects/";
        $body = [
            "soapenv:Envelope"  =>  [
                "xmlns:soapenv" => "http://schemas.xmlsoap.org/soap/envelope/",
                "xmlns:ns" => $ns,
                "xmlns:shar" => $shar,
                [
                    "soapenv:Header" => [],
                    "soapenv:Body" => [
                        "ns:GetConfigurationAndPricingRequest" => [
                            "shar:wsVersion" => $api_version,
                            "shar:id" => $auth[Credential::AUTH_ID],
                            "shar:password" => $auth[Credential::AUTH_PASSWORD],
                            "shar:localizationCountry" => Config::COUNTRY,
                            "shar:localizationLanguage" => Config::LANGUAGE,
                            "shar:currency" => Config::CURRENCY,
                            "shar:fobId" => Config::FOB_ID,
                            "shar:priceType" => "Customer",
                            "shar:configurationType" => "Blank",
                            "shar:productId" => $id,
                            "shar:partId" => $partId,
                        ]
                    ]
                ]
            ]
        ];

        return $this->sendRequest( $this->wsdlPricing, $body );
    }

    /**
     * Fetch media Gallery
     *
     * @param string|int $id
     * @param string|null $partId
     * @return array
     * @throws \Exception
     */
    public function fetchMediaGallery($id, ?string $partId = ""): array
    {
        $auth = $this->getCredential()->getAuth();
        $api_version = "1.1.0";
        $ns = "http://www.promostandards.org/WSDL/MediaService/1.0.0/";
        $shar = "http://www.promostandards.org/WSDL/MediaService/1.0.0/SharedObjects/";
        $body = [
            "soapenv:Envelope"  =>  [
                "xmlns:soapenv" => "http://schemas.xmlsoap.org/soap/envelope/",
                "xmlns:ns" => $ns,
                "xmlns:shar" => $shar,
                [
                    "soapenv:Header" => [],
                    "soapenv:Body" => [
                        "ns:GetMediaContentRequest" => [
                            "shar:wsVersion" => $api_version,
                            "shar:id" => $auth[Credential::AUTH_ID],
                            "shar:password" => $auth[Credential::AUTH_PASSWORD],
                            "shar:productId" => $id,
                            "shar:partId" => $partId,
                            "shar:mediaType" => "Image",
                            "shar:cultureName" => Config::CULTURE_NAME
                        ]
                    ]
                ]
            ]
        ];

        return $this->sendRequest( $this->wsdlMedia, $body );
    }

    /**
     * Retrieves the inventory levels and future availability of a product.
     * If method is `GetFilterValues` it returns all available sizes and colours.
     *
     * @param string|int $productId
     * @param string $method
     * @return array
     * @throws \Exception
     */
    public function fetchInventory( $productId, $method = 'GetInventoryLevelsRequest' ): array
    {
        $auth = $this->getCredential()->getAuth();
        $api_version = "2.0.0";
        $ns = "http://www.promostandards.org/WSDL/Inventory/2.0.0/";
        $shar = "http://www.promostandards.org/WSDL/Inventory/2.0.0/SharedObjects/";
        $body = [
            "soapenv:Envelope"  =>  [
                "xmlns:soapenv" => "http://schemas.xmlsoap.org/soap/envelope/",
                "xmlns:ns" => $ns,
                "xmlns:shar" => $shar,
                [
                    "soapenv:Header" => [],
                    "soapenv:Body" => [
                        "ns:{$method}" => [
                            "shar:wsVersion" => $api_version,
                            "shar:id" => $auth[Credential::AUTH_ID],
                            "shar:password" => $auth[Credential::AUTH_PASSWORD],
                            "shar:productId" => $productId,
                        ]
                    ]
                ]
            ]
        ];

        return $this->sendRequest( $this->wsdlInventory2, $body );
    }

    /**
     * @param string $uri
     * @return void
     */
    protected function constructEndpoints($uri)
    {
        $this->wsdl =  "{$uri}productData/service/index.php";
        $this->wsdl2 = "{$uri}productData2/service/index.php";
        $this->wsdlMedia = "{$uri}media/service/index.php";
        $this->wsdlInventory = "{$uri}inventory/InventoryService.svc";
        $this->wsdlInventory2 = "{$uri}inventory-2-0/service/index.php";
        $this->wsdlPricing = "{$uri}productConfig/service/index.php";
    }
}
