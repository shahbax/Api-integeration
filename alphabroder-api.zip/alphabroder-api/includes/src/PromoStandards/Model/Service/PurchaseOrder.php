<?php
namespace Alphabroder\PromoStandards\Model\Service;

use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\Credential;

class PurchaseOrder extends AbstractService
{
    const ORDER_TYPE_BLANK = 'BLANK';
    const ORDER_TYPE_CONFIGURED = 'CONFIGURED';
    /**
     * WSDL Purchase ORDER
     *
     * @var string
     */
    protected $wsdlPO;

    /**
     * WSDL Order Status
     *
     * @var string
     */
    protected $wsdlOrderStatus;

    /**
     * Constructs the WSDL endpoints.
     *
     * @param string $uri
     * @return void
     */
    protected function constructEndpoints($uri)
    {
        $this->wsdlPO =  "{$uri}purchaseOrder/service/index.php";
        $this->wsdlOrderStatus = "{$uri}orderStatus-1-0/service/index.php";
    }

    public function SendPO( \WC_Order $order )
    {
        $auth = $this->getCredential()->getAuth();
        $api_version = "1.0.0";
        $ns = "http://www.promostandards.org/WSDL/PO/1.0.0/";
        $shar = "http://www.promostandards.org/WSDL/PO/1.0.0/SharedObjects/";
        $body = [
            "soapenv:Envelope" => [
                "xmlns:soapenv" => "http://schemas.xmlsoap.org/soap/envelope/",
                "xmlns:ns" => $ns,
                "xmlns:shar" => $shar,
                [
                    "soapenv:Header" => [],
                    "soapenv:Body" => [
                        "ns:SendPORequest" => [
                            "shar:wsVersion" => $api_version,
                            "shar:id" => $auth[Credential::AUTH_ID],
                            "shar:password" => $auth[Credential::AUTH_PASSWORD],
                            "ns:PO" => [
                                "ns:orderType" => self::ORDER_TYPE_CONFIGURED,
                                "ns:orderNumber" => $order->get_order_number(),
                                "ns:orderDate" => $order->get_date_created(),
                                "ns:totalAmount" => $order->get_total(),
                                "ns:paymentTerms" => "",
                                "ns:rush" => "FALSE",
                                "shar:currency" => Config::CURRENCY,
                                "ns:ShipmentArray" => [
                                    "shar:Shipment" => [
                                        "shar:comments" => "1",
                                        "shar:allowConsolidation" => "TRUE",
                                        "shar:blindShip" => "FALSE",
                                        "shar:packingListRequired" => "FALSE",
                                        "shar:FreightDetails" => [
                                            "shar:carrier" => "UPS",//$order->get_shipping_methods(),
                                            "shar:service" => "Surface"
                                        ],
                                        "shar:ShipTo" => [
                                            "shar:shipmentId" => "1",//$order->get_shipment
                                            "shar:customerPickup" => "TRUE",
                                            "shar:ContactDetails" => [
                                                "shar:attentionTo" =>   'Shoptimals Limited',/*$order->get_billing_first_name() . " "
                                                    .   $order->get_billing_last_name()*///,
                                                "shar:companyName" =>   'InkBombSociety ShoptimalsLtd',//$order->get_billing_company(),
                                                "shar:address1" =>   '12 Lucky Lane',//$order->get_billing_address_1(),
                                                "shar:address2" =>  '',// $order->get_billing_address_2(),
                                                "shar:address3" => "",
                                                "shar:city" =>   'Brampton',//$order->get_billing_city(),
                                                "shar:region" =>   'ON',//$order->get_billing_state(),
                                                "shar:postalCode" =>   'L6R 3M3',//$order->get_billing_postcode(),
                                            ],
                                        ],
                                    ],
                                ],
                                "ns:LineItemArray" => $this->getLineItems( $order ),
                                "ns:termsAndConditions" => "TAndC",
                                "ns:salesChannel"  => "",
                            ],
                        ]
                    ],
                ]
            ]
        ];

        return $this->sendRequest( $this->wsdlPO, $body );
    }

    protected function getLineItems( $order )
    {
        $line_items = ["ns:LineItem" => []];
        /**
         * @var int $item_id
         * @var \WC_Order_Item $item
         */
        foreach( $order->get_items( $this->getTypes() ) as $item_id => $item ) {
            if ($item->is_type('line_item')) {
                $product = new \WC_Product_Variable( $item->get_product()->get_parent_id() );
                /** @var \WC_Order_Item_Product $item */

                $variationId = $item->get_variation_id();
                $variation = new \WC_Product_Variation( $variationId );

                $line_items["ns:LineItem"][] = [
                    "ns:lineNumber" => $item->get_id(),
                    "shar:description" => $item->get_name(),
                    "ns:lineType" => "New",
                    "shar:fobId" => "",
                    "shar:ToleranceDetails" => [
                        "shar:tolerance" => "AllowUnderrun"
                    ],
                    "ns:allowPartialShipments" => "TRUE",
                    "ns:lineItemTotal" => $item->get_total(),
                    "shar:productId" => $product->get_sku(),
                    "ns:PartArray" => [
                        "shar:Part" => [
                            "shar:partGroup" => "1",
                            "shar:partId" => $variation->get_sku(),
                            "shar:customerSupplied" => "TRUE",
                            "shar:Quantity" => [
                                "shar:uom" => "EA",
                                "shar:value" => $item->get_quantity()
                            ]
                        ]
                    ],
                ];
            }
        }

        return $line_items;
    }

    protected function getTypes()
    {
        return array( 'line_item' );
        #return array( 'line_item', 'fee', 'shipping', 'coupon' );
    }
}