<?php
namespace Alphabroder\PromoStandards\Model;

class Category extends \InkbombCore\Model\Category
{
    public function add( $name )
    {
        $category = $this->getIdByName( $name );
        if ( !empty( $category ) ) {
            return $category;
        }

        return wp_insert_term(
            $name,
            'product_cat',
            array(
                'description' => 'Alphabroder Category',
                'parent' => 0,
                'slug' => sanitize_title( $name ),
            )
        );
    }
}