<?php
namespace Alphabroder\PromoStandards\Controllers\Admin\Importer;

use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\CronSchedules;

class Product
{
    public function begin_import()
    {
        if (is_admin() && isset( $_POST['allow_act'] )) {
            if ( !$_POST['allow_act'] ) {
                die();
            }

            $this->updateImportOption( 1 );
            wp_schedule_event(
                time(),
                CronSchedules::EVERY_TWO_SECONDS,
                \Alphabroder\PromoStandards\Cron\Import\Product::HOOK_NAME
            );
            do_action( "init_alphabrorder_import" );
            wp_send_json(["scheduled" => "okay"]);
            die();
        }

    }

    public function reset_import()
    {
        if (is_admin() && isset( $_POST['refresh_req'] )) {
            $options = get_option( Config::IMPORT_OPTIONS );
            if ( isset( $options[Config::OPTIONS_PROMOSTANDARDS] )
                && isset($options[Config::OPTIONS_PROMOSTANDARDS]['read_line'])
            )  {
                unset($options[Config::OPTIONS_PROMOSTANDARDS]['read_line']);
                update_option( Config::IMPORT_OPTIONS, $options );
            }

            wp_send_json(["stopped" => "okay"]);
        }

        die();
    }

    public function stop_import()
    {
        if (is_admin() && isset( $_POST['disallow_act'] )) {
            $action = $_POST['disallow_act'];
            if ( $action ) {
                add_filter('allow_' . \Alphabroder\PromoStandards\Cron\Import\Product::HOOK_NAME, function ( $bool ) {
                    return false;
                });

                $productImporter = new \Alphabroder\PromoStandards\Cron\Import\Product();
                $productImporter->clearScheduler( 1 );
            }

            wp_send_json(["stopped" => "okay"]);
            die();
        }

        die();
    }

    public function is_cron_in_progress()
    {
        if (is_admin() && isset( $_POST['is_in_progress'] )) {
            $progress = 1;
            if ( !Config::isImportingCronInProgress()) {
                $progress = 0;
            }

            wp_send_json(["in_progress" => $progress]);
            die();
        }

        die();
    }

    public function get_import_total()
    {
        if ( !is_admin() ) {
            die();
        }

        $productModel = new \Alphabroder\PromoStandards\Model\Product();
        $productIds = $productModel->getAlphaBroderProductIds();
        wp_send_json( array(
            "total_imported" => (!empty( $productIds ) ? count($productIds): 0),
        ) );
        die();
    }

    private function updateImportOption( $val )
    {
        if ( !in_array( $val, [1,2] ) ) {
            throw new \Exception( "invalid action provided." );
        }

        $options = get_option( Config::IMPORT_OPTIONS );
        $options[Config::OPTIONS_PROMOSTANDARDS]['importing'] = $val;
        update_option( Config::IMPORT_OPTIONS, $options );
    }
}