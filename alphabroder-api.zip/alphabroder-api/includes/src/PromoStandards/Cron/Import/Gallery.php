<?php
namespace Alphabroder\PromoStandards\Cron\Import;

use Alphabroder\PromoStandards\Cron\SchedulerInterface;
use Alphabroder\PromoStandards\Hook\Logger;

class Gallery extends AbstractProduct implements SchedulerInterface
{
    const IMPORT_CRON = 'alphabroder_gallery_import';
    const IMPORT_CSV = 'gallery_import.csv';
    const CLASS_TYPE = array(
        "1001" => "Blank",
        "1007" => "Front",
        "2000" => "Standard Definition",
        "2001" => "High Definition",
    );

    public function execute()
    {
        $id = $this->getUnProcessedProductId( self::IMPORT_CSV );
        if ( !$id ) {
            $this->clearNextSchedule( self::IMPORT_CRON );
            do_action( "completed_alphabrorder_gallery_import" );
            return;
        }

        try {
            $this->import($id);
        } catch (\Exception $e) {
            Logger::log( "[Gallery]: Failed to import the Gallery for ID {$id}."
                . PHP_EOL . " Message: {$e->getMessage()}" );
        }

        Logger::log( "[Gallery]: Marking the product in csv" );
        $this->getProduct()->markImportedProductsInCsv(self::IMPORT_CSV, $id);
        Logger::log( "[Gallery]: Mark completed." );
    }

    /**
     * Import the gallery
     *
     * @param int $productId
     */
    public function import( $productId )
    {
        $product = new \WC_Product_Variable( $productId );
        if ( !$product->get_id() ) {
            Logger::log( "[Gallery]: Product not found. Cannot process the Gallery api request at this time." );
            return;
        }

        Logger::log ("[Gallery]: Requesting Gallery images for product with ID `{$productId}`");
        try {
            $result = $this->getProductData()->fetchMediaGallery( $product->get_sku() );
        } catch (\Exception $e) {
            Logger::log( $e->getMessage() );
            return;
        }
        Logger::log ("Request completed.");
        if ( !isset( $result['Body'] )
            || !isset( $result['Body']['GetMediaContentResponse'] )
            || !isset( $result['Body']['GetMediaContentResponse']['MediaContentArray'] )
            || !isset( $result['Body']['GetMediaContentResponse']['MediaContentArray']['MediaContent'] )
        ) {
            //throw new \Exception ("import failed"); // @todo: add additional actions.
            Logger::log( "Could not import Gallery images for Product {$product->get_id()}" );
            return;
        }

        $mediaContent = $result['Body']['GetMediaContentResponse']['MediaContentArray']['MediaContent'];
        foreach ( $mediaContent as $item ) {
            $this->addMediaContentToVariation( $item );
        }
    }

    /**
     * Upload media content to the variation.
     *
     * @param array $contentArray
     */
    public function addMediaContentToVariation( $contentArray )
    {
        // Verify the media content is high resolution image.
        $classType = $contentArray[ 'ClassTypeArray' ][ 'ClassType' ];
        if ( empty( array_search( self::CLASS_TYPE[ "2001" ], array_column( $classType, "classTypeName" ) ) ) ) {
            return;
        }

        if ( isset($contentArray[ 'mediaType' ]) && $contentArray[ 'mediaType' ] != "Image" ) {
            Logger::log( "Not a media content" );
            return;
        }

        $variation = $this->getProduct()->getVariationBySku( $contentArray[ 'partId' ] );
        if ( !$variation || !$variation->get_id() ) {
            Logger::log( "Could not find variation with SKU `{$contentArray[ 'partId' ]}`" );
            return;
        }

        $existing_image_id = $variation->get_image_id();
        if ( $existing_image_id instanceof \WP_Error ) {
            Logger::log("[Gallery]: Resolving error with image.");
            $variation->set_image_id( null );
            $variation->save();
        } elseif ( is_numeric($existing_image_id) ) {
            wp_delete_attachment($existing_image_id,true);
        }

        $image_url = $contentArray[ 'url' ];
        $fullName = basename($image_url);
        Logger::log( "[Gallery]: Fetching high definition image for variation SKU `{$variation->get_sku()}`." );
        file_put_contents(  ABSPATH . 'wp-content/uploads/' . $fullName, file_get_contents($image_url) );
        $file = array();
        $file['name'] = $fullName;
        $file['tmp_name'] = ABSPATH . 'wp-content/uploads/' . $fullName;
        $file['type'] = wp_check_filetype(ABSPATH . 'wp-content/uploads/' . $fullName);
        Logger::log("[Gallery]: Copying and uploading image to server.");
        $imageId = media_handle_sideload($file, $variation->get_id());
        $variation->set_image_id( $imageId );
        $variation->save();
        Logger::log("[Gallery]: Image update completed.");
    }
}