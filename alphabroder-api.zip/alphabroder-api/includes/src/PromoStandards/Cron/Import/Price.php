<?php
namespace Alphabroder\PromoStandards\Cron\Import;

use Alphabroder\PromoStandards\Cron\SchedulerInterface;
use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\Product;

class Price extends AbstractProduct implements SchedulerInterface
{
    const IMPORT_CRON = 'alphabroder_price_import';
    const IMPORT_CSV = 'price_import.csv';

    /**
     * Process all configuration
     */
    public function execute()
    {
        $id = $this->getUnProcessedProductId( self::IMPORT_CSV );
        if ( !$id ) {
            $this->clearNextSchedule( self::IMPORT_CRON );
            Logger::log( "[Price]: Completed price Import" );
            do_action( "completed_alphabrorder_price_import" );
            return;
        }

        try {
            $this->import($id);
        } catch (\Exception $e) {
            $this->addLog( "[Price]: Failed to import the price for ID {$id}."
                . PHP_EOL . " Message: {$e->getMessage()}" );
            // Continue next steps, as we need to perform next steps.
        }

        $this->addLog( "[Price]: Marking the product in csv" );
        $this->getProduct()->markImportedProductsInCsv(self::IMPORT_CSV, $id);
        $this->addLog( "[Price]: Mark completed." );
    }

    public function import( $productId )
    {
        $product = new \WC_Product_Variable( $productId );
        if ( !$product->get_id() ) {
            $this->addLog( "[Price]: Product not found. Cannot process the price update api request at this time." );
            return;
        }

        $this->addLog ("[Price]: Requesting variation");
        try {
            $result = $this->getProductData()->fetchPricingData($product->get_sku());
        } catch (\Exception $e) {
            $this->addLog( "[Price]: Error: {$e->getMessage()}" );
            return;
        }
        $this->addLog("[Price]: Request completed.");
        $serviceMethod = 'GetConfigurationAndPricingResponse';
        if ( !isset( $result['Body'] ) || !isset( $result['Body'][$serviceMethod] ) ) {
            throw new \Exception ("import failed"); // @todo: add additional actions.
        }

        if ($this->isServiceMessage($serviceMethod, self::IMPORT_CRON)) {
            return;
        }

        if ( !isset($result['Body'][$serviceMethod]['Configuration']) ) {
            $this->addLog('[Price]: ' . json_encode($result['Body']));
            return;
        }

        $priceData = $result['Body'][$serviceMethod]['Configuration'];
        $partArray = $priceData[ 'PartArray' ][ 'Part' ];
        foreach ( $partArray as $part ) {
            $this->importProductPartArray( $product, $part, false );
        }
    }

    public function importProductPartArray( \WC_Product_Variable $product, $part, $allowAdditionalValue = true )
    {
        if ( !isset( $part['PartPriceArray'] ) || $part['PartPriceArray']['PartPrice']['priceUom'] != Config::UOM_CA) {
            return;
        }

        $this->addLog("[Price]: Processing product variation. The product SKU is {$product->get_sku()} and ID is: {$product->get_id()}");
        $thisPart = $part['PartPriceArray']['PartPrice'];
        $variation = $this->getProduct()->getVariationBySku( $part['partId'] );
        $isNewVariation = false;
        if ( !$variation ) {
            $this->addLog( "[Price]: Variation with SKU `{$part['partId']}` not found. Adding it as a new variation." );
            $isNewVariation= true;
        }

        $variation = parent::importProductPartArray( $product,  $part, $isNewVariation );
        $this->addLog( "[Price]: Updating variation with SKU `{$part['partId']}` and id {$variation->get_id()}" );
        $variation->set_regular_price( $thisPart['price'] );
        $variation->save();
        if ( isset( $thisPart[ Product::PRICE_EFFECTIVE_DATE ] ) ) {
            $this->getProduct()->setVariationPriceEffectiveDate( $variation->get_id(), $thisPart[ Product::PRICE_EFFECTIVE_DATE ] );
        }

        // Set price expiry date.
        if ( isset( $thisPart[ Product::PRICE_EXPIRY_DATE ] ) ) {
            $this->getProduct()->setVariationPriceExpiryDate( $variation->get_id(), $thisPart[ Product::PRICE_EXPIRY_DATE ] );
        }
    }
}