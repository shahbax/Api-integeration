<?php
namespace Alphabroder\PromoStandards\Cron\Import;

use Alphabroder\PromoStandards\Cron\SchedulerInterface;
use Alphabroder\PromoStandards\Hook\Logger;

class Inventory extends AbstractProduct implements SchedulerInterface
{
    const IMPORT_CRON = 'alphabroder_inventory2_import';
    const IMPORT_CSV = 'inventory_import.csv';

    /**
     * Execute the Inventory import request.
     */
    public function execute()
    {
        $nextProductId = $this->getUnProcessedProductId( self::IMPORT_CSV );
        if ( !$nextProductId ) {
            $this->clearNextSchedule( self::IMPORT_CRON );
            do_action( 'completed_alphabrorder_inventory_import' );
            return;
        }

        try {
            $this->import( $nextProductId );
        } catch (\Exception $e) {
            Logger::log( "[Inventory]: Inventory import failed for ID {$nextProductId}."
                . PHP_EOL . " Message: {$e->getMessage()}" );
        }

        Logger::log( "[Inventory]: Marking the product in csv" );
        $this->getProduct()->markImportedProductsInCsv(self::IMPORT_CSV, $nextProductId);
        Logger::log( "[Inventory]: Mark completed." );
    }

    /**
     * Import the Next expected product.
     *
     * @param int|string|null $nextProductId
     * @throws \WC_Data_Exception
     */
    public function import( $nextProductId )
    {
        $product = new \WC_Product_Variable( $nextProductId );
        if ( !$product->get_id() ) {
            Logger::log( "[Inventory]: Product not found. Cannot process the inventory update api request at this time." );
            return;
        }

        Logger::log ("[Inventory]: Requesting Inventory 2.0");
        try {
            $result = $this->getProductData()->fetchInventory( $product->get_sku() );
        } catch (\Exception $e) {
            Logger::log( "[Inventory]: Error: {$e->getMessage()}" );
            return;
        }
        Logger::log ("[Inventory]: Request completed.");
        if ( !isset( $result['Body'] ) || !isset( $result['Body']['GetInventoryLevelsResponse'] ) ) {
            throw new \Exception ("import failed"); // @todo: add additional actions.
        }

        $serviceMethod = 'GetInventoryLevelsResponse';
        if ($this->isServiceMessage($serviceMethod)) {
            return;
        }

        if ( !isset($result['Body'][$serviceMethod]['Inventory']) ) {
            Logger::log('[Inventory]: ' . json_encode($result['Body']));
            return;
        }

        $inventory = $result['Body'][$serviceMethod]['Inventory'];
        if ( !isset( $inventory['PartInventoryArray'] ) || !isset( $inventory['PartInventoryArray']['PartInventory'] ) ) {
            Logger::log( "[Inventory]: Error in inventory response. Reason: incomplete data." );
        }

        $partInventoryArray = $inventory['PartInventoryArray']['PartInventory'];
        Logger::log( "[Inventory]: Processing PartInventory Array for Product `{$product->get_id()}`" );
        foreach ( $partInventoryArray as  $partInventory ) {
            $this->addInventoryData( $partInventory );
        }

        // Publish current product.
        $product->set_status( 'publish' );
        $product->set_catalog_visibility( 'visible' );
        $product->save();
    }

    /**
     * Add inventory data to the variations.
     *
     * @param array $partInventory
     * @throws \WC_Data_Exception
     */
    public function addInventoryData( $partInventory )
    {
        $variation = $this->getProduct()->getVariationBySku( $partInventory[ 'partId' ] );
        if ( !$variation || !$variation->get_id() ) {
            Logger::log( "[Inventory]: Could not find variation with SKU `{$partInventory[ 'partId' ]}`" );
            return;
        }

        if ( (string)$partInventory['mainPart'] != "true" ) {
            Logger::log( "[Inventory]: Not a main inventory part for Variation `{$partInventory['partId']}`" );
            return;
        }

        if ( !isset( $partInventory['InventoryLocationArray'] )
            || !isset( $partInventory['InventoryLocationArray']['InventoryLocation'] )
        ) {
            Logger::log( "[Inventory]: Inventory location array not found for Variation `{$partInventory['partId']}`" );
            return;
        }

        $inventoryLocationArray = $partInventory['InventoryLocationArray']['InventoryLocation'];
        $inventoryLocationQty = 0;
        if ( isset( $inventoryLocationArray['inventoryLocationQuantity'] )
            &&  isset($inventoryLocationArray['inventoryLocationQuantity']['Quantity'])
            && isset($inventoryLocationArray['inventoryLocationQuantity']['Quantity']['value'])
        ) {
            $inventoryLocationQty = $inventoryLocationArray['inventoryLocationQuantity']['Quantity']['value'];
        }

        $variation->set_status( 'publish' );
        $variation->set_stock_status( ($inventoryLocationQty > 0) ? 'instock': 'outofstock');
        $variation->set_catalog_visibility( 'visible' );
        $variation->set_manage_stock( true );
        $variation->set_stock_quantity( $inventoryLocationQty );
        $variation->save();
    }
}