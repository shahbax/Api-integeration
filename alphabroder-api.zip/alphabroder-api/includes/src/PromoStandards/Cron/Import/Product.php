<?php
namespace Alphabroder\PromoStandards\Cron\Import;

use Alphabroder\PromoStandards\Cron\SchedulerInterface;
use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\Config;

class Product extends AbstractProduct implements SchedulerInterface
{
    const HOOK_NAME = 'alphabroder_importer';

    protected $read_ids = [];

    public function execute()
    {
        if ( $this->getImporterFlag() == "completed_alphabrorder_import") {
            Logger::log( "ProductDataImport: Waiting for next process to be completed" );
            return;
        }

        if ( !apply_filters( 'allow_' . self::HOOK_NAME, true )
            || !$this->verifyImportProcessing()
        ) {
            Logger::log( "Stopping the Product Data cron." );
            $this->clearScheduler();
            return;
        }

        Logger::log("Starting Product Data Import execution");
        $range = $this->getProcessedRange();
        $start = 1;
        $end = 201;

        if ( !empty( $range ) ) {
            $start = $range[ 1 ] + 1;
            $end = $start + ceil( $range[1] - $range[0] );
        }

        $spreadsheet = $this->getSpreadsheet( $start ,$end);
        $sheet = $spreadsheet->getActiveSheet();
        $data = $sheet->toArray();
        $processed = false;
        foreach ( $data as $value ) {
            if ( empty(array_filter( $value, function ($a) { return $a !== null; } )) ) {
                continue;
            }

            $processed = true;
            try {
                $this->addNewColumn($value);
            } catch (\Exception $e) {
                Logger::log("IMPORT ERROR: " . $e->getMessage());
                Logger::log( "Stopping import process" );
                $processed = false;
            }
        }

        $next_process = false;
        if ( $processed ) {
            /**
             * Import next schedule.
             */
            Logger::log("Product data request processing completed.");
            // Do action for next request in order to allow remaining apis.
            $this->setImporterFlag( "completed_alphabrorder_import" );
            do_action( "completed_alphabrorder_import" );
        } else {
            Logger::log("Stopping Alphabroder Cron process");
            $this->clearScheduler();

            // Reset on exception.
            if ( !empty( $range ) ) {
                $start = $range[ 0 ];
                $end = $range[1];
            }
        }

        $this->setOptions( array(
            "read_line" => array(
                "start" => $start,
                "end" => $end,
            ),
            "next_process" => $next_process
        ) );
    }

    /**
     * Import the Style Column.
     *
     * @param mixed $column
     * @throws \WC_Data_Exception
     * @throws \Exception
     */
    public function addNewColumn( $column )
    {
        if ( empty( $column ) || !is_array( $column ) || !isset( $column[1] )) {
            return;
        }

        $productId = $column[1];
        // Skip if column already processed.
        if ( in_array( $productId, $this->read_ids ) ) {
            //Logger::log ("skipping similar");
            return;
        }

        $this->read_ids[] = $productId;
        // Skip if product already exists
        if ( wc_get_product_id_by_sku( $productId ) ) {
            Logger::log ("product `{$productId}` already exists. Updating..");
        }

        $result = $this->getProductData()->fetchProductData( $productId );
        if ( !isset( $result['Body'] ) || !isset( $result['Body']['GetProductResponse'] ) ) {
            throw new \Exception ("import failed"); // @todo: add additional actions.
        }

        if ( isset( $result['Body']['GetProductResponse']['ServiceMessageArray'] )
            && isset( $result['Body']['GetProductResponse']['ServiceMessageArray']['ServiceMessage'] )
        ) {
            $serviceMessage = $result['Body']['GetProductResponse']['ServiceMessageArray']['ServiceMessage'];
            // @todo: add logger here.
            /**
             *  [code] => 400
             *  [description] => Product Id is unavailable for sale.
             *  [severity] => Error
             */
            Logger::log ( "Product ID = {$productId}: " . $serviceMessage['description'] );
            return;
        }

        $data = $result['Body']['GetProductResponse']['Product'];
        /**
         * Process Import new product.
         */
        $product = $this->import($data);
        if ( !$product || !$product->get_id() ) {
            // @todo: Add a failure logger here.
            Logger::log ("continue; {$productId}" .  json_encode( $column ));
            return;
        }

        Logger::log ("Import done for {$product->get_sku()} and with wp id: {$product->get_id()}");
    }

    /**
     * Import the requested product.
     *
     * @param array $data
     * @return \WC_Product_Variable
     * @throws \WC_Data_Exception
     */
    public function import( $data )
    {
        $categories = array();
        $is_new_import = true;
        if ( isset($data['ProductCategoryArray'])
            && $data['ProductCategoryArray']['ProductCategory']
            && $data['ProductCategoryArray']['ProductCategory']['category']
        ) {
            $productCategoryArray = $data['ProductCategoryArray']['ProductCategory']['category'];
            if ( is_string($productCategoryArray) ) {
                $categories [] = $this->getCategory()->add( $productCategoryArray );
            } else {
                foreach ( $productCategoryArray as $categoryItem ) {
                    $categories [] = $this->getCategory()->add( $productCategoryArray );
                }
            }
        }

        $productId = wc_get_product_id_by_sku( $data['productId'] );
        if ( $productId ) {
            $is_new_import = false;
        }

        $product = new \WC_Product_Variable( $productId );
        $product->set_name( $data['productName'] );
        $marketing_description = "";
        if ( isset( $data['ProductMarketingPointArray'] )
            && isset( $data['ProductMarketingPointArray']['ProductMarketingPoint'] )
        ) {
            $productMarketingPoint = [];
            foreach ($data['ProductMarketingPointArray']['ProductMarketingPoint'] as $marketing ) {
                $productMarketingPoint[ $marketing['pointType'] ][] = $marketing['pointCopy'];
            }

            foreach ($productMarketingPoint as $key => $points) {
                $marketing_description .= "<h2>{$key}</h2>";
                $marketing_description .= "<ul>";
                foreach ( $points as  $point) {
                    $marketing_description .= "<li>{$point}</li>";
                }
                $marketing_description .= "</ul>";
            }
        }

        if ( empty( $marketing_description ) ) {
            $marketing_description .= $data['description'];
        }

        $product->set_description( $marketing_description );
        $product->set_sku( $data['productId'] );
        $product->set_category_ids( $categories );
        $product->set_status( 'importing' );
        $product->set_catalog_visibility( 'hidden' );
        $product->save();

        // Mark the product as Alphabroder
        update_post_meta( $product->get_id(), \Alphabroder\PromoStandards\Model\Product::ALPHABRODER_PRODUCT, 1 );
        // Import variations
        if ( !isset($data['ProductPartArray']) ) {
            Logger::log( "Part Array not found." );
            return $product;
        }

        $attributes = [
            "Colour" => [],
            "Size" => []
        ];
        foreach ( $data['ProductPartArray']['ProductPart'] as $parts )
        {
            if ( !in_array($parts['ColorArray']['Color']['colorName'], $attributes['Colour']) )
                $attributes['Colour'][] = $parts['ColorArray']['Color']['colorName'];

            if ( !in_array($parts['ApparelSize']['labelSize'], $attributes['Size']) )
                $attributes['Size'][] = $parts['ApparelSize']['labelSize'];
        }

        $attribute_object = [];
        foreach ($attributes as $key => $attribute) {
            $new_attribute = new \WC_Product_Attribute();
            $new_attribute->set_name( $key );
            $new_attribute->set_options( $attribute );
            $new_attribute->set_visible(1);
            $new_attribute->set_variation(1);
            $attribute_object[ $key ] = $new_attribute;
        }

        $product->set_attributes( $attribute_object );

        $product->set_status( $is_new_import ? 'publish' : 'draft' ); //draft
        $product->set_catalog_visibility( 'visible' );
        $product->save();

        foreach ( $data['ProductPartArray']['ProductPart'] as $parts ) {
            $this->importProductPartArray( $product, $parts );
        }

        return $product;
    }

    /*public function importProductPartArray( \WC_Product_Variable $product, $part, $allowAdditionalValue = true )
    {
        $variable = $this->getProduct()->getVariationBySku( $part['partId'] );
        if ( !$variable ) {
            return false;
        }/var/www/html/extended-patterns/m2/m2instance/public_html/app/code/XP/Miscellaneous/view/adminhtml/web/css/images/switcher

        return parent::importProductPartArray( $product, $part );
    }*/

    /**
     * Verify the import processing.
     *
     * @return bool
     */
    private function verifyImportProcessing()
    {
        $options = $this->getOptions();
        if (isset($options[Config::OPTIONS_PROMOSTANDARDS])
            && isset($options[Config::OPTIONS_PROMOSTANDARDS]['importing'])
            && ($options[Config::OPTIONS_PROMOSTANDARDS]['importing'] == 1)) {
            return true;
        }

        $this->clearScheduler();
        return false;
    }

    /**
     * Clear the scheduled cron.
     *
     * @param int|bool $force
     */
    public function clearScheduler( $force = 0 )
    {
        if ( wp_next_scheduled( self::HOOK_NAME ) ) {
            wp_clear_scheduled_hook( self::HOOK_NAME );
        }
        $options = $this->getOptions();
        if ( !isset($options[Config::OPTIONS_PROMOSTANDARDS]) || !isset($options[Config::OPTIONS_PROMOSTANDARDS]['importing'])) {
            //return;
        }

        $options[Config::OPTIONS_PROMOSTANDARDS]["importing"] = 2;
        $this->setOptions($options[Config::OPTIONS_PROMOSTANDARDS]);

        if ( !$force ) {
            do_action( "completed_alphabrorder_import" );
        }

        parent::clearScheduler( $force );
    }

    /**
     * Retrieve the processed range.
     *
     * @return array|int[]
     */
    private function getProcessedRange()
    {
        $options = $this->getOptions();
        if ( !isset( $options[ Config::OPTIONS_PROMOSTANDARDS ] )
            || !isset( $options[ Config::OPTIONS_PROMOSTANDARDS ]['read_line'] )
            || !isset( $options[ Config::OPTIONS_PROMOSTANDARDS ]['read_line']['start'] )
            || !isset( $options[ Config::OPTIONS_PROMOSTANDARDS ]['read_line']['end'] )
        ) {
            // start, end
            return [];
        }

        return [
            $options[ Config::OPTIONS_PROMOSTANDARDS ]['read_line']['start'],
            $options[ Config::OPTIONS_PROMOSTANDARDS ]['read_line']['end'],
        ];
    }
}