<?php
namespace Alphabroder\PromoStandards\Cron\Import;

use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\Category;
use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Model\PhpSpreadsheet\ReadFilter;
use Alphabroder\PromoStandards\Model\Service\ProductData;

class AbstractProduct
{
    /**
     * @var ProductData
     */
    protected $productData;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var Category
     */
    protected $category;

    /**
     * @var \Alphabroder\PromoStandards\Model\Product
     */
    protected $product;

    /**
     * @var Price
     */
    private $priceImporter;

    /**
     * @var array
     */
    private array $options = [];

    /**
     * @var string
     */
    protected $inputFileType = 'Xlsx';

    /**
     * @var string
     */
    protected $inputFileName = ALPHABRODER_PATH . 'assets/Color Reference Guide.xlsx';

    /**
     * @var string
     */
    protected $skipImportText = "An import request is already active.";

    protected $logFile = 'alphbroder_importer';

    protected $logFileMode = 'a';

    private $importerFlag = 'importer_flag.csv';

    public function __construct()
    {
        if ( !function_exists( 'media_handle_sideload' )
            || !function_exists( 'media_sideload_image' )
        ) {
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }
    }

    public function importProductPartArray( \WC_Product_Variable $product, $part, $allowAdditionalValue = true )
    {
        $variation = $this->getProduct()->getVariationBySku( $part['partId'] );
        if ( !$variation ) {
            $variation = new \WC_Product_Variation();
        }

        $variation->set_parent_id( $product->get_id() );
        $variation->set_sku( $part['partId'] );
        $description = isset( $part['description'] ) ? $part['description']
            : (isset( $part['partDescription'] ) ? $part['partDescription'] : "");
        $variation->set_description( $description );

        if ( $allowAdditionalValue ) {
            $variation->set_catalog_visibility( 'hidden' );
            $variation->set_stock_status( 'outofstock' );
            $variation->set_manage_stock( true );
            $variation->set_stock_quantity( 0 );
        }

        // Set the dimensions.
        if ( isset( $part['Dimension'] ) ) {
            $variation->set_length( isset( $part['Dimension']['depth'] ) ? $part['Dimension']['depth']: "" );
            $variation->set_width( isset( $part['Dimension']['width'] ) ? $part['Dimension']['width']: "" );
            $variation->set_height( isset( $part['Dimension']['height'] ) ? $part['Dimension']['height']: "" );
            $variation->set_weight( isset( $part['Dimension']['weight'] ) ? $part['Dimension']['weight']: "" );
        }
        $variation->save();
        if ( isset( $part['ColorArray'] ) ) {
            update_post_meta( $variation->get_id(), 'attribute_colour',  $part['ColorArray']['Color']['colorName']);
        }
        if ( isset( $part['ApparelSize'] ) ) {
            update_post_meta( $variation->get_id(), 'attribute_size',  $part['ApparelSize']['labelSize']);
        }

        $partGroup = ["partGroup", "partGroupRequired", "partGroupDescription", "defaultPart"];
        foreach ( $partGroup as $pGroup ) {
            if ( !isset( $part[$pGroup] ) ) {
                continue;
            }

            update_post_meta( $variation->get_id(), $pGroup,  $part[$pGroup]);
        }

        if ( isset( $part['ratio'] ) ) {
            update_post_meta( $variation->get_id(), 'ratio',  $part['ratio']);
        }
        return $variation;
    }

    public function clearScheduler( $force = 0 )
    {
        if ( !$force ) {
            Logger::log("Skip clearing the schedulers.");
            return;
        }

        $importers = [
            Price::IMPORT_CRON,
            Inventory::IMPORT_CRON,
            Gallery::IMPORT_CRON,
        ];

        foreach ( $importers as $importer ) {
            if ( wp_next_scheduled( $importer ) ) {
                wp_clear_scheduled_hook( $importer );
            }
        }
    }

    protected function getSpreadsheet($start, $end)
    {
        /**  Create a new Reader of the type defined in $inputFileType  **/
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($this->inputFileType);
        $filterSubset = new ReadFilter( $start, $end );
        /**  Tell the Reader that we want to use the Read Filter  **/
        $reader->setReadFilter( $filterSubset );
        /**  Load only the rows and columns that match our filter to Spreadsheet  **/
        $this->spreadSheet = $reader->load( $this->inputFileName );
        return $this->spreadSheet;
    }

    /**
     * Get all options.
     *
     * @return array
     */
    protected function getOptions()
    {
        //if ( empty( $this->options ) ) {
            $this->options = Config::getImportOptions();
            if ( !isset( $this->options[ Config::OPTIONS_PROMOSTANDARDS ]  ) ) {
                $this->options[ Config::OPTIONS_PROMOSTANDARDS ] = [];
            }
            //$this->options = isset( $configOptions['promostandard_products'] ) ? $configOptions['promostandard_products'] : [];
        //}
        return $this->options;
    }

    protected function setOptions( $options )
    {
        if ( empty( $options ) ) {
            return;
        }

        $this->options[ 'promostandard_products' ] = array_merge($this->options['promostandard_products'], $options);
        update_option( Config::IMPORT_OPTIONS, $this->options );
    }

    /**
     * Checks if current import request is active.
     *
     * @return bool
     */
    protected function hasActiveImportRequest(): bool
    {
        if ( wp_next_scheduled( Product::HOOK_NAME ) ) {
            return true;
        }

        return false;
    }

    protected function clearNextSchedule( $name )
    {
        if ( wp_next_scheduled( $name ) ) {
            wp_clear_scheduled_hook( $name );
        }
    }

    /**
     * @param string $csv_file
     * @return false|mixed
     */
    protected function getUnProcessedProductId( $csv_file )
    {
        $results = $this->getProduct()->getAlphaBroderProductIds();
        if ( !count($results) ) {
            Logger::log( "No products found." );
            return false;
        }

        $productIds = $this->getProduct()->getImportedProductsData($csv_file);
        if ( !empty( $productIds ) ) {
            foreach ( $results as $result ) {
                if ( !in_array( $result['post_id'], $productIds ) ) {
                    $id = $result['post_id'];
                    break;
                }
            }

            if ( empty( $id ) ) {
                Logger::log( "No product to import." );
                return false;
            }
        } else {
            $id = $results[0]['post_id'];
        }

        return $id;
    }

    /**
     * Checks if response contains the service message.
     *
     * @param string $requestedMethod
     * @param string|null $cronName
     * @return bool
     */
    protected function isServiceMessage( $requestedMethod, $cronName = '' )
    {
        if ( isset( $result['Body'][$requestedMethod]['ServiceMessageArray'] )
            && isset( $result['Body'][$requestedMethod]['ServiceMessageArray']['ServiceMessage'] )
        ) {
            $serviceMessage = $result['Body'][$requestedMethod]['ServiceMessageArray']['ServiceMessage'];
            /**
             *  [code] => 400
             *  [description] => Product Id is unavailable for sale.
             *  [severity] => Error
             */
            Logger::log ( $serviceMessage['description'] );
            return true;
        }

        return false;
    }

    /**
     * @return \Alphabroder\PromoStandards\Model\Product
     */
    protected function getProduct()
    {
        if ( empty( $this->product ) ) {
            $this->product = new \Alphabroder\PromoStandards\Model\Product();
        }

        return $this->product;
    }

    /**
     * @return ProductData
     */
    protected function getProductData()
    {
        if ( empty( $this->productData ) ) {
            $this->productData = new ProductData( $this->getConfig() );
        }

        return $this->productData;
    }

    protected function getCategory()
    {
        if ( empty( $this->category ) ) {
            $this->category = new Category();
        }

        return $this->category;
    }

    /**
     * Get Config
     *
     * @return Config
     */
    protected function getConfig()
    {
        if ( empty( $this->config ) ) {
            $this->config = new Config();
        }
        return $this->config;
    }

    /**
     * @param string $text
     */
    protected function addLog( $text )
    {
        Logger::log( $text, $this->logFileMode, $this->logFile );
    }

    public function getImporterFlag()
    {
        $file = ALPHABRODER_PATH . 'assets/' . $this->importerFlag;
        if ( !file_exists( $file ) ) {
            return false;
        }

        $rows = file_get_contents( $file );
        $rows = explode(PHP_EOL, $rows);
        return isset( $rows[1] ) ? $rows[1] : false;
    }

    public function setImporterFlag( $flag )
    {
        $file = ALPHABRODER_PATH . 'assets/' . $this->importerFlag;
        if ( !$flag ) {
            if ( !file_exists( $file ) ) {
                unlink( $file );
            }
            return;
        }

        $handler = fopen( $file, 'w' );
        fwrite($handler, "flag" . PHP_EOL . $flag );
        fclose($handler);
    }

    /**
     * @return Price
     */
    private function getPriceImporter()
    {
        if ( empty( $this->priceImporter ) ) {
            $this->priceImporter = new Price();
        }

        return $this->priceImporter;
    }
}