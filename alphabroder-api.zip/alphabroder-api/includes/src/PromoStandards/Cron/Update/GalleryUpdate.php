<?php
namespace Alphabroder\PromoStandards\Cron\Update;

use Alphabroder\PromoStandards\Cron\Import\Gallery;
use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\CronSchedules;

class GalleryUpdate extends Gallery
{
    const CRON_NAME = 'alphabroder_gallery_update_12hours';
    const CRON_UPDATE = 'alphabroder_gallery_update';
    const UPDATE_CSV = 'gallery_update.csv';

    public function update()
    {
        Logger::log( "[Gallery Update]: Begin gallery update" );
        // First Stop the cron Steps update (if running)
        $this->clearNextSchedule( self::CRON_UPDATE );

        $id = $this->getUnProcessedProductId( self::UPDATE_CSV );
        if ( !$id ) {
            // Delete the logger, if exists.
            $csvFile = ALPHABRODER_PATH . 'assets/' . self::UPDATE_CSV;
            if ( file_exists( $csvFile ) ) {
                unlink( $csvFile );
            }
        }

        // Run the cron update schedule.
        if ( !wp_next_scheduled( self::CRON_UPDATE ) ) {
            wp_schedule_event( time(), CronSchedules::EVERY_TWO_SECONDS, self::CRON_UPDATE );
        }
    }

    public function execute()
    {
        $id = $this->getUnProcessedProductId( self::UPDATE_CSV );
        if ( !$id ) {
            $this->clearNextSchedule( self::UPDATE_CSV );
            do_action( "completed_alphabrorder_gallery_update" );
            return;
        }

        try {
            $this->import($id);
        } catch (\Exception $e) {
            Logger::log( "[Gallery Update]: Failed to import the Gallery for ID {$id}."
                . PHP_EOL . " Message: {$e->getMessage()}" );
        }

        Logger::log( "[Gallery Update]: Marking the product in csv" );
        $this->getProduct()->markImportedProductsInCsv(self::UPDATE_CSV, $id);
        Logger::log( "[Gallery Update]: Mark completed." );
    }
}