<?php
namespace Alphabroder\PromoStandards\Cron\Update;

use Alphabroder\PromoStandards\Cron\Import\Inventory;
use Alphabroder\PromoStandards\Hook\Logger;
use Alphabroder\PromoStandards\Model\CronSchedules;

class InventoryUpdate extends Inventory
{
    const CRON_NAME = 'alphabroder_inventory2_update_hourly';
    const CRON_UPDATE = 'alphabroder_inventory2_update';
    const UPDATE_CSV = 'inventory_update.csv';

    /**
     * Execute the Inventory update action.
     */
    public function execute()
    {
        $nextProductId = $this->getUnProcessedProductId( self::UPDATE_CSV );
        if ( !$nextProductId ) {
            $this->clearNextSchedule( self::CRON_UPDATE );
            do_action( 'completed_alphabrorder_inventory_update' );
            return;
        }

        try {
            $this->import( $nextProductId );
        } catch (\Exception $e) {
            Logger::log( "[Inventory Update]: Inventory Update failed for ID {$nextProductId}."
                . PHP_EOL . " Message: {$e->getMessage()}" );
        }

        Logger::log( "[Inventory Update]: Marking the product in csv" );
        $this->getProduct()->markImportedProductsInCsv( self::UPDATE_CSV, $nextProductId );
        Logger::log( "[Inventory Update]: Mark completed." );
    }

    /**
     * Process the cron update.
     */
    public function update()
    {
        Logger::log( "[Inventory Update]: Begin inventory update" );
        // First Stop the cron Steps update (if running)
        $this->clearNextSchedule( self::CRON_UPDATE );
        $nextProductId = $this->getUnProcessedProductId( self::UPDATE_CSV );
        if ( !$nextProductId ) {
            // Delete the completed files.
            $csvFile = ALPHABRODER_PATH . 'assets/' . self::UPDATE_CSV;
            if ( file_exists( $csvFile ) ) {
                unlink( $csvFile );
            }
        }

        // Run the cron update schedule.
        if ( !wp_next_scheduled( self::CRON_UPDATE ) ) {
            wp_schedule_event( time(), CronSchedules::EVERY_TWO_SECONDS, self::CRON_UPDATE );
        }
    }
}