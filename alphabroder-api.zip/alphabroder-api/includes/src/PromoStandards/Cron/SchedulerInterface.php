<?php
namespace Alphabroder\PromoStandards\Cron;

interface SchedulerInterface
{
    public function execute();
}