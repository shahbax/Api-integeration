<?php
namespace Alphabroder\PromoStandards\Hook\Admin\Settings;

use Alphabroder\PromoStandards\Hook\Admin\Settings;

/**
 * Renderer renders the fields based on provided data.
 */
class Renderer extends \InkbombCore\Hook\Settings\Renderer
{

    /**
     * Renders the field based on provided data.
     *
     * @param array $data
     */
    public function render( $data )
    {
        if ( !isset( $data['section_id'] ) ) {
            $data['section_id'] = Settings::SECTION_ID;
            $data['option_name'] = Settings::OPTION_NAME;
        }

        parent::render( $data );
    }
}