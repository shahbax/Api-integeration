<?php
namespace Alphabroder\PromoStandards\Hook\Admin;

use Alphabroder\PromoStandards\Model\Config;
use Alphabroder\PromoStandards\Views\Renderer;

/**
 * Alphabroder Admin settings
 */
class Settings extends \InkbombCore\Hook\AbstractSettings
{
    const OPTION_GROUP = 'alphabroder_settings';
    const OPTION_NAME = 'alphabroder_settings';
    const SECTION_ID = 'alphabroder_settings_section';
    const PAGE_NAME = 'alphabroder_settings_page';
    const OPTION_AUTH_ID = 'auth_id';
    const OPTION_AUTH_PWD = 'auth_password';
    const OPTION_LOGGING = 'allow_log';
    const OPTION_APPMODE = 'appmode';

    /**
     * @var \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer
     */
    private $fieldRenderer;

    /**
     * @var Config
     */
    private $config;

    /**
     * Construct the request and init the register settings.
     */
    public function __construct()
    {
        add_action( 'admin_init', array( $this, 'register' ) );
    }

    /**
     * Add Alphabroder as submenu under inkbomb main menu.
     */
    public function add_submenu_page()
    {
        $page_hook = add_submenu_page(
            'inkbomb-sinalite-settings',
            __('Alphabroder', 'alphabroder'),
            __('Alphabroder API ', 'alphabroder'),
            'manage_options',
            'alphaborder-api-settings',
            array($this, 'displaySettingPage'),
            50
        );
    }

    /**
     * Register the settings for Alphabroder.
     */
    public function register()
    {
        // Register setting
        register_setting( self::OPTION_GROUP, self::OPTION_NAME );
        // Add setting section
        add_settings_section( self::SECTION_ID, 'Alphabroder Settings', function () {}, self::PAGE_NAME );
        $fields = array(
            array(
                "field_id" => "_fld_" . self::OPTION_AUTH_ID,
                "title" => "Auth ID",
                "callback" => function () {
                    $this->getFieldRenderer()->render(
                        array(
                            'field_id' => '_fld_' . self::OPTION_AUTH_ID,
                            'name' => self::OPTION_AUTH_ID,
                            'value' => $this->getConfig()->getAuthId(),
                        )
                    );
                }
            ),
            array(
                "field_id" => "_fld_" . self::OPTION_AUTH_PWD,
                "title" => "Auth Password",
                "callback" => function () {
                    $this->getFieldRenderer()->render(
                        array(
                            'field_id' => '_fld_' . self::OPTION_AUTH_PWD,
                            'name' => self::OPTION_AUTH_PWD,
                            'value' => $this->getConfig()->getPassword(),
                            'type' => \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer::INPUT_PASSWORD
                        )
                    );
                },
            ),
            array(
                "field_id" => "_fld_" . self::OPTION_APPMODE,
                "title" => "Credentials Environment",
                "callback" => function () {
                    $this->getFieldRenderer()->render(
                        array(
                            'field_id' => '_fld_' . self::OPTION_APPMODE,
                            'name' => self::OPTION_APPMODE,
                            'value' => $this->getConfig()->getAppMode(),
                            'type' => \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer::SELECT,
                            'class' => '',
                            'options' => array(
                                "developer" => Config::APP_MODE_DEVELOPER,
                                "production" => Config::APP_MODE_PRODUCTION
                            ),
                        )
                    );
                },
            ),
            array(
                "field_id" => "_fld_" . self::OPTION_LOGGING,
                "title" => "Enable log",
                "callback" => function () {
                    $this->getFieldRenderer()->render(
                        array(
                            'field_id' => '_fld_' . self::OPTION_LOGGING,
                            'name' => self::OPTION_LOGGING,
                            'value' => $this->getConfig()->isLogEnabled(),
                            'type' => \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer::SELECT,
                            'class' => '',
                            'options' => array(
                                "0" => "No",
                                "1" => "Yes",
                            ),
                        )
                    );
                },
            ),
        );

        foreach ( $fields as $field ) {
            $this->add_field( $field['field_id'], $field['title'], $field['callback'] );
        }
    }

    /**
     * Renders the settings page
     */
    public function displaySettingPage()
    {
        Renderer::render('admin/settings.php', [
            'title' => get_admin_page_title()
        ]);
    }

    /**
     * @return \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer
     */
    protected function getFieldRenderer()
    {
        if ( empty( $this->fieldRenderer ) ) {
            $this->fieldRenderer = new \Alphabroder\PromoStandards\Hook\Admin\Settings\Renderer();
        }
        return $this->fieldRenderer;
    }

    /**
     * @return Config
     */
    private function getConfig()
    {
        if ( empty ( $this->config ) ) {
            $this->config = new Config();
        }

        return $this->config;
    }
}