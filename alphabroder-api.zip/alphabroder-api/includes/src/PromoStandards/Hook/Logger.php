<?php
namespace Alphabroder\PromoStandards\Hook;

use Alphabroder\PromoStandards\Hook\Admin\Settings;

final class Logger extends \InkbombCore\Logger\InkbombLogger
{
    /**
     * @param string $entry
     * @param string $mode
     * @param string $filename
     * @return false|int
     */
    public static function log( $entry, $mode = 'a', $filename = 'alphbroder_importer' )
    {
        $setting = get_option( Settings::OPTION_NAME );
        if ( empty( $setting ) || !isset( $setting[Settings::OPTION_LOGGING] )) {
            return false;
        }

        if ( !(int)$setting[Settings::OPTION_LOGGING] ) {
            return false;
        }

        return parent::log( $entry, $mode, $filename );
    }
}