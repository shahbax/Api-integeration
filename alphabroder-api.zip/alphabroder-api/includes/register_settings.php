<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function alphabroder_register_settings() {
    register_setting( 'alphabroder_options', 'alphabroder_options' );
}