<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists( 'inkbomb_alphabroder_deactivation' ) ) {
    function inkbomb_alphabroder_deactivation()
    {
        // 1. Deactivate all Alphabroder running cron jobs.
        alphabroder_uninstall_cron_jobs();
    }
}