<?php

use Alphabroder\PromoStandards\Hook\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists('inkbomb_alphabroder_activation') ) {
    function inkbomb_alphabroder_activation () {
        // Truncate the log
        Logger::log("");
        // Register and execute the Inventory update.
        alphabroder_update_price_fn();
        alphabroder_update_gallery_fn();
        alphabroder_update_inventory_fn();
    }
}