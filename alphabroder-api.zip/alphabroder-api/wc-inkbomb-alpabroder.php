<?php
/**
 * Plugin Name: Inkbomb Alphabroder API
 * Plugin URI: https://inkbomb.ca/
 * Description: Alphabroder API integration.
 * Version: 1.0.0
 * Author: Inkbomb
 * Author URI: https://inkbomb.ca/
 * Developer: Arsalan
 * Developer URI: https://arsalanajmal.com/
 * Text Domain: alphabroder
 *
 * WC requires at least: 3.5
 * WC tested up to: 6.9
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( !function_exists('add_action') ) {
    echo "No direct access allowed";
    exit();
}

/**
 * Version Checking
 */
if ( version_compare( get_bloginfo('version'), '4.0', '<' ) ) {
    $message = 'Plugin is not supported for the version less than 4.0';
    die($message);
}

/**
 * Constants
 */
define('ALPHABRODER_PATH', plugin_dir_path(__FILE__ ));
define('ALPHABRODER_URI', plugin_dir_url( __FILE__ ));

/**
 * Check if woocommerce is activated
 */
if ( in_array('woocommerce/woocommerce.php',
    apply_filters('active_plugins', get_option('active_plugins'))
) ) {
    #require ( ABSPATH . 'wp-content/plugins/inkbomb-commerce/includes/guzzlehttp/vendor/autoload.php' );
    require ( ABSPATH . 'wp-content/plugins/inkbomb-core/includes/lib/guzzlehttp/vendor/autoload.php');
    require ( ABSPATH . 'wp-content/plugins/inkbomb-core/includes/core/autoloader.php');
    require ( ALPHABRODER_PATH . 'lib/phpspreadsheet/vendor/autoload.php');
    require ( ALPHABRODER_PATH . '/includes/autoloader.php');

    if ( !class_exists( 'Inkbomb_Alphabroder' ) ) {
        class Inkbomb_Alphabroder
        {
            public function __construct()
            {
                /**
                 * Include files
                 */
                $this->include_files();

                /**
                 * Add hooks and filters.
                 */
                $this->add_hooks_and_filters();

                // register cron schedules
                $this->register_cron_schedules();
            }

            public function include_files()
            {
                /**
                 * Include the cron hooks first.
                 */
                $this->add_dir_files_to_require( array (
                    "cron_hooks"
                ), 'includes');

                /**
                 * Register alphabroder cron hooks
                 */
                register_alphabroder_cron();

                $this->add_dir_files_to_require( array (
                    "activation",
                    "deactivation"
                ), 'includes');
            }

            public function add_hooks_and_filters()
            {
                // Register activation hook.
                register_activation_hook(__FILE__, 'inkbomb_alphabroder_activation');

                // Deactivation hook
                register_deactivation_hook( __FILE__ , 'inkbomb_alphabroder_deactivation');

                // Add submenu
                add_action('admin_menu', array(new \Alphabroder\PromoStandards\Hook\Admin\Settings(), 'add_submenu_page'), 100);

                /**
                 * Product import actions.
                 */
                $product_controller = new \Alphabroder\PromoStandards\Controllers\Admin\Importer\Product();
                add_action( 'wp_ajax_stop_alphabroder_import', array( $product_controller, 'stop_import'));
                add_action( 'wp_ajax_begin_alphabroder_import', array($product_controller, 'begin_import'));
                add_action( 'wp_ajax_reset_alphabroder_import', array($product_controller, 'reset_import'));
                add_action( 'wp_ajax_is_alphabroder_cron', array($product_controller, 'is_cron_in_progress'));
                add_action( 'wp_ajax_alphabroder_import_total', array($product_controller, 'get_import_total'));
            }

            /**
             * Register the cron schedules that need to run.
             */
            public function register_cron_schedules()
            {
                // Run a logic when Product import is initialized.
                add_action( "init_alphabrorder_import", 'init_alphabrorder_import_fn' );
                // Run next job after completing the Product import request.
                add_action( "completed_alphabrorder_import", "after_completed_alphabrorder_import" );
                // Perform next operation after completing the Price Import request.
                add_action( "completed_alphabrorder_price_import", 'after_completed_alphabrorder_price_import' );
                // Add action after completing the Gallery import request.
                add_action( 'completed_alphabrorder_gallery_import', 'after_completed_alphabrorder_gallery_import' );
                // Add action after completing the Inventory import request.
                add_action( 'completed_alphabrorder_inventory_import', 'after_completed_alphabrorder_inventory_import' );
            }

            private function add_dir_files_to_require($files, $dir)
            {
                if (empty($files) || !is_array($files)) {
                    return;
                }

                if (strpos($dir, "/") != 0) {
                    $dir = "/" . $dir;
                }

                if (strcmp($dir[-1], "/") != 0) {
                    $dir .= "/";
                }

                foreach ($files as $file) {
                    require ( ALPHABRODER_PATH . $dir . $file . ".php" );
                }
            }
        }

        $inkbomb_alphabroder = new Inkbomb_Alphabroder();
    }
}