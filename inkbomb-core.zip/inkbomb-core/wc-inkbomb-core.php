<?php
/**
 * Plugin Name: Inkbomb Core
 * Plugin URI: https://inkbomb.ca/
 * Description: Inkbomb Core plugin, contains central code and settings.
 * Version: 1.0.0
 * Author: Inkbomb
 * Author URI: https://inkbomb.ca/
 * Developer: Arsalan
 * Developer URI: https://arsalanajmal.com/
 * Text Domain: inkbomb_core
 *
 * WC requires at least: 3.5
 * WC tested up to: 7.1
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */

if ( !function_exists('add_action') ) {
    echo "No direct access allowed";
    exit();
}

/**
 * Version Checking
 */
if ( version_compare( get_bloginfo('version'), '4.0', '<' ) ) {
    $message = 'Plugin is not supported for the version less than 4.0';
    die($message);
}

/**
 * Constants
 */
define('INKBOMB_CORE_PATH', plugin_dir_path(__FILE__ ));
define('INKBOMB_CORE_URI', plugin_dir_url( __FILE__ ));
define( 'INKBOMB_CORE_DOMAIN', 'inkbomb_core');
/**
 * Check if woocommerce is activated
 */
if ( !in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {
    die("Woocommerce must be active before activating the Inkbomb plugins.");
}

// Includes
require ( INKBOMB_CORE_PATH . 'includes/lib/guzzlehttp/vendor/autoload.php' );
require (INKBOMB_CORE_PATH . 'includes/core/autoloader.php');
require( INKBOMB_CORE_PATH . '/includes/core.php' );
require( INKBOMB_CORE_PATH . '/includes/admin/inkbomb_page_menu.php' );

// Hooks
// Inkbomb menu registration
add_action('admin_menu', 'inkbomb_core_page_menu', 99);
add_action( 'admin_init', 'inkbomb_core_admin_init' );
register_inkbomb_cron();