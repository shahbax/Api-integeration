<?php
namespace InkbombCore\Model;

/**
 * Options configurations
 */
class Config
{
    /**
     * Returns the Configuration array
     *
     * @param string $optionName
     * @param string|null $filterIndex
     * @return array
     */
    public function getConfigArray( $optionName, $filterIndex = '' ): array
    {
        $options = get_option( $optionName );
        if ( empty( $filterIndex ) ) {
            return ( !empty( $options ) ) ? $options : [];
        }

        return ( isset( $options[ $filterIndex ] )) ? $options : [];
    }
}