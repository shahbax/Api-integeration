<?php
namespace InkbombCore\Model;

class Schedule
{
    const EVERY_FIFTEEN_SECONDS = 'inkbomb_every_fifteen_seconds';

    public function after_fifteen_seconds( $schedules )
    {
        $schedules [ static::EVERY_FIFTEEN_SECONDS ] = array(
            "interval" => 15,
            "display" => esc_html__( __('Inkbomb Cron every fifteen seconds scheduler' )  ),
        );
        return $schedules;
    }
}