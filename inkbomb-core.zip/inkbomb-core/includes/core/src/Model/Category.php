<?php
namespace InkbombCore\Model;

class Category
{
    public function getIdByName( $name )
    {
        $category = get_term_by( 'name', $name, 'product_cat' );
        return !empty( $category ) ? $category->term_id : null;
    }

    public function add( $name )
    {
        $category = $this->getIdByName( $name );
        if ( !empty( $category ) ) {
            return $category;
        }

        return wp_insert_term(
            $name,
            'product_cat',
            array(
                'description' => $name,
                'parent' => 0,
                'slug' => sanitize_title( $name ),
            )
        );
    }
}