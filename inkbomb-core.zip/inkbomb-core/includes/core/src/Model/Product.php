<?php
namespace InkbombCore\Model;

class Product
{
    public function __construct()
    {
        if ( !function_exists( 'media_handle_sideload' )
            || !function_exists( 'media_sideload_image' )
        ) {
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }
    }
    /**
     * Retrieves all product ids by api product key
     *
     * @param string $key
     * @param string|null $value
     * @return array|object|\stdClass[]|null
     */
    public function getIdsByApiProduct( $key, $value = '' )
    {
        global $wpdb;
        if ( !empty( $value ) ) {
            $value = " AND meta_value = '" . $value . "'";
        }

        $results = $wpdb->get_results( "select post_id from $wpdb->postmeta where meta_key = '"
            . $key . "'" . $value, ARRAY_A );
        return $results;
    }

    /**
     * @param string|int|null $sku
     * @return false|\WC_Product_Variation
     */
    public function getVariationBySku( $sku )
    {
        global $wpdb;
        $results = $wpdb->get_results( "select post_id, meta_key from $wpdb->postmeta where meta_key = '_sku' AND meta_value = '" . $sku . "'", ARRAY_A );
        if ( !count($results) ) {
            return false;
        }

        return new \WC_Product_Variation( $results[0]['post_id'] );
    }

    /**
     * @param \WC_Product|\WC_Product_Variation $product
     * @param string $imageUrl
     */
    public function uploadImgToProduct( $product, $imageUrl )
    {
        $existing_image_id = $product->get_image_id();
        // Resolve existing image.
        if ( $existing_image_id instanceof \WP_Error ) {
            $product->set_image_id( null );
            $product->save();
        } elseif ( is_numeric($existing_image_id) ) {
            wp_delete_attachment($existing_image_id,true);
        }

        $fullName = basename($imageUrl);
        file_put_contents(  ABSPATH . 'wp-content/uploads/' . $fullName, file_get_contents($imageUrl) );
        $file = array();
        $file['name'] = $fullName;
        $file['tmp_name'] = ABSPATH . 'wp-content/uploads/' . $fullName;
        $file['type'] = wp_check_filetype(ABSPATH . 'wp-content/uploads/' . $fullName);
        $imageId = media_handle_sideload($file, $product->get_id());
        $product->set_image_id( $imageId );
        $product->save();
    }
}