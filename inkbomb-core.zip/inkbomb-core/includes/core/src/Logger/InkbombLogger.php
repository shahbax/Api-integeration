<?php
namespace InkbombCore\Logger;

class InkbombLogger
{
    /**
     * @param string $entry
     * @param string $mode
     * @param string $filename
     * @return false|int
     */
    public static function log( $entry, $mode = 'a', $filename = 'inkbomb_log' )
    {
        $uploadDir = wp_upload_dir();
        $uploadDir = $uploadDir['basedir'];
        if ( is_array( $entry ) ) {
            $entry = json_encode( $entry );
        }

        $prefix = "[" . current_time( 'mysql' ) . "]:";
        if ( empty( $entry ) ) {
            $prefix = "";
            $mode = 'w';
        }

        $filename = $uploadDir . "/" . $filename . ".log";
        $filename = fopen( $filename, $mode );

        $bytes = fwrite( $filename, $prefix . $entry . PHP_EOL );
        fclose( $filename );
        return $bytes;
    }
}