<?php
namespace InkbombCore\Hook\Settings;

class Renderer
{
    public const INPUT = 'text';
    public const INPUT_HIDDEN = 'hidden';
    public const INPUT_PASSWORD = 'password';
    public const SELECT = 'select';
    public const MULTISELECT = 'multiselect';
    public const CHECKBOX = 'checkbox';
    public const RADIO = 'radio';

    private $sectionId;

    private $optionName;

    private $fieldData = '';

    /**
     * Renders the field based on provided data.
     *
     * @param array $data
     */
    public function render( $data ) {
        $fieldId = $data['field_id'];
        $name = $data['name'];
        $this->sectionId = $data['section_id'];
        $this->optionName = $data['option_name'];
        $type = isset( $data['type'] ) ? $data['type'] : self::INPUT;
        $value = isset( $data['value'] ) ? $data['value'] : '';
        $class = isset( $data['class'] ) ? $data['class'] : 'regular-text';
        $options = isset( $data['options'] ) ? $data['options'] : array();
        $note = isset( $data['note'] ) ? $data['note'] : '';

        if ( in_array($type, array( 'select', 'multiselect' )) ) {
            $this->fieldData = $this->getSelectField( $fieldId, $name, $options, $value, $class );
        } else {
            $this->fieldData = $this->getInputField($fieldId, $name, $value, $type, $class);
        }

        echo $this->fieldData . $this->addNoteText( $fieldId, $note );
    }

    /**
     * Get Selected Field.
     *
     * @param string $fieldId
     * @param string $name
     * @param array $options
     * @param string $selectedValue
     * @param string $class
     * @return string
     */
    private function getSelectField( $fieldId, $name, $options, $selectedValue, $class )
    {
        $select = "<select id=\"".  $this->sectionId . $fieldId . "\" class=\"" . $class . "\" name=\""
            . $this->optionName . "[" . $name . "]\">";
        foreach ($options as $key => $optionText) {
            $select .= '<option value="' . $key . '" ' . (!empty($selectedValue) && $selectedValue == $key ? "selected": "") . '>' . $optionText . '</option>';
        }
        $select .= "</select>";

        return $select;
    }

    /**
     * Get input / hidden field.
     *
     * @param string|int $fieldId
     * @param string $name
     * @param string $value
     * @param string $type
     * @param string $class
     * @return string
     */
    private function getInputField($fieldId, $name, $value, $type, $class)
    {
        return "<input type=\"{$type}\" id=\"".  $this->sectionId . $fieldId . "\" class=\"" . $class . "\" name=\""
            . $this->optionName . "[" . $name . "]\" value=\""
            . $value . "\"/>";
    }

    /**
     * Returns the field note.
     *
     * @param string $fieldId
     * @param string|null $txt
     * @return string
     */
    private function addNoteText($fieldId, $txt = '')
    {
        return '<div id="field_note_' . $fieldId . '" class="field_note">' . $txt . '</div>';
    }
}