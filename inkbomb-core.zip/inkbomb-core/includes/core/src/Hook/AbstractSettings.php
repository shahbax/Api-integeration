<?php
namespace InkbombCore\Hook;

use InkbombCore\View\Template\Renderer;

abstract class AbstractSettings
{
    const PAGE_NAME = 'inkbomb_settings_page';
    const SECTION_ID = 'inkbomb_settings_section';

    public abstract function register();

    /**
     * Renders the settings page
     */
    public function displaySettingPage()
    {
        Renderer::render('admin/settings.php', [
            'title' => get_admin_page_title()
        ]);
    }

    /**
     * Adds the settings field.
     *
     * @param string|int $id
     * @param string $title
     * @param mixed $callback
     */
    public function add_field($id, $title, $callback)
    {
        add_settings_field(
            $id,
            $title,
            $callback,
            static::PAGE_NAME,
            static::SECTION_ID
        );
    }
}