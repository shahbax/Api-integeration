<?php
namespace InkbombCore\View\Template;

class Renderer
{
    public static function render($template, $data = array())
    {
        $template = static::getTemplateDir() . $template;
        $output = "";
        if (file_exists($template)) {
            // Extract to a local namespace
            extract($data);
            // Start output buffering
            ob_start();
            // Include template file.
            include $template;
            // End buffering
            $output = ob_get_clean();
        }
        echo $output;
    }

    /**
     * @return string
     */
    public static function getTemplateDir(): string
    {
        return INKBOMB_CORE_PATH . 'includes/core/src/View/html/';
    }
}