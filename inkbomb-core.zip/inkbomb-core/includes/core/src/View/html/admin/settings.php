<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap">
    <h1><?php /** @var $title */ echo $title; ?></h1>
</div>
