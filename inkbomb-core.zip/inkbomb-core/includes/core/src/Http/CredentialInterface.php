<?php
namespace InkbombCore\Http;

interface CredentialInterface
{
    /**
     * @return array
     */
    public function getAuth(): array;
}