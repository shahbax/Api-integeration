<?php
namespace InkbombCore\Http;

class Request
{
    /**
     * @var array
     */
    private $options;

    /**
     * @var array
     */
    private $headers;

    /**
     * @var string
     */
    private $method;

    /**
     * @var array|string
     */
    private $body;

    /**
     * @var string
     */
    private $uri;

    /**
     * @param array $options
     * @param array $headers
     * @param array|string $body
     * @param string $method
     * @param string $uri
     */
    public function __construct(
        array $options,
        array $headers,
              $body,
              $method,
              $uri
    ) {
        $this->options = $options;
        $this->headers = $headers;
        $this->body = $body;
        $this->method = $method;
        $this->uri = $uri;
    }

    /**
     * @return array
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @return string
     */
    public function getMethod()
    {
        if (!in_array(strtoupper($this->method), ['POST', 'GET'])) {
            $this->method = 'POST';
        }

        return strtoupper($this->method);
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->headers;
    }

    /**
     * @return array|string
     */
    public function getBody()
    {
        return $this->body;
    }

    /**
     * @return string
     */
    public function getUri()
    {
        return (string) $this->uri;
    }
}