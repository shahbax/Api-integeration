<?php
namespace InkbombCore\Http;

use Exception;

/**
 * Api Request sender
 */
interface ApiInterface
{
    /**
     * Execute the request.
     *
     * @param Request $httpRequest
     * @return array
     * @throws Exception
     */
    public function execute($httpRequest);
}