<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'inkbomb_core_page_menu' ) ) {
    function inkbomb_core_page_menu() {
        add_menu_page(
            __('Sinalite API', INKBOMB_CORE_DOMAIN), // Keep the main menu as Sinalite api
            __('Inkbomb Commerce', INKBOMB_CORE_DOMAIN),
            'manage_options',
            'inkbomb-sinalite-settings',
            'inkbomb_sinalite_setting',
            'dashicons-store',
            49
        );
    }
}