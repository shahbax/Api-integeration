<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists('inkbomb_core_admin_init') ) {
    function inkbomb_core_admin_init()
    {
        wp_enqueue_style('inkbomb-core-admin', INKBOMB_CORE_URI . "assets/css/admin.css", false, '1.1', 'all');
    }
}

if ( !function_exists( 'register_inkbomb_cron' ) ) {
    function register_inkbomb_cron()
    {
        $schedule = new \InkbombCore\Model\Schedule();
        add_filter( 'cron_schedules', array( $schedule, 'after_fifteen_seconds' ) );
    }
}