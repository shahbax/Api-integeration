<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists('write_log') ) {
    function inkbomb_write_log($log)
    {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }
}