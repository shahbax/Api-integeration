<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require(INKBOMB_PATH . '/views/admin/settings_page.php');