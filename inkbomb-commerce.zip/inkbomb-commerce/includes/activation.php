<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists('inkbomb_commerce_activation') ) {
    function inkbomb_commerce_activation() {
        // Default settings
        if ( !get_option('inkbomb_commerce_settings') ) {
            add_option('inkbomb_commerce_settings', array(
                'inkbomb_commerce_label' => 'Inkbomb commerce'
            ));
        }

        // schedule the cron jobs
        /*if ( function_exists( 'as_next_scheduled_action' ) && false === as_next_scheduled_action( 'inkbomb_process_hook' ) ) {
            if ( !wp_next_scheduled( 'inkbomb_cron_hook' ) ) {
                as_schedule_recurring_action( strtotime( 'midnight tonight' ), DAY_IN_SECONDS, 'inkbomb_process_hook' );
            }
        }*/
    }
}


// For Woocommerce 2.5+ (2.6.x and 3.0)
#add_action( 'woocommerce_cart_calculate_fees', 'prefix_add_discount_line', 10, 1 );
/**
 * @param WC_Cart $cart
 * @return void
 */
function prefix_add_discount_line( $cart ) {

    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    $discount = 0;
    // Get the unformated taxes array
    $taxes = $cart->get_taxes();
    // Add each taxes to $discount
    foreach($taxes as &$tax) {
        $tax = 0;
        $discount += $tax;
    }
    $cart->set_cart_contents_taxes($taxes);
    // Applying a discount if not null or equal to zero
    /*if ($discount > 0 && ! empty($discount) )
        $cart->add_fee( __( 'Tax Paid On COD', 'inkbomb' ) , - $discount );*/
}


#add_filter('woocommerce_cart_get_subtotal_tax', 'calc_inkbomb_tax', 10, 1);
#add_filter('woocommerce_cart_get_total_tax', 'calc_inkbomb_tax', 10, 1);
function calc_inkbomb_tax($subtotal_tax)
{
    return 0.87;
}




#####
// Auto Add Tax Depending On Room Per Night Price
#add_action( 'woocommerce_cart_calculate_fees','auto_add_tax_for_room', 10, 1 );
/**
 * @param WC_Cart $cart
 * @return void
 */
function auto_add_tax_for_room( $cart ) {
   // if ( is_admin() && ! defined('DOING_AJAX') ) return;

    $percent = 18;

    // Calculation
    $surcharge = ( $cart->cart_contents_total + $cart->shipping_total ) * $percent / 100;

    // Add the fee (tax third argument disabled: false)
    $cart->add_fee( __( 'TAX', 'woocommerce')." ($percent%)", $surcharge, false );
    $cart->set_subtotal_tax(0);
    $cart->set_total_tax(0);
}
#add_action( 'woocommerce_before_calculate_totals', 'apply_conditionally_taxes', 20, 1 );
/**
 * @param WC_Cart $cart
 * @return void
 */
function apply_conditionally_taxes( $cart ){
    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    foreach( $cart->get_cart() as &$cart_item ) {
        $cart_item['line_tax_data'] = array(
            "subtotal" => array(0.87),
            "total" => array(0.87),
        );
        $cart_item['line_tax'] = 0.87;
        /*echo "<pre />";
        print_r($cart_item['line_tax_data']); exit;
        if( $cart_item['quantity'] >= 6 ){
            $cart_item['data']->set_tax_class('zero-rate');
        }*/
    }
    $cart->set_subtotal_tax("0.87");
    $cart->set_total_tax("0.87");
    return $cart;
    //$cart->
}