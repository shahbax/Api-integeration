<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists('inkbomb_deactivation') ) {
    function inkbomb_deactivation()
    {
        $timestamp = wp_next_scheduled( 'inkbomb_cron_hook' );
        wp_unschedule_event( $timestamp, 'inkbomb_cron_hook' );
    }
}