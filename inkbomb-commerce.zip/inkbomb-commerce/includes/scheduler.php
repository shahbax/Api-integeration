<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !function_exists('inkbomb_add_cron_interval') ) {
    function inkbomb_add_cron_interval( $schedules ) {
        $schedules ['inkbomb_cron_interval'] = array(
            "interval" => (60 * 60) * 12,
            "display" => esc_html__( __('Inkbomb Products Interval' )  ),
        );
        return $schedules;
    }
}

if ( !function_exists('inkbomb_process_hook') ) {
    function inkbomb_process_hook() {
        $sinalite_product_update = new Sinalite_Product_Update_Scheduler();
        $sinalite_product_update->execute();
    }
}