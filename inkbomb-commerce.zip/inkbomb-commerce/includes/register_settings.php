<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function inkbomb_register_settings() {
    ############## General SETTINGS #################
    register_setting( 'inkbomb_options', 'inkbomb_options' );

    /**
     * Add Settings section.
     */
    add_settings_section(
            'inkbomb_general_settings_section',
            'Settings',
            'inkbomb_general_section_text',
            'inkbomb_general_settings_page'
    );

    /**
     * Add Settings section fields.
     */
    add_settings_field(
            'inkbomb_setting_import_categories_field',
            'Import Products for category',
            'inkbomb_setting_import_categories',
            'inkbomb_general_settings_page',
            'inkbomb_general_settings_section'
    );
    add_settings_field(
            'inkbomb_setting_markup_field',
            'Price Markup',
            'inkbomb_setting_price_markup',
            'inkbomb_general_settings_page',
            'inkbomb_general_settings_section'
    );
    add_settings_field(
            'inkbomb_setting_scheduler_field',
            'Enable variation Schedule import',
            'inkbomb_setting_enable_schedule',
            'inkbomb_general_settings_page',
            'inkbomb_general_settings_section'
    );
    /*add_settings_field(
            'inkbomb_setting_allowed_shipping_methods_field',
            'Shipping methods',
            'inkbomb_setting_allowed_shipping_methods',
            'inkbomb_general_settings_page',
            'inkbomb_general_settings_section'
    );*/

    ############## API SETTINGS #################
    /**
     * Register api settings.
     */
    register_setting( 'inkbomb_api_options', 'inkbomb_api_options' );

    /**
     * Add API settings section.
     */
    add_settings_section(
        'inkbomb_api_settings_section',
        'API Settings',
        'inkbomb_section_text',
        'inkbomb_api_settings_page'
    );

    /**
     * Client ID field.
     */
    add_settings_field(
        'inkbomb_setting_client_id',
        'Client ID',
        'inkbomb_setting_client_id',
        'inkbomb_api_settings_page',
        'inkbomb_api_settings_section'
    );

    /**
     * Client Secret.
     */
    add_settings_field(
        'inkbomb_setting_client_secret',
        'Client Secret',
        'inkbomb_setting_client_secret',
        'inkbomb_api_settings_page',
        'inkbomb_api_settings_section'
    );

    /**
     * Environment
     */
    add_settings_field(
        'inkbomb_setting_app_mode',
        'Environment',
        'inkbomb_setting_app_mode',
        'inkbomb_api_settings_page',
        'inkbomb_api_settings_section'
    );

    /**
     * Access token.
     */
    add_settings_field(
        'inkbomb_setting_generated_access_token',
        'Access token',
        'inkbomb_setting_generated_access_token',
        'inkbomb_api_settings_page',
        'inkbomb_api_settings_section'
    );

    wp_enqueue_style('inkbomb-sinalite-settings', INKBOMB_URI . "assets/css/admin.css", false, '1.1', 'all');
}

function inkbomb_options_validate( $input ) {
    $newinput['client_id'] = trim( $input['client_id'] );
    if ( ! preg_match( '/^[a-z0-9]{32}$/i', $newinput['client_id'] ) ) {
        $newinput['client_id'] = '';
    }

    return $newinput;
}

function inkbomb_general_section_text()
{
    echo '<p>Inkbomb Configuration Settings</p>';
}

function inkbomb_setting_import_categories()
{
    global $sinalite_config;
    $orderby = 'name';
    $order = 'asc';
    $hide_empty = false ;
    $cat_args = array(
        'orderby'    => $orderby,
        'order'      => $order,
        'hide_empty' => $hide_empty,
    );

    $product_categories = get_terms( 'product_cat', $cat_args );
    if( !empty($product_categories) ) {
        $selected_options = $sinalite_config->get_category_ids();
        $selected = !empty($selected_options) ? json_decode($selected_options, true) : array();
        echo '<input type="hidden" name="inkbomb_options[import_cats]" id="inkbomb_setting_import_categories" value=\''
            . $selected_options . '\'>';
        echo '<select class="inkbomb_select" multiple="multiple" id="inkbomb_setting_import_categories_select">';
        foreach ($product_categories as $key => $category) {
            echo '<option value="' .  $category->term_id . '" '
                . (in_array($category->term_id, $selected) ? 'selected="selected" ' : '')
                . '>' . $category->name . '</option>';
        }
        echo '</select>';
        ?>
        <script type="text/javascript">
            jQuery(function ($) {
                $("#inkbomb_setting_import_categories_select").on('change', function () {
                    $("#inkbomb_setting_import_categories").val(JSON.stringify($(this).val()));
                });
            });
        </script>
        <?php
    }
}

function inkbomb_setting_price_markup()
{
    /** @var $sinalite_config Inkbomb_Sinalite_Config */
    global $sinalite_config;
    echo '<input type="number" name="inkbomb_options[' .Inkbomb_Sinalite_Config::PRICE_MARKUP . ']" id="inkbomb_setting_import_categories" value=\''
        . $sinalite_config->get_markup_value() . '\' style="width: 75px;"> %';
}

function inkbomb_setting_enable_schedule()
{
    /** @var $sinalite_config Inkbomb_Sinalite_Config */
    global $sinalite_config;
    $options = array(
        0 => "No",
        1 => "Yes",
    );
    $selected = $sinalite_config->is_scheduler_enabled();
    echo '<select class="inkbomb_select" name="inkbomb_options[' .Inkbomb_Sinalite_Config::IS_SCHEDULER_ENABLED . ']" id="inkbomb_setting_import_scheduler_select">';
        foreach ($options as $key => $value) {
            echo "<option value=\"{$key}\"". ($selected == $key ? 'selected="selected"' : '') . ">{$value}</option>";
        }
    echo '</select>';
}

function inkbomb_setting_allowed_shipping_methods() {
    $options = get_option( 'inkbomb_options' );
    $selected_options = isset($options['allowed_shipping_methods']) ? $options['allowed_shipping_methods'] : '';
    $selected = !empty($selected_options) ? json_decode($selected_options, true) : array();
    echo '<input type="hidden" name="inkbomb_options[allowed_shipping_methods]" id="inkbomb_setting_allowed_shipping_methods" value=\'' . $selected_options . '\'>';
    echo '<select class="select2" multiple="multiple" id="inkbomb_setting_allowed_shipping_methods_select">';
    $shipping_method_list = array(
        "UPS Standard" => "UPS Standard",
        "UPS Express" => "UPS Express",
        "UPS Expedited" => "UPS Expedited",
        "UPS Express Saver" => "UPS Express Saver",
        "UPS Worldwide Expedited" => "UPS Worldwide Expedited",
        "UPS Saver" => "UPS Saver",
        "FedEx Standard Overnight" => "FedEx Standard Overnight",
        "FedEx Economy" => "FedEx Economy",
        "FedEx Express Saver" => "FedEx Express Saver",
        "FedEx International Economy" => "FedEx International Economy",
        "FedEx International Priority" => "FedEx International Priority",
    );
    foreach ($shipping_method_list as $key => $shipping_method) {
        echo '<option value="' .  $key . '" '
            . (in_array($key, $selected) ? 'selected="selected" ' : '')
            . '>' . $shipping_method . '</option>';
    }
    echo '</select>';
    ?>
    <script type="text/javascript">
        jQuery(function ($) {
            $("#inkbomb_setting_allowed_shipping_methods_select").on('change', function () {
                $("#inkbomb_setting_allowed_shipping_methods").val(JSON.stringify($(this).val()));
                console.log($("#inkbomb_setting_allowed_shipping_methods").val());
            });
        });
    </script>
    <?php
}


function inkbomb_section_text() {
    echo '<p>Sinalite API configuration and token generation.</p>';
}

function inkbomb_setting_client_id() {
    global $sinalite_config;
    echo "<input id='inkbomb_setting_client_id' name='inkbomb_api_options[client_id]' type='text' value='"
        . esc_attr( $sinalite_config->get_client_id() ) . "' />";
}

function inkbomb_setting_client_secret() {
    global $sinalite_config;
    echo "<input id='inkbomb_setting_client_secret' name='inkbomb_api_options[client_secret]' type='password' value='"
        . esc_attr( $sinalite_config->get_client_secret() ) . "' />";
}

function inkbomb_setting_app_mode() {
    global $sinalite_config;
    $app_modes = array("sandbox" => "Sandbox", "live" => "Live");
    $selected = esc_attr( $sinalite_config->get_app_mode() );
    echo '<select id="inkbomb_setting_app_mode" name="inkbomb_api_options[app_mode]" class="inkbomb_select">';
    foreach ($app_modes as $key => $value) {
        echo '<option value="' . $key . '" ' . (!empty($selected) && $selected == $key ? "selected": "") . '>' . $value . '</option>';
    }
    echo "</select>";
    ?>
    <p id="sandbox_help_text" class="app_mode_text" style="display: none;"><strong>Sandbox url:</strong> api.sinaliteuppy.com</p>
    <p id="live_help_text" class="app_mode_text" style="display: none;"><strong>Live url:</strong> apilive.sinaliteuppy.com</p>
    <script type="text/javascript">
        jQuery(function ($) {
            $('#inkbomb_setting_app_mode').on('change', function () {
                $('.app_mode_text').hide();
                $("#" + $(this).val() + '_help_text').show();
            });

            $('#inkbomb_setting_app_mode').trigger('change');
        });
    </script>
    <?php
}

function inkbomb_setting_generated_access_token()
{
    global $sinalite_config;
    global $sinalite_api;

    $token_value = $sinalite_config->get_generated_access_token();
    $token_type_value = $sinalite_config->get_generated_token_type();
    echo "<input id='inkbomb_setting_generated_access_token' name='inkbomb_api_options[generated_access_token]' type='hidden' value='" .  ( $token_value ) . "' />";
    echo "<input id='inkbomb_setting_generated_access_token_type' name='inkbomb_api_options[generated_access_token_type]' type='hidden' value='"
        .  ( $token_type_value ) . "' />";
    ?>
    <input type="text" id="output_token" value="<?php echo $token_value; ?>" disabled="disabled" />
    <button id="generate_new_access_token" class="button button-primary"><span>Generate</span></button>
    <script type="text/javascript">
        jQuery(function ($) {
            var access_token = '#inkbomb_setting_generated_access_token';

            $("#generate_new_access_token").on('click', function (e) {
                e.preventDefault();
                var settings = <?php
                    $auth_data = array(
                        "client_id" => $sinalite_config->get_client_id(),
                        "client_secret" => $sinalite_config->get_client_secret(),
                        "audience" => Inkbomb_Sinalite_Config::API_AUDIENCE,
                        "grant_type" => Inkbomb_Sinalite_Config::CREDENTIALS_GRANT_TYPE,
                    );
                    $settings = array(
                        //"async" =>  true,
                        "crossDomain" => true,
                        "url" => $sinalite_api->get_api_url() . "/auth/token",
                        "method" => "POST",
                        "headers" => array(
                            "content-type" => "application/json"
                        ),
                        "data" => json_encode($auth_data, JSON_UNESCAPED_SLASHES),
                    );
                    echo json_encode($settings, JSON_UNESCAPED_SLASHES);
                    ?>;
                var auth_data = JSON.parse(settings.data);
                // Set updated values.
                auth_data.client_id = $("#inkbomb_setting_client_id").val();
                auth_data.client_secret = $("#inkbomb_setting_client_secret").val();
                settings.data = JSON.stringify(auth_data);
                $('#generate_new_access_token').attr('disabled', 'disabled');
                $.ajax(settings).done(function (response)
                {
                    $('#generate_new_access_token').removeAttr('disabled');
                    if ( ! response.access_token ) {
                        alert("Error in Authentication");
                        return console.log("Error in Authentication");
                    }

                    $('#inkbomb_setting_generated_access_token_type').val(response.token_type).trigger('click');
                    var response_token =  response.access_token;
                    $(access_token).val(response_token);

                    $("#output_token").val(response_token);
                    $('input[type="submit"]').click();
                });
            })
        });
    </script>
    <?php
}