<?php
/**
 * Plugin Name: Inkbomb Commerce
 * Plugin URI: https://inkbomb.ca/
 * Description: Inkbomb has Sinalite APIs integration.
 * Version: 1.0.0
 * Author: Inkbomb
 * Author URI: https://inkbomb.ca/
 * Developer: Arsalan
 * Developer URI: https://arsalanajmal.com/
 * Text Domain: inkbomb
 *
 * WC requires at least: 3.5
 * WC tested up to: 7.1
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */


if ( !function_exists('add_action') ) {
    echo "No direct access allowed";
    exit();
}

/**
 * Version Checking
 */
if ( version_compare( get_bloginfo('version'), '4.0', '<' ) ) {
    $message = 'Plugin is not supported for the version less than 4.0';
    die($message);
}

/**
 * Constants
 */
define('INKBOMB_PATH', plugin_dir_path(__FILE__ ));
define('INKBOMB_URI', plugin_dir_url( __FILE__ ));

define('INKBOMB_WC_PATH', WP_PLUGIN_DIR . '/woocommerce');
define('INKBOMB_WC_ASSETS_PATH', WP_PLUGIN_DIR . '/woocommerce/assets');

/**
 * Check if woocommerce is activated
 */
if ( in_array('woocommerce/woocommerce.php',
    apply_filters('active_plugins', get_option('active_plugins'))
) ) {

    global $sinalite_config;
    global $sinalite_api;

    require ( ABSPATH . 'wp-content/plugins/inkbomb-core/includes/lib/guzzlehttp/vendor/autoload.php');
    require(INKBOMB_PATH . 'classes/source/inkbomb_sinalite_config.php');
    require(INKBOMB_PATH . 'classes/api/sinalite_api.php');
    $sinalite_config = new Inkbomb_Sinalite_Config();
    $sinalite_api = new Sinalite_api();
    /*if ( version_compare( Constants::get_constant( 'WC_VERSION' ), '3.0', '<' ) ) {
        $message = 'Plugin supports at least Woocomerce 3';
        die($message);
    }*/
    if ( !class_exists('Inkbomb_Commerce') ) {
        class Inkbomb_Commerce
        {
            public function __construct()
            {
                /**
                 * Include files
                 */
                $this->include_files();

                /**
                 * Include classes
                 */
                $this->add_classes();

                /**
                 * Include hooks
                 */
                $this->add_hooks();

                /**
                 * Add Schedule Event.
                 */
                $this->add_schedule_event();
            }

            private function include_files()
            {
                require(INKBOMB_PATH . '/includes/log_writer.php');
                require(INKBOMB_PATH . '/views/admin/settings_page.php');
                require(INKBOMB_PATH . '/includes/register_settings.php');
                require(INKBOMB_PATH . '/includes/scheduler.php');
                require(INKBOMB_PATH . '/includes/activation.php');
                require(INKBOMB_PATH . '/includes/deactivation.php');
            }

            private function add_classes()
            {
                $inkbomb_classes = array(
                    'admin/inkbomb_settings',
                    'catalog/import/sinalite_product_importer',
                    'admin/controllers/inkbomb_product_controller',
                    'pricing/inkbomb_price_calculator',
                    'catalog/sinalite_product',
                    'checkout/inkbomb_shipping',
                    'checkout/inkbomb_cart',
                    'order/inkbomb_order',
                    'order/inkbomb_order_item',
                    'cron/sinalite_product_update_scheduler',
                );

                foreach ($inkbomb_classes as $inkbomb_class) {
                    require( INKBOMB_PATH . "/classes/" . $inkbomb_class . ".php" );
                }
            }

            public function add_hooks()
            {
                register_activation_hook(__FILE__, 'inkbomb_commerce_activation');

                // Inkbomb menu registration
                ###add_action('admin_menu', array(new Inkbomb_settings(), 'add_submenu_page'), 99);
                add_action( 'admin_init', 'inkbomb_register_settings' );
                // Import product ajax request
                add_action( 'wp_ajax_import_inkbomb_product', array(new Inkbomb_product_controller(), 'import_product') );
                add_action( 'wp_ajax_import_inkbomb_product_variation', array(new Inkbomb_product_controller(), 'create_product_variations') );
                // Calculate totals before.
                add_action( 'woocommerce_before_calculate_totals', array( new Inkbomb_Cart(), 'before_calculate_totals' ) );
                //Order processed hook
                $order = new Inkbomb_order();
                add_action( 'woocommerce_checkout_create_order', array($order, 'create_order'), 10, 2 );
                //add_action( 'woocommerce_checkout_order_processed', array(new Inkbomb_order(), 'order_processed'), 10, 1 );
                // Filters
                add_filter( 'woocommerce_countries', array( new Inkbomb_Shipping(), 'filter_woocommerce_countries' ) );
                add_filter( 'woocommerce_states', array( new Inkbomb_Shipping(), 'filter_woocommerce_states' ) );
                add_filter( 'woocommerce_package_rates', array( new Inkbomb_Cart(), 'estimate_shipping' ), 10, 3 );
                add_filter( 'woocommerce_admin_billing_fields', array( new Inkbomb_Order_Item(), 'init_order' ), 10, 1);

                // ################ Sinalite product hooks and filters ################
                //$sinalite_product_instance = new Sinalite_Product();
                add_action('woocommerce_single_product_summary', array( new Sinalite_Product(), 'single_product_summary' ), 35);
                add_filter( 'woocommerce_product_variation_get_price', array( new Sinalite_Product(), 'get_variation_prices' ), 10, 3 );
                add_filter( 'woocommerce_product_variation_get_regular_price', array( new Sinalite_Product(), 'get_variation_prices' ), 10, 3 );
                // ################ END: Sinalite product hooks and filters ################

                // ################ Scheduler hooks and filters ################
                add_filter( 'cron_schedules', 'inkbomb_add_cron_interval' );
                add_action( 'inkbomb_cron_hook', 'inkbomb_process_hook' );
                // ################ END: Scheduler hooks and filters ################

                // Add deactivation
                register_deactivation_hook( __FILE__, 'inkbomb_deactivation' );
            }

            public function add_schedule_event()
            {
                if ( !wp_next_scheduled( 'inkbomb_cron_hook' ) ) {
                    wp_schedule_event( time(), 'inkbomb_cron_interval', 'inkbomb_cron_hook' );
                }
            }
        }

        $inkbomb_commerce = new Inkbomb_Commerce();
    }
}