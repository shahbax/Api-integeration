<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Automattic\WooCommerce\Utilities\NumberUtil;

class Sinalite_Product
{
    const VARIATION_ATTRIBUTE = 'sinalite_variation_attribute';
    const PRODUCT_ID = 'sinalite_product_id';
    const PRICE_HASH_DATA = 'sinalite_price_data';

    /**
     * @var Sinalite_api
     */
    private $sinalite_api;

    /**
     * @var Inkbomb_Price_Calculator
     */
    private $price_calculator;

    public function __construct()
    {
        $this->sinalite_api = new Sinalite_api();
        $this->price_calculator = new Inkbomb_Price_Calculator($this->sinalite_api);
    }

    public function set_sinalite_product_id($product_id, $sinalite_p_id)
    {
        update_post_meta($product_id, self::PRODUCT_ID, esc_attr($sinalite_p_id));
    }

    /**
     * Get Sinalite product ID.
     *
     * @param $product_id
     * @return mixed
     */
    public function get_sinalite_product_id($product_id)
    {
        return get_post_meta($product_id, self::PRODUCT_ID, true);
    }

    public function set_sinalite_price_data($product_id, $price_hash_data)
    {
        if ( is_array( $price_hash_data ) ) {
            $price_hash_data = json_encode($price_hash_data, JSON_UNESCAPED_SLASHES);
        }

        update_post_meta($product_id, self::PRICE_HASH_DATA, $price_hash_data);
    }

    public function set_sinalite_variation($variation_id, $variation)
    {
        if ( is_array($variation) ) {
            $variation = json_encode($variation, JSON_UNESCAPED_SLASHES);
        }

        update_post_meta($variation_id, self::VARIATION_ATTRIBUTE, $variation);
    }

    public function has_sinalite_product($product)
    {
        if (empty($product)) {
            return false;
        }

        if (!$product instanceof WC_Product && !$product instanceof WC_Product_Variable) {
            $product = new WC_Product($product);
            if (!$product->get_id()) {
                return false;
            }
        }

        return (bool)$this->get_sinalite_product_id($product->get_id());
    }

    /**
     * Get Sinalite product variation.
     *
     * @param $variation_id
     * @return mixed
     */
    public function get_sinalite_variation($variation_id)
    {
        $variation = get_post_meta($variation_id, self::VARIATION_ATTRIBUTE, true);
        if (!$variation) {
            return $variation;
        }

        $variation = json_decode($variation, JSON_UNESCAPED_SLASHES);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }

        return $variation;
    }

    public function get_variation_prices( $price, $product )
    {
        if ( !$this->has_sinalite_product( $product ) ) {
            return $price;
        }

        $variation_id = $product->get_id();
        if (empty($variation_id) || !$product->get_attributes()) {
            return $price;
        }

        wc_delete_product_transients($product->get_id());
        $product_id = $this->get_sinalite_product_id($product->get_parent_id());
        $hash_calculated_price = $this->price_calculator->calculate_using_price_hash(
            $product_id,
            $product->get_attributes()
        );
        if ($hash_calculated_price > 0.00) {
            return $hash_calculated_price;
        }

        $variation = $this->get_sinalite_variation($variation_id);
        $price_data = $this->price_calculator->calculate_via_api($product_id, array_values($variation));
        if (isset($price_data['price']) && $price_data['price']) {
            return $price_data['price'];
        }

        return $price;
    }

    public function single_product_summary()
    {
        global $woocommerce, $product;
        if (!$this->has_sinalite_product($product)) {
            return;
        }
        ?>
        <script>
            jQuery(function ($) {
                var product_price = <?php echo (float)$product->get_price(); ?>,
                    current_cart_total = <?php echo $woocommerce->cart->cart_contents_total; ?>,
                    currency = '<?php echo get_woocommerce_currency_symbol(); ?>';

                $('[name=quantity]').change(function () {
                    if (!(this.value < 1)) {
                        var product_total = parseFloat(product_price * this.value),
                            cart_total = parseFloat(product_total + current_cart_total);

                        $('#pt-product-total-price .price').html(currency + product_total.toFixed(2));
                        $('#pt-cart-total-price .price').html(currency + cart_total.toFixed(2));
                    }
                    $('#pt-product-total-price,#pt-cart-total-price').toggle(!(this.value <= 1));

                });

                $( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
                    // Fired when the user selects all the required dropdowns / attributes
                    // and a final variation is selected / shown
                    if ( variation.display_price !== undefined ) {
                        $('.entry-summary .price .woocommerce-Price-amount bdi').html(
                            '<span class="woocommerce-Price-currencySymbol">' + currency + '</span> '
                            + variation.display_price
                        );
                    }
                } );

                $( ".reset_variations" ).on( "click", function (event) {
                    $('.entry-summary .price .woocommerce-Price-amount bdi').html(
                        '<span class="woocommerce-Price-currencySymbol">' + currency + '</span> '
                        + <?php echo NumberUtil::round(
                        0,
                        wc_get_price_decimals()
                    ); ?>
                    );
                } );
            });
        </script>
        <?php
    }

    public function export_csv($product_api_data)
    {
        // Create headers
        $csv = "id,_original_id,name,sku,category" . PHP_EOL;
        foreach ($product_api_data as $product) {
            $csv .= "{$product['id']},{$product['_original_id']},{$product['name']},{$product['sku']},{$product['category']}" . PHP_EOL;
        }

        $handler = fopen( 'sinalite-product-export.csv', 'w' );
        fwrite($handler, $csv);
        fclose($handler);
        file_put_contents( INKBOMB_PATH . 'assets/exports/sinalite-product-export.csv', $csv );
    }

    public function get_csv_data()
    {
        $data = file_get_contents(INKBOMB_PATH . 'assets/exports/sinalite-product-export.csv');
        $rows = explode(PHP_EOL, $data);
        $output = [];
        foreach ($rows as $key => $row) {
            $content = explode(",", $row);
            if (!isset($content[0]) || !isset($content[1]) || !isset($content[2]) || !isset($content[3]) || !isset($content[4])) {
                if ($key == 0 && !empty($row)) {
                    throw new Exception("Invalid CSV input!");
                }

                continue;
            }

            if ($key == 0) {
                continue;
            }

            $output[$content[0]] = array(
                "id" => $content[0],
                "_original_id" => $content[1],
                "name" => $content[2],
                "sku" => $content[3],
                "category" => $content[4],
            );
        }

        return $output;
    }
}