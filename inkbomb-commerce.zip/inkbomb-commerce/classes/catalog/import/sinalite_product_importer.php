<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Sinalite_Product_Importer
{
    /**
     * @var Sinalite_Product
     */
    private $product;

    public function __construct()
    {
        $this->product = new Sinalite_Product();
    }

    public function import_product($product_data, $price_data)
    {
        /** @var $sinalite_config Inkbomb_Sinalite_Config */
        global $sinalite_config;
        $product_id = wc_get_product_id_by_sku($product_data['sku']);
        $this->validate_product_data($product_data);
        $product = new WC_Product_Variable($product_id);
        if (!$product->get_image_id()) {
            $product->set_image_id( $sinalite_config->get_placeholder_attachment_id() );
            $product->set_gallery_image_ids( array( $sinalite_config->get_placeholder_attachment_id() ) );
        }

        $product->set_name($product_data['name']);
        $product->set_sku($product_data['sku']);
        $product->set_description($product_data['name']);
        $cat_name = $product_data['category']; //"Business Cards";
        $category = get_term_by( 'name', $cat_name, 'product_cat' );
        $cat_id = $category->term_id;
        $product->set_category_ids(array($cat_id));
        //Set product status to importing.
        $product->set_status( 'importing' );
        $product->set_catalog_visibility( 'hidden' );
        $product->save();

        // Set Sinalite product id.
        $this->product->set_sinalite_product_id($product->get_id(), $product_data['id']);

        // Import price hash data
        $this->import_price_hash($product_id, $price_data);

        // Read and write the csv
        $csv_data = $this->product->get_csv_data();
        $csv_data[$product_data['id']] = array(
            "id" => $product_data['id'],
            "_original_id" => $product->get_id(),
            "name" => $product_data['name'],
            "sku" => $product_data['sku'],
            "category" => $product_data['category']
        );

        $this->product->export_csv($csv_data);
        // Save attributes.
        $attributes = $this->extract_attributes_from_options_group($price_data[0]);
        $this->import_attributes($product, $attributes);

        // Publish the product changes
        $product->set_catalog_visibility( 'visible' );
        $product->set_status( 'publish' );
        $product->set_stock_status('instock');
        $product->save();
        return $product->get_data();
    }

    public function import_price_hash($product_id, $price_data)
    {
        // Create Price hash data.
        $price_hash_data = array();
        for ($i =0; $i < count($price_data[1]); $i++) {
            $price_hash_data[$price_data[1][$i]['hash']] = $price_data[1][$i]['value'];
        }
        // Set Sinalite Price data.
        $this->product->set_sinalite_price_data($product_id, $price_hash_data);
    }

    public function import_attributes(WC_Product_Variable $product, $attributes)
    {
        global $woocommerce;
        // Reset all attributes
        $product->set_attributes( array() );
        $product->save();
        // Empty all carts
        if (!empty($woocommerce) && !empty($woocommerce->cart)) {
            $woocommerce->cart->empty_cart();
        }

        // Create attributes list.
        $attr_list = array();
        $position = 0;
        foreach ($attributes as $key => $opt) {
            $attribute = new WC_Product_Attribute();
            $attribute->set_name( $key );
            $attribute->set_options( $opt );
            $attribute->set_position( $position );
            $attribute->set_visible( true );
            $attribute->set_variation( true );
            $attr_list[$position] = $attribute;
            $position++;
        }
        $product->set_attributes( $attr_list );
        $product->save();

        // Delete all variations
        $data_store_cpt = new WC_Product_Variable_Data_Store_CPT();
        $data_store_cpt->delete_variations($product->get_id(), true);
    }

    public function extract_attributes_from_options_group($options)
    {
        $attributes = array();
        array_walk($options, function ($item, $key) use (&$attributes) {
            $group = $item['group'];
            $name = $item['name'];
            if (!isset($attributes[$group])) {
                $attributes[$group] = array();
            }

            $attributes[$group] = array_merge($attributes[$group], array($name));
        }, $attributes);

        if (isset($attributes['qty'])) {
            asort($attributes['qty']);
        }

        return $attributes;
    }

    public function import_variations($variations, $price_data, $product)
    {
        if (empty($variations)) {
            return array(
                "success" => true,
                "message" => "no variation found."
            );
        }

        if (!$product instanceof WC_Product_Variable) {
            $product = new WC_Product_Variable($product);
        }

        if (!$product->get_id()) {
            throw new Exception("Product does not exist.");
        }
        //set_time_limit(600);
        // Change product status
        $product->set_status( 'importing' );
        $product->set_catalog_visibility( 'hidden' );
        $product->save();

        // Price groups
        $price_groups = array();
        foreach ($price_data as $data) {
            $price_groups[$data['id']] = $data;
        }

        $imported_count = 0;
        for ($i=0; $i < count($variations); $i++) {
            $variation = explode("-", $variations[$i]['key']);
            $sinalite_variation_attribute = array();
            $options = array();
            for ($j=0; $j < count($variation); $j++) {
                if (empty($price_groups[$variation[$j]])) {
                    continue;
                }
                $options[sanitize_title($price_groups[$variation[$j]]['group'])] = $price_groups[$variation[$j]]['name'];

                $sinalite_variation_attribute = array_merge(
                    $sinalite_variation_attribute,
                    array(
                        $price_groups[$variation[$j]]['group']
                            => $price_groups[
                                $variation[$j]
                        ]['id']
                    )
                );
            }
            if (empty($options)) {
                continue;
            }

            $this->create_a_variation($product, $options, $sinalite_variation_attribute);
            $imported_count++;
        }

        $product->set_catalog_visibility( 'visible' );
        $product->set_status( 'publish' );
        $product->save();
        update_post_meta($product->get_id(), '_stock_status', 'instock');

        return array(
            "success" => true,
            "message" => __("A total of \"{$imported_count}\" variations were imported successfully.", "inkbomb")
        );
    }

    private function create_a_variation(WC_Product_Variable $product, $options, $sinalite_variation_attribute, $price = 0)
    {
        global $wpdb;
        $product_id = $product->get_id();

        $post_excerpt = array();
        foreach ($product->get_attributes() as $attribute) {
            $post_excerpt[$attribute->get_name()] = "{$attribute->get_name()}: " . $options[sanitize_title($attribute->get_name())];
        }

        $post_excerpt = implode(", ", $post_excerpt);

        if ( is_array($sinalite_variation_attribute) ) {
            $sinalite_variation_attribute = json_encode($sinalite_variation_attribute, JSON_UNESCAPED_SLASHES);
        }

        $prefix = $wpdb->prefix;
        /**
         * Insert a new variation post data.
         */
        $wpdb->insert($prefix . 'posts', array(
            "ID" => null,
            "post_author" => get_current_user_id(),
            "post_date" => current_time("mysql"),
            "post_date_gmt" => current_time("mysql", 1),
            "post_content" => "",
            "post_title" => $product->get_name(),
            "post_excerpt" => $post_excerpt,
            "post_status" => "publish",
            "comment_status" => "closed",
            "ping_status" => "closed",
            "post_password" => "",
            "post_name" => $product->get_sku(),
            "to_ping" => "",
            "pinged" => "",
            "post_modified" => current_time("mysql"),
            "post_modified_gmt" => current_time("mysql", 1),
            "post_content_filtered" => "",
            "post_parent" => $product->get_id(),
            "guid" => get_site_url() . "?post_type=product_variation&p=",
            "menu_order" => 0,
            "post_type" => "product_variation",
            "post_mime_type" => "",
            "comment_count" => 0
        ));

        $variation_id = $wpdb->insert_id;
        // Update the `guid` to include the variation id
        $wpdb->update($prefix . 'posts', array(
            "guid" => get_site_url() . "?post_type=product_variation&p=" . $variation_id,
            "post_name" => $product->get_sku() . '_' . $variation_id
        ), array("ID" => $variation_id));
        $variation_metadata = array_merge(
            $this->get_variation_default_meta_data(array('price' => $price)),
            array_combine(
                array_map(function ($key) {
                    return 'attribute_' . $key;
                }, array_keys($options)),
                $options
            )
        );

        foreach ($variation_metadata as $key => $value) {
            $wpdb->insert($prefix . 'postmeta', array(
                "meta_id" => null,
                "post_id" => $variation_id,
                "meta_key" => $key,
                "meta_value" => $value
            ));
        }

        // Finally save the sinalite variation value.
        $this->product->set_sinalite_variation($variation_id, $sinalite_variation_attribute);
        return $variation_id;
    }

    public function get_variation_default_meta_data($data = array())
    {
        return array(
            "_variation_description" => isset($data['description']) ? $data['description'] : "",
            "_regular_price" => isset($data['price']) ? $data['price'] : 0,
            "total_sales" => isset($data['total_sales']) ? $data['total_sales'] : 0,
            "_stock_status" => isset($data['stock_status']) ? $data['stock_status'] : "instock",
            "_tax_status" => isset($data['tax_status']) ? $data['tax_status'] : "taxable",
            "_tax_class" => isset($data['tax_class']) ? $data['tax_class'] : "parent",
            "_manage_stock" => isset($data['manage_stock']) ? $data['manage_stock'] : "no",
            "_backorders" => isset($data['backorders']) ? $data['backorders'] : "no",
            "_sold_individually" => isset($data['sold_individually']) ? $data['sold_individually'] : "no",
            "_virtual" => isset($data['virtual']) ? $data['virtual'] : "no",
            "_downloadable" => isset($data['downloadable']) ? $data['downloadable'] : "no",
            "_download_limit" => isset($data['download_limit']) ? $data['download_limit'] : "-1",
            "_download_expiry" => isset($data['download_expiry']) ? $data['download_expiry'] : "-1",
            "_wc_average_rating" => isset($data['wc_average_rating']) ? $data['wc_average_rating'] : "0",
            "_wc_review_count" => isset($data['wc_review_count']) ? $data['wc_review_count'] : "0",
            "_price" => isset($data['price']) ? $data['price'] : 0,
            "_product_version" => WC()->version
        );
    }

    private function validate_product_data($data)
    {
        if ( empty($data) ) {
            throw new Exception("Invalid data provided.");
        }

        $keys = array_keys($data);
        $product_keys = array("sku", "name", "id", "category", "enabled");
        if ( array_diff( $keys, $product_keys ) != array_diff($product_keys, $keys) ) {
            //throw new Exception("Product keys mismatch!");
        }
    }
}