<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists('Inkbomb_Shipping') ) {

    class Inkbomb_Shipping
    {
        /**
         * @var Sinalite_Product
         */
        private $sinalite_product;

        /**
         * Filter Woocommerce Countries list.
         *
         * @param $countries
         * @return array|mixed
         */
        public function filter_woocommerce_countries($countries)
        {
            global $product;

            // Skip for admin
            if (is_admin() || !$this->get_sinalite_product()->has_sinalite_product($product)) {
                return $countries;
            }

            return self::get_allowed_countries();
        }

        /**
         * Filter States.
         *
         * @param $states
         * @return mixed
         */
        public function filter_woocommerce_states($states)
        {
            global $product;

            if (is_admin() || !$this->get_sinalite_product()->has_sinalite_product($product)) {
                return $states;
            }

            return self::get_allowed_states();
        }

        public static function get_allowed_countries()
        {
            return array(
                "CA" => __("Canada", "inkbomb"),
                "US" => __("United States", "inkbomb")
            );
        }

        public static function get_allowed_states()
        {
            return array(
                "US" => array(
                    "AK" => "Alaska",
                    "AS" => "American Samoa",
                    "AZ" => "Arizona",
                    "AR" => "Arkansas",
                    #"AE" => "Armed Forces Africa",
                    "AA" => "Armed Forces Americas",
                    #"AE" => "Armed Forces Canada",
                    # "AE" => "Armed Forces Europe",
                    "AE" => "Armed Forces (AE)",
                    "AP" => "Armed Forces Pacific",
                    "CA" => "California",
                    "CO" => "Colorado",
                    "CT" => "Connecticut",
                    "DE" => "Delaware",
                    "DC" => "District of Columbia",
                    "FM" => "Federated States Of Micronesia",
                    "FL" => "Florida",
                    "GA" => "Georgia",
                    "GU" => "Guam",
                    "HI" => "Hawaii",
                    "ID" => "Idaho",
                    "IL" => "Illinois",
                    "IN" => "Indiana",
                    "IA" => "Iowa",
                    "KS" => "Kansas",
                    "KY" => "Kentucky",
                    "LA" => "Louisiana",
                    "ME" => "Maine",
                    "MH" => "Marshall Islands",
                    "MD" => "Maryland",
                    "MA" => "Massachusetts",
                    "MI" => "Michigan",
                    "MN" => "Minnesota",
                    "MS" => "Mississippi",
                    "MO" => "Missouri",
                    "MT" => "Montana",
                    "NE" => "Nebraska",
                    "NV" => "Nevada",
                    "NH" => "New Hampshire",
                    "NJ" => "New Jersey",
                    "NM" => "New Mexico",
                    "NY" => "New York",
                    "NC" => "North Carolina",
                    "ND" => "North Dakota",
                    "MP" => "Northern Mariana Islands",
                    "OH" => "Ohio",
                    "OK" => "Oklahoma",
                    "OR" => "Oregon",
                    "PW" => "Palau",
                    "PA" => "Pennsylvania",
                    "PR" => "Puerto Rico",
                    "RI" => "Rhode Island",
                    "SC" => "South Carolina",
                    "SD" => "South Dakota",
                    "TN" => "Tennessee",
                    "TX" => "Texas",
                    "UT" => "Utah",
                    "VT" => "Vermont",
                    "VI" => "Virgin Islands",
                    "VA" => "Virginia",
                    "WA" => "Washington",
                    "WV" => "West Virginia",
                    "WI" => "Wisconsin",
                    "WY" => "Wyoming",
                ),
                "CA" => array(
                    "AB" => "Alberta",
                    "BC" => "British Columbia",
                    "MB" => "Manitoba",
                    "NL" => "Newfoundland and Labrador",
                    "NB" => "New Brunswick",
                    "NS" => "Nova Scotia",
                    "NT" => "Northwest Territories",
                    "NU" => "Nunavut",
                    "ON" => "Ontario",
                    "PE" => "Prince Edward Island",
                    "QC" => "Quebec",
                    "SK" => "Saskatchewan",
                    "YT" => "Yukon Territory",
                )
            );
        }

        private function get_sinalite_product()
        {
            if ($this->sinalite_product == null) {
                $this->sinalite_product = new Sinalite_Product();
            }

            return $this->sinalite_product;
        }
    }

}