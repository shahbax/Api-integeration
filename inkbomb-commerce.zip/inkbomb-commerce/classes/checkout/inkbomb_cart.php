<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists('Inkbomb_Cart') ) {

    class Inkbomb_Cart
    {
        /**
         * Inkbomb price calculator.
         *
         * @var Inkbomb_Price_Calculator
         */
        private $price_calculator;

        /**
         * @var Sinalite_Product
         */
        private $product;

        /**
         * @var Sinalite_api
         */
        private $sinalite_api;

        public function __construct()
        {
            $this->sinalite_api = new Sinalite_api();
            $this->price_calculator = new Inkbomb_Price_Calculator($this->sinalite_api);
            $this->product = new Sinalite_Product();
        }

        public function before_calculate_totals( $cart_object )
        {
            $cart_items = $cart_object->cart_contents;
            if ( empty( $cart_items ) ) {
                return;
            }

            foreach ( $cart_items as $key => $value ) {
                if (!isset($value['variation_id']) || !isset($value['product_id'])) {
                    continue;
                }

                $data = $value['data']->get_meta_data();
                $product_id = $this->product->get_sinalite_product_id($value['product_id']);
                $variation = '[]';
                if (is_array($data)
                    && !isset($data[Sinalite_Product::VARIATION_ATTRIBUTE])
                    && isset($data[0])
                    && ($data[0] instanceof WC_Meta_Data)
                ) {
                    $meta_data = $data[0]->get_data();
                    $variation = isset($meta_data['key'])
                        && ($meta_data['key'] == Sinalite_Product::VARIATION_ATTRIBUTE)
                        && $meta_data['value'] ?
                            $meta_data['value'] : $variation;
                }

                $variation = json_decode($variation, JSON_UNESCAPED_SLASHES);
                if (!$variation) {
                    continue;
                }

                $variation_data = $this->price_calculator->calculate_via_api($product_id, array_values($variation));
                if (empty($variation_data) || !isset($variation_data['price'])) {
                    continue;
                }

                $price = $variation_data['price'] + ($variation_data['price'] * round((5/100), 2));
                $value['data']->set_price( $price );
            }
        }

        public function estimate_shipping( $rates, $package )
        {
            if (!isset($package['contents'])) {
                return $rates;
            }

            $cart = WC()->cart;
            if ($cart == null) {
                return $rates;
            }

            $customer = $cart->get_customer();
            $items = array(
                "items" => array(),
                "shippingInfo" => array(
                    "ShipState" => $customer->get_shipping_state(),
                    "ShipZip" => $customer->get_shipping_postcode(),
                    "ShipCountry" => $customer->get_shipping_country(),
                )
            );
            foreach ($package['contents'] as $key => $value) {
                $variation = self::retrieve_variation_from_meta_data($value['data']->get_meta_data());
                if (empty($variation)) {
                    continue;
                }

                $items["items"][] = array(
                    "productId" => $this->product->get_sinalite_product_id($value['product_id']),
                    "options" => $variation,
                );
            }

            if (empty($items["items"])
                || empty($items['shippingInfo']['ShipState'])
                || empty($items['shippingInfo']['ShipZip'])
                || empty($items['shippingInfo']['ShipCountry'])
            ) {
                return $rates;
            }

            // Fetch rates
            $result = $this->sinalite_api->post("/order/shippingEstimate", $items);
            if (!isset($result['statusCode']) || $result['statusCode'] != 200 || !isset($result['body'])) {
                return $rates;
            }

            $estimate_body = $result['body'];
            $available_shipping = array();
            foreach ($estimate_body as $estimate) {
                if (!isset($estimate[0]) || !isset($estimate[1]) || !isset($estimate[2])) {
                    continue;
                }

                $available_shipping[strtolower($estimate[1])] = array(
                    "code"  =>  $estimate[0],
                    "title"  =>  $estimate[1],
                    "cost"  =>  $estimate[2],
                    "priority"  =>  isset($estimate[3]) ? $estimate[3] : 0,
                );
            }

            foreach ( $rates as $id => $rate ) {
                $rate_lbl = strtolower($rates[$id]->label);
                if ( !in_array( $rate_lbl, array_keys( $available_shipping ) ) ) {
                    continue;
                }

                $rates[$id]->cost = $available_shipping[$rate_lbl]['cost'];
            }
            return $rates;
        }

        public static function retrieve_variation_from_meta_data($meta_Data)
        {
            $variation = '[]';
            if (is_array($meta_Data)
                && !isset($meta_Data[Sinalite_Product::VARIATION_ATTRIBUTE])
                && isset($meta_Data[0])
                && ($meta_Data[0] instanceof WC_Meta_Data)
            ) {
                $meta_data = $meta_Data[0]->get_data();
                $variation = isset($meta_data['key'])
                && ($meta_data['key'] == Sinalite_Product::VARIATION_ATTRIBUTE)
                && $meta_data['value'] ?
                    $meta_data['value'] : $variation;
            }

            $variation = json_decode($variation, JSON_UNESCAPED_SLASHES);
            if (!$variation) {
                return array();
            }

            return $variation;
        }
    }
}