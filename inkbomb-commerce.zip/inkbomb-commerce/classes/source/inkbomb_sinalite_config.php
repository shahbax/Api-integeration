<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Inkbomb_Sinalite_Config
{
    const SINALITE_GENERAL_OPTIONS = 'inkbomb_options';
    const SINALITE_API_OPTIONS = 'inkbomb_api_options';
    const IMPORT_CATEGORIES = 'import_cats';
    const SINALITE_CLIENT_ID = 'client_id';
    const SINALITE_CLIENT_SECRET = 'client_secret';
    const SINALITE_APP_MODE = 'app_mode';
    const SINALITE_GENERATED_ACCESS_TOKEN = 'generated_access_token';
    const SINALITE_GENERATED_TOKEN_TYPE = 'generated_access_token_type';
    const API_AUDIENCE = 'https://apiconnect.sinalite.com';
    const CREDENTIALS_GRANT_TYPE = 'client_credentials';
    const PRICE_MARKUP = 'price_markup';
    const IS_SCHEDULER_ENABLED = 'is_scheduler_enabled';
    const DISPLAY_ORDER_DETAILS = 'display_order_details';

    public function get_general_options()
    {
        $options = get_option( self::SINALITE_GENERAL_OPTIONS );
        return !empty($options) ? $options : array();
    }

    public function get_api_options()
    {
        $options = get_option( self::SINALITE_API_OPTIONS );
        return !empty($options) ? $options : array();
    }

    public function get_category_ids()
    {
        $options = $this->get_general_options();
        return isset($options[self::IMPORT_CATEGORIES]) ? $options[self::IMPORT_CATEGORIES] : '[]';
    }

    public function get_selected_category_options()
    {
        $ids = json_decode($this->get_category_ids(), true);
        if (empty($ids)) {
            return array();
        }

        $selected_list = array();
        foreach ($ids as $id) {
            $selected_list [] = array(
                "value" => $id,
                "name" => get_the_category_by_ID($id)
            );
        }
        return $selected_list;
    }

    public function get_client_id()
    {
        $options = $this->get_api_options();
        return isset( $options[ self::SINALITE_CLIENT_ID ] ) ? $options[ self::SINALITE_CLIENT_ID ] : "";
    }

    public function get_client_secret()
    {
        $options = $this->get_api_options();
        return isset( $options[ self::SINALITE_CLIENT_SECRET ] ) ? $options[ self::SINALITE_CLIENT_SECRET ] : "";
    }

    public function get_app_mode()
    {
        $options = $this->get_api_options();
        return isset( $options[ self::SINALITE_APP_MODE ] ) ? $options[ self::SINALITE_APP_MODE ] : "";
    }

    public function get_generated_access_token()
    {
        $options = $this->get_api_options();
        return isset( $options[ self::SINALITE_GENERATED_ACCESS_TOKEN ] ) ? $options[ self::SINALITE_GENERATED_ACCESS_TOKEN ] : "";
    }

    public function get_generated_token_type()
    {
        $options = $this->get_api_options();
        return isset( $options[ self::SINALITE_GENERATED_TOKEN_TYPE ] ) ? $options[ self::SINALITE_GENERATED_TOKEN_TYPE ] : "Bearer";
    }

    public function get_markup_value()
    {
        $options = $this->get_general_options();
        return isset($options[self::PRICE_MARKUP]) ? (int)$options[self::PRICE_MARKUP] : 5;
    }

    public function is_scheduler_enabled()
    {
        $options = $this->get_general_options();
        return isset($options[self::IS_SCHEDULER_ENABLED]) ? (int)$options[self::IS_SCHEDULER_ENABLED] : 1;
    }

    public function get_placeholder_attachment_id()
    {
        $options = $this->get_general_options();
        if (!isset($options['placeholder_attachment_id'])) {
            $options['placeholder_attachment_id'] = "";
        }

        if (empty($options['placeholder_attachment_id'])) {
            $image_url = wc_placeholder_img_src('woocommerce_large');
            $buffer = file_get_contents($image_url);
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime_type = $finfo->buffer($buffer);
            $attachment_id = wp_insert_attachment(
                array(
                    'guid'           => $image_url,
                    'post_mime_type' => $mime_type,
                    'post_title'     => basename( $image_url),
                    'post_content'   => '',
                    'post_status'    => 'inherit',
                ),
                $image_url
            );
            $options['placeholder_attachment_id'] = $attachment_id;
            update_option(self::SINALITE_GENERAL_OPTIONS, $options);
        }

        return $options['placeholder_attachment_id'];
    }
}