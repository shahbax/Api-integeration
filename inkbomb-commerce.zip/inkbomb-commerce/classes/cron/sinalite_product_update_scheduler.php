<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists('Sinalite_Product_Update_Scheduler') ) {

    class Sinalite_Product_Update_Scheduler
    {
        /**
         * @var Sinalite_Product_Importer
         */
        private $importer;

        /**
         * @var Sinalite_Product
         */
        private $product;

        public function __construct()
        {
            $this->importer = new Sinalite_Product_Importer();
            $this->product = new Sinalite_Product();
        }

        public function execute()
        {
            /** @var $sinalite_api Sinalite_api */
            global $sinalite_api;
            /** @var $sinalite_config Inkbomb_Sinalite_Config */
            global $sinalite_config;

            if (!$sinalite_config->is_scheduler_enabled()) {
                return;
            }

            inkbomb_write_log("Sinalite import scheduler started.");
            $cron_complete_msg = "Sinalite import scheduler completed successfully.";
            $csv_data = $this->product->get_csv_data();
            if (empty($csv_data)) {
                inkbomb_write_log("No product found to import.");
                inkbomb_write_log($cron_complete_msg);
                return;
            }

            foreach ($csv_data as $data) {
                if (empty($data['_original_id'])) {
                    inkbomb_write_log("\"{$data['name']}\" not found. Skipping import update.");
                    continue;
                }

                inkbomb_write_log("*********************************");
                inkbomb_write_log("importing \"{$data['name']}\"");
                // Get the price data and price hash
                try {
                    $p_id = $data['id'];
                    $original_p_id = $data['_original_id'];
                    /**
                     * Retrieve the price data.
                     */
                    $price_data = $sinalite_api->get("/product/{$p_id}/en_ca", array(), true);
                    if (empty($price_data)) {
                        throw new Exception("No response received from API.");
                    }

                    /**
                     * Extract attributes from api.
                     */
                    $attributes = $this->importer->extract_attributes_from_options_group($price_data[0]);
                    if (empty($attributes)) {
                        throw new Exception("Error finding the group attributes.");
                    }

                    // Load the product using `_original_id` index value
                    $product = new WC_Product_Variable($original_p_id);
                    if (!$product->get_id()) {
                        throw new Exception("Product with ID {$product->get_id()} not found.");
                    }

                    /**
                     * Import price hash data
                     */
                    $this->importer->import_price_hash($product->get_id(), $price_data);

                    /**
                     * Begin importing the attributes.
                     */
                    $this->importer->import_attributes($product, $attributes);

                    /**
                     * Retrieve variations
                     */
                    $variation_data = $sinalite_api->get("/variants/{$p_id}");
                    if (empty($variation_data)) {
                        throw new Exception("No variations received from API.");
                    }

                    $response = $this->importer->import_variations($variation_data, $price_data[0], $product);
                    if (!empty($response["success"])) {
                        inkbomb_write_log("Import Success! {$response['message']}");
                    }

                    inkbomb_write_log("*********************************");
                } catch (Exception $e) {
                    inkbomb_write_log("Import API Exception: \"{$e->getMessage()}\"");
                    continue;
                }
            }
            /*wp_mail(
                'ars4arsalan@gmail.com',
                'Testing a cron event',
                'This is an automatic WordPress email for testing a cron event.'
            );*/
            inkbomb_write_log($cron_complete_msg);
        }
    }

}