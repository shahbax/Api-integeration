<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists( 'Sinalite_api' ) ) {
    class Sinalite_api
    {
        const API_STORE_CA = 'en_ca';
        const API_STORE_US = 'en_us';

        /**
         * @var \GuzzleHttp\Client
         */
        private $guzzle_client;

        private $token;

        private $sandbox_url = 'https://api.sinaliteuppy.com';
        private $live_url = 'https://liveapi.sinalite.com';

        public function __construct()
        {
            $this->guzzle_client = new GuzzleHttp\Client();
        }

        /**
         *
         * Send post request.
         *
         * @param $path
         * @param $body
         * @return mixed
         * @throws Exception
         * @throws \GuzzleHttp\Exception\GuzzleException
         */
        public function post($path, $body = array())
        {
            $raw_response = $this->guzzle_client->post(
                $this->prepare_url($path),
                array(
                    "headers" => array(
                        "Authorization" => "Bearer {$this->get_token()}"
                    ),
                    GuzzleHttp\RequestOptions::JSON =>  $body,
                    "connect_timeout" => 35
                )
            );

            return $this->extract_response($raw_response);
        }

        /**
         * Send GET request.
         *
         * @param $path
         * @param array $body
         * @param bool $token_required
         * @return mixed
         * @throws Exception
         */
        public function get($path, $body = array(), $token_required = false)
        {
            $options = array();
            if (!empty($body)) {
                $options[GuzzleHttp\RequestOptions::JSON] = $body;
            }

            if ($token_required) {
                $options["headers"] = array(
                    "Authorization" => "Bearer {$this->get_token()}"
                );
            }

            $options['connect_timeout'] = 35;
            $raw_response = $this->guzzle_client->get(
                $this->prepare_url($path),
                $options
            );

            return $this->extract_response($raw_response);
        }

        /**
         * Returns API url based on configuration.
         *
         * @param $options
         * @return string
         */
        public function get_api_url()
        {
            global $sinalite_config;
            return ($sinalite_config->get_app_mode() == 'live') ? $this->get_live_url() : $this->get_sandbox_url();
        }

        /**
         * Return generated token string.
         *
         * @param $options
         * @return mixed|string
         */
        public function get_token($options = array())
        {
            global $sinalite_config;
            if ($this->token == null) {
                $this->token = $sinalite_config->get_generated_access_token();
            }

            return $this->token;
        }

        /**
         * Prepares the request url based on provided path.
         *
         * @param $path
         * @return string
         */
        private function prepare_url($path)
        {
            if (strpos($path, '/') != 0) {
                $path = '/' . $path;
            }

            return $this->get_api_url() . $path;
        }

        /**
         * Returns the sandbox url
         *
         * @return string
         */
        private function get_sandbox_url()
        {
            return $this->sandbox_url;
        }

        /**
         * Returns the live api url.
         *
         * @return string
         */
        private function get_live_url()
        {
            return $this->live_url;
        }

        private function extract_response($raw_response)
        {
            $result = $raw_response->getBody()->getContents();
            $response = json_decode($result, true);
            if (json_last_error() != JSON_ERROR_NONE) {
                inkbomb_write_log($result);
                throw new Exception("Invalid JSON formed.");
            }

            return $response;
        }

        /**
         * Executes the CURl request and returns the response data.
         *
         * @param $url
         * @param $additional_options
         * @return mixed
         * @throws Exception
         */
        private function execute($url, $additional_options = array())
        {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER , false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_POSTREDIR, 3);
            if (!empty($additional_options)) {
                foreach ($additional_options as $key => $option) {
                    curl_setopt($ch, $key, $option);
                }
            }

            $result = curl_exec($ch);
            $error_msg = '';
            if (curl_errno($ch)) {
                $error_msg = curl_error($ch);
            }

            curl_close($ch);
            if (!empty($error_msg)) {
                throw new Exception($error_msg);
            }

            $json_response = json_decode($result, true);
            if (json_last_error() != JSON_ERROR_NONE) {
                throw new Exception("Invalid JSON formed.");
            }

            return $json_response;
        }
    }
}