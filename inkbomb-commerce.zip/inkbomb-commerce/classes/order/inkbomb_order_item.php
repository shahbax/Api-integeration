<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists( 'Inkbomb_Order_Item' ) ) {

    class Inkbomb_Order_Item
    {
        /**
         * @var Sinalite_api
         */
        private $sinalite_api;

        private $order_data = array();

        public function __construct()
        {
            $this->sinalite_api = new Sinalite_api();
            add_action( 'woocommerce_admin_order_items_after_fees', array( $this, 'html_sinalite_order_data' ) );
            add_action( 'woocommerce_before_order_itemmeta', array( $this, 'html_before_order_meta' ), 10, 3);
        }

        public function init_order($billing_address)
        {
            $order = WC()->order_factory->get_order();
            $sinalite_data = $this->extract_sinalite_data($order);
            if (empty($sinalite_data) || !isset($sinalite_data['orderId']) || isset($this->order_data['order'])) {
                return $billing_address;
            }

            try {
                $this->order_data = $this->sinalite_api->get("/order/{$sinalite_data['orderId']}", array(), true);
            } catch (Exception $e) {
                return $billing_address;
            }
            if (!$this->order_data || !isset($this->order_data['order']) || !isset($this->order_data['items'])) {
                return $billing_address;
            }

            foreach ($this->order_data['items'] as $key => $item) {
                $attributes = array();
                $options = json_decode($item["options"], JSON_UNESCAPED_SLASHES);
                array_walk($options, function ($val, $k) use (&$attributes) {
                    $attributes[sanitize_title($k)] = $val;
                }, $attributes);

                $this->order_data['items'][$key]["options"] = $attributes;
            }

            echo "<script>
                    var sinalite_data = " . json_encode($this->order_data, JSON_UNESCAPED_SLASHES) . ";
                    window.sinalite_order_data = sinalite_data;
                </script>";
            echo '<script type="text/javascript" src="' . INKBOMB_URI . 'assets/js/admin/order-item.js' . '"></script>';
            return $billing_address;
        }

        public function html_sinalite_order_data ($order_id)
        {
            $order = WC()->order_factory->get_order($order_id);
            $sinalite_data = $this->extract_sinalite_data($order);
            if (empty($sinalite_data)) {
                return;
            }
            ?>
            <div class="panel-wrap woocommerce" style="padding: 23px 24px 12px;">
                <div class="panel woocommerce-order-data">
                    <h1 class="woocommerce-order-data__heading"><?php echo __('Sinalite Order Summary', 'inkbomb') ?></h1>
                    <?php foreach ($sinalite_data as $key => $datum){
                        if ($key == "message") {
                            continue;
                        }
                        ?>
                        <p class="woocommerce-order-data__meta"><strong><?php
                            echo __(ucfirst($key) . ': ', 'inkbomb') ?></strong><?php
                            if (is_numeric($datum) && $key != "orderId") {
                                $datum = wc_price((float) $datum);
                            }
                            echo $datum;
                            ?></p>
                    <?php } ?>
                </div>
            </div>
            <?php
        }

        /**
         * @param $item_id
         * @param WC_Order_Item $item
         * @param WC_Product_Variable $product
         */
        public function html_before_order_meta( $item_id, $item, $product )
        {
            if ($product == null || !isset($this->order_data['items'])) {
                return;
            }

            $items = $this->order_data['items'];
            $attributes = $product->get_attributes();
            foreach ($items as $itm) {
                if (empty(array_diff($itm['options'], $attributes)) && isset($itm['packageInfo'])) {
                    ?>
                        <div class="view" style="display: none;">
                            <input name='package_info' type='hidden' value='<?php echo $itm['packageInfo']; ?>' />
                            <p><strong>Package info:</strong></p>
                            <table class="package_details display_meta">
                                <tbody></tbody>
                            </table>
                    <?php
                        if (isset($itm['files']) && $itm['files']) {
                            $files = json_decode($itm['files'], JSON_UNESCAPED_SLASHES);
                            echo '<p><strong>Files:</strong></p><ol>';
                            foreach ($files as $file) {
                                ?>
                                <li><a href="<?php echo $file['url'] ?>" target="_blank"><?php echo ucfirst($file['type']); ?></a></li>
                                <?php
                            }
                            echo '</ol>';
                        }
                    ?>
                            <p><strong>Options:</strong></p>
                        </div>
                    <?php
                    break;
                }
            }
        }

        private function extract_sinalite_data( $order )
        {
            $sinalite_data = $order->get_meta('sinalite_order_data');
            if (!$sinalite_data) {
                return array();
            }

            $data = json_decode($sinalite_data, JSON_UNESCAPED_SLASHES);
            if (!isset($data['orderId'])) {
                return array();
            }

            return $data;
        }
    }
}