<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists( 'Inkbomb_order' ) ) {

    class Inkbomb_order
    {
        /**
         * Inkbomb product instance.
         *
         * @var Sinalite_Product
         */
        private $product;

        /**
         * @var Inkbomb_Price_Calculator
         */
        private $price_calculator;

        private $sinalite_order_data = array();

        private $sinalite_items = array();

        public function __construct()
        {
            $this->product = new Sinalite_Product();
            $this->price_calculator = new Inkbomb_Price_Calculator();
        }

        protected $_request = array(
            "items" => array(),
            "shippingInfo" => array(),
            "billingInfo" => array(),
            "notes" => ""
        );

        /**
         * @param WC_Order $order
         * @param mixed $data
         * @throws \GuzzleHttp\Exception\GuzzleException
         */
        public function create_order($order, $data)
        {
            /** @var $sinalite_api Sinalite_api */
            global $sinalite_api;

            $this->_prepare_request($order);
            try {
                if (empty($this->sinalite_items)) {
                    return;
                }

                /**
                 * Validate the number of sinalite items.
                 */
                if ( count($this->sinalite_items) < count( $order->get_items() ) ) {
                    throw new Exception("Only Sinalite items are allowed.");
                }

                // Send order placement request
                $result = $sinalite_api->post('order/new', $this->get_request());
                if (isset($result['status']) && $result['status'] == 'success') {
                    $shipping_cost = $result['shippingCost'];
                    $tax_amount = $result['tax'];
                    $subtotal_incl_tax = $this->_add_markup_price($result['subtotal']);
                    $grandtoal_incl_tax = $this->_add_markup_price($result['grandtotal']);

                    $order->set_prices_include_tax('yes');
                    $order->set_shipping_total($shipping_cost);
                    $order->set_cart_tax($tax_amount);
                    $order->set_prices_include_tax($subtotal_incl_tax);
                    $order->set_total($grandtoal_incl_tax);
                    $order->set_prices_include_tax($grandtoal_incl_tax);
                    /**
                     * @var  $key
                     * @var WC_Order_Item_Tax $tax
                     */
                    foreach ( $order->get_items( 'tax' ) as $key => &$tax ) {
                        $tax->set_tax_total($tax_amount);
                    }
                    $this->sinalite_order_data = $result;
                } else {
                    throw new Exception(isset($result['message']) ? $result['message'] : "Request Failure");
                }

            } catch (Exception $e) {
                $order->set_status('failed');
                throw new Exception("Failed to place order. Please try again later." . $e->getMessage());
            }
        }

        public function update_order_meta($order_id, $data)
        {
            update_post_meta($order_id, 'sinalite_order_data', json_encode($this->sinalite_order_data));
        }

        /**
         * Returns the request array.
         *
         * @return mixed
         */
        public function get_request()
        {
            return $this->_request;
        }

        /**
         * Prepares the request to be sent to Sinalite order placement API.
         *
         * @param WC_Order $order
         */
        protected function _prepare_request( WC_Order $order )
        {
            $this->_request["notes"] = $order->get_customer_note();
            $i = 0;
            foreach( $order->get_items( $this->_get_types() ) as $item_id => $item ) {
                if ($item->is_type('line_item')) {
                    $variation_id = $item->get_variation_id();
                    $sinalite_product_id = $this->product->get_sinalite_product_id($item->get_product_id());
                    if ( empty( $sinalite_product_id ) ) {
                        continue;
                    }
                    // Push Sinalite item
                    $this->sinalite_items[] = $sinalite_product_id;
                    $this->_request["items"][$i] = array(
                        "productId" => $sinalite_product_id,
                        "options" => $this->get_selected_variations($variation_id),
                        "files" => array(
                            array(
                                "type" => "front",
                                "url" => "https://plugindemo.arsalanajmal.pk/wp-content/uploads/pdf1.pdf",
                            ),
                            array(
                                "type" => "back",
                                "url" => "https://plugindemo.arsalanajmal.pk/wp-content/uploads/pdf2.pdf",
                                //"url" => "https://sinalite.com/pdf2.pdf",
                            ),
                        )
                    );

                    $i++;
                }
            }

            $this->_request["shippingInfo"] = $this->get_shipping_info($order);
            $this->_request["billingInfo"] = $this->get_billing_info($order);
        }

        public function get_price_calculator()
        {
            return $this->price_calculator;
        }

        protected function _get_types()
        {
            return array( 'line_item', 'fee', 'shipping', 'coupon' );
        }

        protected function _add_markup_price($price)
        {
            return $this->get_price_calculator()->add_markup_price($price);
        }

        private function get_selected_variations($variation_id)
        {
            $variations = get_post_meta($variation_id, 'sinalite_variation_attribute', true);
            if (!empty($variations)) {
                $variations = json_decode($variations, true);
            }

            return $variations;
        }

        private function get_shipping_info(WC_Order $order)
        {
            return array(
                "ShipFName"=> $order->get_shipping_first_name(),
                "ShipLName"=> $order->get_shipping_last_name(),
                "ShipEmail"=> $order->get_billing_email(),
                "ShipAddr"=> $order->get_shipping_address_1(),
                "ShipAddr2"=> $order->get_shipping_address_2(),
                "ShipCity"=> $order->get_shipping_city(),
                "ShipState"=> $order->get_shipping_state(),
                "ShipZip"=> $order->get_shipping_postcode(),
                "ShipCountry"=> $order->get_shipping_country(),
                "ShipPhone"=> $order->get_shipping_phone(),
                "ShipMethod"=> $order->get_shipping_method(), //"UPS Standard"
            );
        }

        private function get_billing_info(WC_Order $order)
        {
            return array(
                "BillFName"=> $order->get_billing_first_name(),
                "BillLName"=> $order->get_billing_last_name(),
                "BillEmail"=> $order->get_billing_email(),
                "BillAddr"=> $order->get_billing_address_1(),
                "BillAddr2"=> $order->get_billing_address_2(),
                "BillCity"=> $order->get_billing_city(),
                "BillState"=> $order->get_billing_state(),
                "BillZip"=> $order->get_billing_postcode(),
                "BillCountry"=> $order->get_billing_country(),
                "BillPhone"=> $order->get_billing_phone()
            );
        }
    }

}