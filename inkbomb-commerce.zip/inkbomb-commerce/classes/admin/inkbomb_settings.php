<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists( 'Inkbomb_settings' ) ) {
    class Inkbomb_settings
    {
        public function add_submenu_page()
        {
            /*add_menu_page(
                __('Sinalite API Settings', 'inkbomb'),
                __('Inkbomb Commerce', 'inkbomb'),
                'manage_options',
                'inkbomb-sinalite-settings',
                'inkbomb_sinalite_setting',
                'dashicons-store',
                49
            );*/

            /*add_submenu_page(
                'inkbomb-sinalite-settings',
                __('Sinalite API Settings', 'inkbomb'),
                __('Sinalite API', 'inkbomb'),
                'manage_options',
                'inkbomb-commerce-settings',
                'inkbomb_sinalite_setting',
                10
            );*/
        }
    }
}