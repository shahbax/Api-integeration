<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( !class_exists( 'Inkbomb_product_controller' ) ) {
    class Inkbomb_product_controller
    {
        /**
         * @var Sinalite_Product
         */
        private $product;

        /**
         * @var Sinalite_Product_Importer
         */
        private $sinalite_importer;

        public function __construct()
        {
            $this->product = new Sinalite_Product();
            $this->sinalite_importer = new Sinalite_Product_Importer();
        }

        public function import_product()
        {
            if (is_admin()) {
                $data = json_decode(stripslashes($_POST['data']), true);
                $price_data = json_decode(stripslashes($_POST['price_data']), true);
                $product_data = $this->sinalite_importer->import_product($data, $price_data);
                wp_send_json($product_data, 1);
                die();

                /*########################################################*/
                $image_url = 'https://source.knowthemage.com/wp-content/uploads/2022/09/hoodie-with-logo-2.jpg';
                $temp_file = wc_rest_upload_image_from_url($image_url);
                $temp_file = $temp_file['file'];
                //echo json_encode($temp_file); exit;
                $file = array(
                    'name'     => basename( $image_url ),
                    'type'     => mime_content_type( $temp_file ),
                    'tmp_name' => $temp_file,
                    'size'     => filesize( $temp_file ),
                );
                $sideload = wp_handle_sideload(
                    $file,
                    array(
                        'test_form'   => false // no needs to check 'action' parameter
                    )
                );
                $attachment_id = wp_insert_attachment(
                    array(
                        'guid'           => $sideload[ 'url' ],
                        'post_mime_type' => $sideload[ 'type' ],
                        'post_title'     => basename( $sideload[ 'file' ] ),
                        'post_content'   => '',
                        'post_status'    => 'inherit',
                    ),
                    $sideload[ 'file' ]
                );
                //echo json_encode($attachment_id); exit;
                // Creating a variable product
                $image_url = wc_placeholder_img_src('woocommerce_large');
                $media = media_sideload_image($image_url,0);
                $attachments = get_posts(array(
                    'post_type' => 'attachment',
                    'post_status' => null,
                    'post_parent' => 0,
                    'orderby' => 'post_date',
                    'order' => 'DESC'
                ));

                $product_id = wc_get_product_id_by_sku($data['sku']);
                $product = new WC_Product_Variable($product_id);
                $product->set_image_id( $attachments[0]->ID );
                $product->set_name($data['name']);
                $product->set_sku($data['sku']);
                $product->set_description($data['name']);
                $cat_name = "Business Cards";
                $category = get_term_by( 'name', $cat_name, 'product_cat' );
                $cat_id = $category->term_id;
                $product->set_category_ids(array($cat_id));
                $product->set_stock_status('instock');

                $product->save();
                $this->product->set_sinalite_product_id($product->get_id(), $data['id']);
                $price_hash_data = array();
                for ($i =0; $i < count($price_data[1]); $i++) {
                    $price_hash_data[$price_data[1][$i]['hash']] = $price_data[1][$i]['value'];
                }
                $this->product->set_sinalite_price_data($product->get_id(), $price_hash_data);
                //$this->add_attribute($product, $price_data);
                wp_send_json($product->get_data(), 1);
            }

            wp_die();
        }

        public function create_product_variations()
        {
            if (is_admin()) {
                $variations = json_decode(stripslashes($_POST['variations']), true);
                $price_data = json_decode(stripslashes($_POST['price_data']), true);
                $product_id = $_POST['product_id'];

                try {
                    $result = $this->sinalite_importer->import_variations($variations, $price_data, $product_id);
                } catch (Exception $e) {
                    wp_send_json(["error" => true, "message" => $e->getMessage()], 0);
                    die();
                }

                wp_send_json($result, 1);
            }

            die();
        }
    }
}