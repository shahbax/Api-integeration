<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use Automattic\WooCommerce\Utilities\NumberUtil;

if ( !class_exists('Inkbomb_Price_Calculator') ) {


    class Inkbomb_Price_Calculator
    {
        /**
         * @var Sinalite_api
         */
        private $sinalite_api;

        /**
         * @param $sinalite_api
         */
        public function __construct($sinalite_api = null)
        {
            $this->sinalite_api = (!$sinalite_api instanceof Sinalite_api) ?
                new Sinalite_api(): $sinalite_api;
            $this->init_session();
        }

        public function calculate_using_price_hash($product_id, $product_options)
        {
            $price_hash_data = get_post_meta($product_id, 'sinalite_price_data', true);
            $price_hash_data = json_decode($price_hash_data, JSON_UNESCAPED_SLASHES);
            $calculated_price = 0;
            if (!$price_hash_data || !count($price_hash_data)) {
                return $this->add_markup_price($calculated_price);
            }

            $qty = $product_options["qty"] ?? 0;
            $size = $product_options["size"] ?? 0;
            if (!$qty || !$size) {
                return $this->add_markup_price($calculated_price);
            }

            foreach ($product_options as $name => $value) {
                if (in_array($name, array("qty", "size"))) {
                    continue;
                }

                $calculated_price += $this->convert_and_validate_price($qty, $size,array(
                    "name" => $name,
                    "value" => $value,
                    "price_hash" => $price_hash_data
                ));
            }

            $final_price = $calculated_price * $qty;

            return $this->add_markup_price($final_price);
        }

        public function convert_and_validate_price($qty, $size, $attribute_data)
        {
            $hash_str = md5(strtolower(
                "#{$attribute_data['name']}#{$attribute_data['name']}_{$attribute_data['value']}#size#size_{$size}#qty#qty_{$qty}"
            ));
            if (!isset($attribute_data['price_hash'][$hash_str])) {
                throw new Exception("Hash string not found in list.");
            }

            $hash_value = $attribute_data['price_hash'][$hash_str];
            if (is_numeric($hash_value)) {
                return $this->add_markup_price($hash_value);
            }

            if (!strpos($hash_value, "x") && !strpos($hash_value, "+")) {
                throw new Exception("Invalid hash string.");
            }

            $sign = "x";
            $hash_array_value = explode("x", str_replace(" ", "", $hash_value));
            if (empty($hash_array_value)) {
                $hash_array_value = explode("+", str_replace(" ", "", $hash_value));
            }

            $price = 0;
            foreach ($hash_array_value as $amount) {
                if (!is_numeric($amount)) {
                    continue;
                }

                if (!$price) $price = 1;

                if ($sign == "x")
                    $price *= (float)$amount;
                else
                    $price += (float)$amount;
            }

            // Do not add markup here.
            return $price;
        }

        /**
         * @param $product_id
         * @param $product_options
         * @param string $store_code
         * @return array
         * @throws \GuzzleHttp\Exception\GuzzleException
         */
        public function calculate_via_api($product_id, $product_options, $store_code = "en_ca")
        {
            /*$is_product_post = ( isset($_REQUEST['post_type']) && $_REQUEST['post_type'] == "product" && is_admin())
                ? true : false;*/
            if (!is_array($product_options) || empty($product_id) || is_admin()) {
                return array();
            }

            $path = "/price/$product_id/$store_code";
            if (!isset($product_options['productOptions'])) {
                $product_options = array(
                    "productOptions" => $product_options
                );
            }

            try {
                if (isset($_SESSION['sinalite_api_calc'][json_encode($product_options)]) && $_SESSION['sinalite_api_calc'][json_encode($product_options)]) {
                    return json_decode($_SESSION['sinalite_api_calc'][json_encode($product_options)], true);
                }

                $price_data = $this->sinalite_api->post($path, $product_options);
                if (isset($price_data['error'])) {
                    throw new Exception($price_data['error']);
                }

                // Add markup.
                if (isset($price_data['price'])) {
                    $price_data['price'] = $this->add_markup_price($price_data['price']);
                    inkbomb_write_log("price: {$price_data['price']}");
                }

                $_SESSION['sinalite_api_calc'][json_encode($product_options)] = json_encode($price_data);
                return $price_data;
            } catch (Exception $e) {
                return array();
            }
        }

        /**
         * @param $price
         * @return float
         */
        public function add_markup_price($price)
        {
            /** @var $sinalite_config Inkbomb_Sinalite_Config */
            global $sinalite_config;

            $price += $price * round($sinalite_config->get_markup_value()/100, 2);
            return NumberUtil::round(
                $price,
                wc_get_price_decimals()
            );
        }

        protected function init_session()
        {
            if(!headers_sent() && !session_id()) {
                session_start();
            }

            if (!isset($_SESSION) || !isset($_SESSION['sinalite_api_calc'])) {
                $_SESSION = array("sinalite_api_calc" => array());
            }
        }
    }
}