<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_UPS_Worldwide_Expedited') ) {
    class Inkbomb_UPS_Worldwide_Expedited extends Inkbomb_Shipping_Method
    {
        public function __construct($instance_id = 0)
        {
            $this->id                   = 'ups_worldwide_expedited';
            $this->method_title         = __('UPS Worldwide Expedited');
            $this->method_description   = __('UPS Worldwide Expedited');
            $this->enabled              = "yes";
            $this->title                = "UPS Worldwide Expedited";

            $this->init();
        }
    }
}