<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function inkbomb_ups_shipping_init()
{
    if ( ! class_exists('Inkbomb_UPS_Saver') ) {
        class Inkbomb_UPS_Saver extends WC_Shipping_Method
        {
            public function __construct($instance_id = 0)
            {
                $this->id                   = 'ups';
                $this->instance_id          = absint( $instance_id );
                $this->method_title         = __('UPS Saver');
                $this->method_description   = __('Sinalite API UPS Saver');

                // Load the settings API
                $this->init_form_fields();
                $this->init_settings(); // This is part of the settings API. Loads settings you previously init.
                $this->supports             = array(
                    'shipping-zones',
                    'instance-settings',
                );
                $this->instance_form_fields = array(
                    'enabled' => array(
                        'title' 		=> __( 'Enable/Disable' ),
                        'type' 			=> 'checkbox',
                        'label' 		=> __( 'Enable this shipping method' ),
                        'default' 		=> 'yes',
                    ),
                    'title' => array(
                        'title' 		=> __( 'Title' ),
                        'type' 			=> 'text',
                        'description' 	=> __( 'This controls the title which the user sees during checkout.' ),
                        'default'		=> __( 'UPS Saver' ),
                        'desc_tip'		=> true
                    )
                );
                $this->enabled              = $this->get_option( 'enabled' );
                $this->title                = $this->get_option( 'title' );

                add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
            }

            public function calculate_shipping( $package = array() ) {
                $rate = array(
                    'label' => $this->title,
                    'cost' => '10.99',
                    'calc_tax' => 'per_item'
                );

                // Register the rate
                $this->add_rate( $rate );
            }
        }
    }
}
