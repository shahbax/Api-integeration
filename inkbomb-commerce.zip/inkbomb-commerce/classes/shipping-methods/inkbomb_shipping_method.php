<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_Shipping_Method') ) {
    class Inkbomb_Shipping_Method extends WC_Shipping_Method
    {
        public function init()
        {
            // Load the settings API
            $this->init_form_fields();
            $this->init_settings(); // This is part of the settings API. Loads settings you previously init.

            // Save settings in admin if you have any defined
            add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
        }

        public function calculate_shipping( $package = array() ) {
            $rate = array(
                'label' => $this->title,
                'cost' => '10.99',
                'calc_tax' => 'per_item'
            );

            // Register the rate
            //$this->add_rate( $rate );
        }
    }
}
