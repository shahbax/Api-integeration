<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_UPS_Express') ) {
    class Inkbomb_UPS_Express extends Inkbomb_Shipping_Method
    {
        public function __construct($instance_id = 0)
        {
            $this->id                   = 'ups_express';
            $this->method_title         = __('UPS Express');
            $this->method_description   = __('UPS Express');
            $this->enabled              = "yes";
            $this->title                = "UPS Express";

            $this->init();
        }
    }
}