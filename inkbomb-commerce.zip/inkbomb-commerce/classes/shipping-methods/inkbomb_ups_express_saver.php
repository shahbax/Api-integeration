<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_UPS_Express_Saver') ) {
    class Inkbomb_UPS_Express_Saver extends Inkbomb_Shipping_Method
    {
        public function __construct($instance_id = 0)
        {
            $this->id                   = 'ups_saver';
            $this->method_title         = __('UPS Saver');
            $this->method_description   = __('UPS Saver');
            $this->enabled              = "yes";
            $this->title                = "UPS Saver";

            $this->init();
        }
    }
}