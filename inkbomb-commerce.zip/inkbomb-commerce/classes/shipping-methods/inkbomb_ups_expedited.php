<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_UPS_Expedited') ) {
    class Inkbomb_UPS_Expedited extends Inkbomb_Shipping_Method
    {
        public function __construct($instance_id = 0)
        {
            $this->id                   = 'ups_expedited';
            $this->method_title         = __('UPS Expedited');
            $this->method_description   = __('UPS Expedited');
            $this->enabled              = "yes";
            $this->title                = "UPS Expedited";

            $this->init();
        }
    }
}