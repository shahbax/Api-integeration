<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists('Inkbomb_UPS_Standard') ) {
    class Inkbomb_UPS_Standard extends Inkbomb_Shipping_Method
    {
        public function __construct($instance_id = 0)
        {
            $this->id                   = 'ups_standard';
            $this->method_title         = __('UPS Standard');
            $this->method_description   = __('UPS Standard');
            $this->enabled              = "yes";
            $this->title                = "UPS Standard";

            $this->init();
        }
    }
}