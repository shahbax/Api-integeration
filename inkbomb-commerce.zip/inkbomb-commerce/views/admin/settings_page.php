<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function inkbomb_sinalite_setting() {
    $default_tab = null;
    $tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <nav class="nav-tab-wrapper">
            <a href="?page=inkbomb-sinalite-settings" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">General Settings</a>
            <a href="?page=inkbomb-sinalite-settings&tab=api_settings" class="nav-tab <?php if($tab==='api_settings'):?>nav-tab-active<?php endif; ?>">API Settings</a>
            <a href="?page=inkbomb-sinalite-settings&tab=import_products" class="nav-tab <?php if($tab==='import_products'):?>nav-tab-active<?php endif; ?>">Import Product</a>
        </nav>
        <div class="tab-content">
        <?php
            switch($tab) {
                case 'import_products':
                    require(INKBOMB_PATH . '/views/admin/tabs/import_products.php');
                    break;
                case 'api_settings':
                    require(INKBOMB_PATH . '/views/admin/tabs/api_settings.php');
                    break;
                default:
                    require(INKBOMB_PATH . '/views/admin/tabs/general_settings.php');
                break;
            }
        ?>
        </div>
    </div>
    <?php
}