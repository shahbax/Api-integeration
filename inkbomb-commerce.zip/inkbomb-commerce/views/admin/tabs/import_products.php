<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** @var $sinalite_config Inkbomb_Sinalite_Config */
global $sinalite_config;
global $sinalite_api;

$default_tab = null;
$tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
$selected_categories = $sinalite_config->get_selected_category_options();
if (!empty($selected_categories)):
?>
<div class="wrap woocommerce">
    <h1 class="screen-reader-text">General settings</h1>
    <h2>Import Products</h2>
    <p class="sinalite-import-instructions">Click Import button to begin importing products.</p>
    <div>
        <label id="inkbomb_category"><span></span>
        </label>
        <p>
            <select id="inkbomb_category" name="category" multiple="multiple" class="inkbomb_select">
                <?php foreach ($selected_categories as $selected_category): ?>
                    <option value="<?php echo $selected_category['name']; ?>"><?php echo $selected_category['name']; ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" id="fetch_sinalite_products" class="button-primary woocommerce-save-button inkbomb-importer-btn">Fetch Product list</button>
            <button type="submit" id="import_sinalite_products" class="button-primary woocommerce-save-button inkbomb-importer-btn" style="display: none;">Import Products</button>
        </p>
    </div>

    <div id="output" class="import-status-text"></div>
    <table id="imported_action_status" class="wp-list-table widefat fixed striped table-view-list urls" style="display: none;">
        <thead>
            <tr>
                <td style="display: none">Data</td>
                <td class="manage-column column-selection"><label for="select_all"><input type="checkbox" id="select_all" />&nbsp;<span>Select All</span></label></td>
                <td class="manage-column column-id column-primary">ID</td>
                <td class="manage-column column-name column-primary">Name</td>
                <td class="manage-column column-sku column-primary">SKU</td>
                <td class="manage-column column-category column-primary">Category</td>
                <td class="manage-column column-enabled column-primary" style="display: none;">Enabled</td>
                <td class="manage-column column-action column-primary">Import Status</td>
            </tr>
        </thead>
        <tbody>
            <tr>
            </tr>
        </tbody>
    </table>
</div>
<script type="text/javascript">
    window.sinalite_api = {
        endpoint: "<?php echo $sinalite_api->get_api_url(); ?>",
        access_token: "<?php echo $sinalite_api->get_token(); ?>",
        token_type: "<?php echo $sinalite_config->get_generated_token_type(); ?>"
    };
</script>
<script type="text/javascript" src="<?php echo INKBOMB_URI . 'assets/js/admin/importer.js' ?>"></script>
<?php
else:
echo '<h3>Please Select the categories list from configuration.</h3>';
endif;