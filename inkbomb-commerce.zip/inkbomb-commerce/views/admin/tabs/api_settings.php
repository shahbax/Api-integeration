<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

?>
<form action="options.php" method="post">
    <?php
        settings_fields( 'inkbomb_api_options' );
        do_settings_sections( 'inkbomb_api_settings_page' );
    ?>
    <input name="submit" class="button button-primary" type="submit" value="<?php esc_attr_e( 'Save' ); ?>" />
</form>