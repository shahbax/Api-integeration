jQuery( function ($) {

    var sinaliteApi = window.sinalite_api;

    var import_btn = "#import_sinalite_products",
        inkbomb_category = '#inkbomb_category',
        allowed_category_options = inkbomb_category + " option",
        import_table = '#imported_action_status',
        tbody = import_table + " tbody",
        output = "#output",
        selectAllOption = '#select_all',
        fetchProductBtn = "#fetch_sinalite_products";

    // Product fetch event.
    $(document).on('click', fetchProductBtn, initialize_import);
    // Import products event.
    $(document).on('click', import_btn, fetch_pricing_data_and_import);
    // Select all checkbox action.
    $(document).on('change', selectAllOption, function () {
        var toggleText= "Select All",
            attrChecked = false,
            checkboxes = $('input[name="import[]"]');
        $(checkboxes).prop('checked', false);
        if ($(this).is(':checked')) {
            toggleText = "Deselect All";
            attrChecked = true;
        }

        $(checkboxes).prop('checked', attrChecked);
        $(this).siblings('span')[0].innerText = toggleText;
    });
    // on Change the selection
    $(document).on( 'change', 'input[name="import[]"]', function () {
        $( '#select_all' ).prop('checked', false);
        $($( '#select_all' ).siblings('span')).text("Select All");
    } );

    // Display Fetch product button on allowed category option selection.
    $( document ).on( 'change', inkbomb_category, function () {
        $( fetchProductBtn ).show();
        $( import_btn ).hide();
    } );
    /**
     * Retrieve the list of selected categories.
     * @returns {*[]}
     */
    function get_selected_categories()
    {
        var selected_categories = [];
        $(allowed_category_options).each(function () {
            if ($(this).is(':selected')) selected_categories.push($(this).val());
        });

        return selected_categories;
    }

    function initialize_import(e) {
        if (!get_selected_categories().length) {
            alert("Please select the categories to import.");
            return;
        }

        var currentTarget = e.currentTarget;
        $(currentTarget).attr('disabled', 'disabled');
        $(output).html("Requesting products to be imported...");
        $.get( { url: sinaliteApi.endpoint + "/product",  headers: {"authorization":  sinaliteApi.access_token} }, function (data, status) {
            $(output).html("");
            $(currentTarget).removeAttr('disabled');
            if ( status !== "success" ) {
                alert("Something went wrong while importing the products.");
                return false;
            }

            if ( !data.length ) {
                $(output).html("<p>No products were found!</p>");
                return false;
            }

            display_products_to_import(data);
            $(currentTarget).hide();
            $(import_btn).removeAttr('disabled').show();
        });

        return false;
    }

    /**
     * Display the products table that needs to be imported.
     * @param data
     */
    function display_products_to_import( data ) {
        $( tbody ).html("");
        var selected_categories = get_selected_categories();
        if ( !selected_categories.length ) {
            alert("Please select the categories to import.");
            return;
        }

        /**
         * Loop through each item
         */
        $( data ).each(function ( key, item ) {
            // Print only allowed category products
            if ( selected_categories.indexOf(item.category) > -1 ) {
                var itm_enabled = (item.enabled === 1 ? "yes" : "no");
                $(tbody).append(
                    '<tr id="product_' + item.id + '">'
                    + '<td style="display: none;"><input type="hidden" class="import_product_input" id="import_id_' + item.id + '" value=\'' + JSON.stringify(item) + '\' /></td>'
                    + '<td class="manage-column column-selection" style="margin: auto; text-align: center;"><input type="checkbox" name="import[]" value="' + item.id + '" /></td>'
                    + '<td class="column-id column-primary">' + item.id + '</td>'
                    + '<td class="column-name column-primary">' + item.name + '</td>'
                    + '<td class="column-sku column-primary">' + item.sku + '</td>'
                    + '<td class="column-category column-primary">' + item.category + '</td>'
                    + '<td class="column-enabled column-primary" style="display: none;"><span class="dashicons dashicons-' + itm_enabled + '"></span></td>'
                    + '<td class="column-action-status column-primary" id="product_' + item.id + '_status">Ready to import</td> '
                    + '</tr>'
                );

                // on load uncheck the select all
                $( selectAllOption ).trigger('change');
            }
        });

        $( import_table ).show('slow');
    }

    function fetch_pricing_data_and_import() {
        var inter,
            import_input = $('.import_product_input'),
            import_input_length = $(import_input).length,
            key = 0,
            prevKey = 0,
            importItemCheckbox = $('input[name="import[]"]'),
            allowed_ids = [];

        $( output ).html("import started");
        // Push allowed categories
        $(importItemCheckbox).each(function () {
            if ($(this).is(':checked')) {
                allowed_ids.push(parseInt($(this).val()));
            }
        });

        // Disable the import button
        $(import_btn).attr('disabled', 'disabled');

        /**
         * Begin import loop
         */
        inter = setInterval(function () {
            if (key === prevKey) {
                try {
                    var item = JSON.parse($(import_input[key]).val()),
                        tr = $(import_input[key]).parent().parent();

                    // Update the previous key
                    prevKey = key + 1;

                    // Process only allowed products
                    if ($.inArray(item.id, allowed_ids) > -1) {
                        $( output ).html("importing item \"" + item.name + "\" having ID: " + item.id);
                        /**
                         * Request product data.
                         */
                        $.get( {
                            url: sinaliteApi.endpoint + "/product/" + item.id + "/en_ca",
                            headers: {
                                "authorization":  sinaliteApi.access_token
                            }
                        }, function (price_data, status) {
                            // Set the current product status in progress.
                            $('#product_' + item.id + '_status').html('<span class="dashicons dashicons-update"></span> In Progress...');
                            $( output ).html("importing item \"" + item.name + "\" having ID: " + item.id);
                            // Send the retrieved product data and price data to the server
                            $.post(ajaxurl, {
                                data: (typeof item === "object") ? JSON.stringify(item): item,
                                price_data: JSON.stringify(price_data),
                                action: 'import_inkbomb_product'
                            }, function (product_data, status) {

                                // Request Current Product Variations
                                $.get( {
                                    url: sinaliteApi.endpoint + "/variants/" + item.id
                                }, function (data, status) {

                                    var intrvl2,
                                        req_allowed = true,
                                        req_completed = false,
                                        count = 0,
                                        i = 0,
                                        variation_length = data.length;

                                    /**
                                     * add variations step by step.
                                     * @type {number}
                                     */
                                    intrvl2 = setInterval(function () {

                                        /**
                                         * Break the nested interval
                                         * if request completed status is true
                                         */
                                        if (req_completed) {
                                            ++key;
                                            prevKey = key;
                                            $('#product_' + item.id + '_status').html('<span class="dashicons dashicons-yes"></span> Import completed');
                                            $(tr).css('backgroundColor', 'rgba(55, 183, 63, 0.5)');
                                            $(tr).find('input[type="checkbox"]').attr('disabled','disabled');
                                            clearInterval(intrvl2);
                                        }

                                        // Proceed with next request if allowed
                                        if (req_allowed) {
                                            i = count;
                                            // Request next 35 variations to the server.
                                            count = (variation_length < (count + 35)) ? variation_length : (count + 35);
                                            req_allowed = false;
                                            // Assign next variation
                                            var nextVariation = data.slice(i, count);
                                            $.post( ajaxurl, {
                                                product_id: product_data['id'],
                                                sinalite_id: item.id,
                                                variations: JSON.stringify(nextVariation),
                                                price_data: JSON.stringify(price_data[0]),
                                                action: 'import_inkbomb_product_variation'
                                            }, function ( data, status ) {
                                                // Allow Next request after 250ms difference.
                                                setTimeout(function () {
                                                    req_allowed = true;
                                                }, 200);
                                            } );

                                            /**
                                             * Mark the current request completed,
                                             * if variation processing completed.
                                             */
                                            if (count >= (variation_length-1)) {
                                                // Complete the request
                                                req_allowed = false;
                                                req_completed = true;
                                            }
                                        }

                                    }, 250);
                                })
                            });

                        });
                    } else {
                        // Skip the current item.
                        ++key;
                        prevKey = key;
                    }
                } catch (e) {
                    $(import_btn).removeAttr('disabled');
                    clearInterval( inter );
                }
            }

            /**
             * Break the loop if key reaches a value greater than
             * the imported input length.
             */
            if (import_input_length && key >= (import_input_length-1)) {
                $(import_btn).removeAttr('disabled');
                $(output).html("<span class=\"dashicons dashicons-yes\"></span> Request products have been imported.");
                clearInterval( inter );
            }
        }, 25);
    }
} );