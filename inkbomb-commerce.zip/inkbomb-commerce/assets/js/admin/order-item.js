jQuery( function ($) {
    var sinalite_order = window.sinalite_order_data;

    if (sinalite_order !== undefined) {
        $('input[name="package_info"]').each(function (key, value) {
            var package_info = (value.value.trim() !== "" ? JSON.parse(value.value) : []);
            $(value).siblings('table.package_details').each(function (i, el) {
               for (var j in package_info) {
                   var tbody = $(el).find('tbody');
                   $(tbody).append('<tr>' +
                       '<th>' + j + '</th>' +
                       '<td>' + package_info[j] + '</td>' +
                       '</tr>');
               }
                $(el).parent().show();
            });
        });
    }
} );